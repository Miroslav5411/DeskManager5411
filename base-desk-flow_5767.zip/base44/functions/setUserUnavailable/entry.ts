import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

// Admin-only action: Set another user as Unavailable.
// Two actions:
//   action: "preview" -> { ok, employee, dates, personalDeskBookings, personalParkingBookings, guestDeskBookings, guestParkingBookings }
//   action: "execute" -> performs releases + DailyWorkStatus writes + AuditLog
//
// Hard rules:
//   - Only Admin (role on Employee record OR auth user role) may invoke.
//   - Releases ONLY personal desk + parking bookings of the target employee.
//   - Guest bookings (owner_type === 'Guest') hosted by the target employee are NOT cancelled.
//   - DailyWorkStatus.status_type is restricted to "Office" | "Home Office" | "Unavailable".
//   - One DailyWorkStatus per (employee_id, date): create-or-update.
//   - Target employee remains active. is_active is never changed by this function.

const ALLOWED_WORK_STATUSES = ['Office', 'Home Office', 'Unavailable'];
const RELEASED_STATUS = 'Cancelled by Admin'; // Admin override action

function todayKey() {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}

function isWithinRolling30Days(dateStr) {
  if (!dateStr || typeof dateStr !== 'string') return false;
  const today = todayKey();
  const max = new Date();
  max.setDate(max.getDate() + 29);
  const maxStr = `${max.getFullYear()}-${String(max.getMonth() + 1).padStart(2, '0')}-${String(max.getDate()).padStart(2, '0')}`;
  return dateStr >= today && dateStr <= maxStr;
}

async function assertAdmin(base44, user) {
  if (!user) throw new Response(JSON.stringify({ error: 'Unauthorized' }), { status: 401 });
  const matches = await base44.asServiceRole.entities.Employee.filter({ email: (user.email || '').toLowerCase() });
  const isAdmin = matches[0]?.role === 'Admin' || user.role === 'Admin' || user.role === 'admin';
  if (!isAdmin) {
    throw new Response(JSON.stringify({ error: 'Forbidden: Admin access required' }), { status: 403 });
  }
  return matches[0] || null;
}

async function loadImpact(sr, employeeId, dates) {
  const [allDesk, allPark] = await Promise.all([
    sr.entities.DeskBooking.list('-date', 5000),
    sr.entities.ParkingBooking.list('-date', 5000),
  ]);

  const personalDeskBookings = allDesk.filter(
    (b) => b.employee_id === employeeId && b.owner_type !== 'Guest' && b.status === 'Active' && dates.includes(b.date)
  );
  const personalParkingBookings = allPark.filter(
    (b) => b.employee_id === employeeId && b.owner_type !== 'Guest' && b.status === 'Active' && dates.includes(b.date)
  );
  const guestDeskBookings = allDesk.filter(
    (b) => b.host_employee_id === employeeId && b.owner_type === 'Guest' && b.status === 'Active' && dates.includes(b.date)
  );
  const guestParkingBookings = allPark.filter(
    (b) => b.host_employee_id === employeeId && b.owner_type === 'Guest' && b.status === 'Active' && dates.includes(b.date)
  );

  return { personalDeskBookings, personalParkingBookings, guestDeskBookings, guestParkingBookings };
}

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    let actor;
    try {
      actor = await assertAdmin(base44, user);
    } catch (resp) {
      if (resp instanceof Response) return resp;
      throw resp;
    }

    const sr = base44.asServiceRole;
    const body = await req.json().catch(() => ({}));
    const action = body.action || 'preview';
    const employeeId = String(body.employeeId || '').trim();
    const rawDates = Array.isArray(body.dates) ? body.dates : [];
    const reason = typeof body.reason === 'string' ? body.reason.trim() : '';

    if (!employeeId) return Response.json({ error: 'employeeId is required' }, { status: 400 });

    const dates = Array.from(new Set(rawDates.filter(isWithinRolling30Days))).sort();
    if (dates.length === 0) {
      return Response.json({ error: 'At least one date within the next 30 days is required' }, { status: 400 });
    }

    const employee = (await sr.entities.Employee.filter({ id: employeeId }))[0];
    if (!employee) return Response.json({ error: 'Employee not found' }, { status: 404 });

    const impact = await loadImpact(sr, employee.id, dates);

    if (action === 'preview') {
      return Response.json({
        ok: true,
        employee: { id: employee.id, name: employee.name, email: employee.email },
        dates,
        ...impact,
      });
    }

    if (action !== 'execute') {
      return Response.json({ error: `Unknown action "${action}"` }, { status: 400 });
    }

    // ----- EXECUTE -----
    const nowIso = new Date().toISOString();
    let assignmentsReleased = { desk: 0, parking: 0 };

    // Release personal desk bookings
    for (const b of impact.personalDeskBookings) {
      await sr.entities.DeskBooking.update(b.id, {
        status: RELEASED_STATUS,
        cancelled_at: nowIso,
        cancel_reason: reason
          ? `Admin set Unavailable: ${reason}`
          : 'Admin set Unavailable',
      });
      assignmentsReleased.desk += 1;
    }

    // Release personal parking bookings
    for (const b of impact.personalParkingBookings) {
      await sr.entities.ParkingBooking.update(b.id, {
        status: RELEASED_STATUS,
        cancelled_at: nowIso,
        cancel_reason: reason
          ? `Admin set Unavailable: ${reason}`
          : 'Admin set Unavailable',
      });
      assignmentsReleased.parking += 1;
    }

    // Upsert DailyWorkStatus = Unavailable / source = Admin Set
    const existingStatuses = await sr.entities.DailyWorkStatus.filter({ employee_id: employee.id });
    let statusesCreated = 0;
    let statusesUpdated = 0;
    for (const date of dates) {
      // hard-enforce allowed status
      if (!ALLOWED_WORK_STATUSES.includes('Unavailable')) {
        return Response.json({ error: 'Internal: Unavailable not allowed' }, { status: 500 });
      }
      const existing = existingStatuses.find((s) => s.date === date);
      if (existing) {
        await sr.entities.DailyWorkStatus.update(existing.id, {
          status_type: 'Unavailable',
          source: 'Admin Set',
        });
        statusesUpdated += 1;
      } else {
        await sr.entities.DailyWorkStatus.create({
          employee_id: employee.id,
          date,
          status_type: 'Unavailable',
          source: 'Admin Set',
        });
        statusesCreated += 1;
      }
    }

    // AuditLog — single entry covering all dates
    let auditLogId = null;
    try {
      const audit = await sr.entities.AuditLog.create({
        actor_user_id: actor?.id || user?.id || '',
        action_type: 'Admin Set User Unavailable',
        affected_object_type: 'Employee/DailyWorkStatus',
        affected_object_id: employee.id,
        summary: `Admin set ${employee.name} as Unavailable for ${dates.length} date(s): ${dates.join(', ')}. Released ${assignmentsReleased.desk} desk and ${assignmentsReleased.parking} parking booking(s). Guest bookings preserved: ${impact.guestDeskBookings.length} desk, ${impact.guestParkingBookings.length} parking.`,
        reason: reason || '',
        status: 'success',
        timestamp: nowIso,
      });
      auditLogId = audit?.id || null;
    } catch (_e) { /* AuditLog optional */ }

    return Response.json({
      ok: true,
      employee: { id: employee.id, name: employee.name, email: employee.email, is_active: employee.is_active },
      dates,
      assignmentsReleased,
      statusesCreated,
      statusesUpdated,
      guestBookingsPreserved: {
        desk: impact.guestDeskBookings.length,
        parking: impact.guestParkingBookings.length,
      },
      auditLogId,
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});
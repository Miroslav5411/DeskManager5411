// Backend executor for Fixed-Desk XLSX import with preview/execute modes and invitation planning.
import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

const REQUIRED_COLUMNS = ["employee_email", "employee_name", "team_name", "location_name", "building_name", "floor_name", "desk_code"];
const trim = (v) => (v == null ? "" : String(v).trim());
const normalizeEmail = (email = "") => String(email).trim().toLowerCase();
const normalizeStatus = (status) => status === 'Sent' ? 'Sent/Pending' : (status || 'Not Sent');

function validateColumns(headers) {
  const set = new Set((headers || []).map((h) => trim(h)));
  const missing = REQUIRED_COLUMNS.filter((c) => !set.has(c));
  return { ok: missing.length === 0, missing };
}

function indexBy(list, keyFn) {
  const m = new Map();
  for (const item of list || []) {
    const k = keyFn(item);
    if (k != null && k !== "") m.set(k, item);
  }
  return m;
}

function buildCatalogIndexes(catalog) {
  const locationByName = indexBy(catalog.locations, (l) => trim(l.name).toLowerCase());
  const buildingByLocAndName = new Map();
  for (const b of catalog.buildings || []) buildingByLocAndName.set(`${b.location_id}::${trim(b.name).toLowerCase()}`, b);
  const floorByBuildingAndName = new Map();
  for (const f of catalog.floors || []) floorByBuildingAndName.set(`${f.building_id}::${trim(f.name).toLowerCase()}`, f);
  const deskByFloorAndCode = new Map();
  for (const d of catalog.desks || []) deskByFloorAndCode.set(`${d.floor_id}::${trim(d.code).toLowerCase()}`, d);
  const teamByName = indexBy(catalog.teams, (t) => trim(t.name).toLowerCase());
  const employeeByEmail = indexBy(catalog.employees, (e) => normalizeEmail(e.email));
  return { locationByName, buildingByLocAndName, floorByBuildingAndName, deskByFloorAndCode, teamByName, employeeByEmail };
}

function validateRows(rawRows, catalog) {
  const idx = buildCatalogIndexes(catalog);
  const rowErrors = [];
  const parsedRows = [];
  const seenDeskIds = new Set();
  const seenEmails = new Set();

  (rawRows || []).forEach((row, i) => {
    const rowNumber = i + 2;
    const errors = [];
    const emailRaw = trim(row.employee_email);
    const name = trim(row.employee_name);
    const teamName = trim(row.team_name);
    const locName = trim(row.location_name);
    const bldName = trim(row.building_name);
    const floorName = trim(row.floor_name);
    const deskCode = trim(row.desk_code);
    if (!emailRaw) errors.push("employee_email is required");
    if (!name) errors.push("employee_name is required");
    if (!locName) errors.push("location_name is required");
    if (!bldName) errors.push("building_name is required");
    if (!floorName) errors.push("floor_name is required");
    if (!deskCode) errors.push("desk_code is required");
    const email = normalizeEmail(emailRaw);
    if (email && seenEmails.has(email)) errors.push(`duplicate employee_email "${emailRaw}" in file`);
    if (email) seenEmails.add(email);
    const location = locName ? idx.locationByName.get(locName.toLowerCase()) : null;
    if (locName && !location) errors.push(`location "${locName}" not found`);
    let building = null;
    if (location && bldName) {
      building = idx.buildingByLocAndName.get(`${location.id}::${bldName.toLowerCase()}`);
      if (!building) errors.push(`building "${bldName}" not found in location "${locName}"`);
    }
    let floor = null;
    if (building && floorName) {
      floor = idx.floorByBuildingAndName.get(`${building.id}::${floorName.toLowerCase()}`);
      if (!floor) errors.push(`floor "${floorName}" not found in building "${bldName}"`);
    }
    let desk = null;
    if (floor && deskCode) {
      desk = idx.deskByFloorAndCode.get(`${floor.id}::${deskCode.toLowerCase()}`);
      if (!desk) errors.push(`desk "${deskCode}" not found on floor "${floorName}"`);
    }
    if (desk) {
      if (seenDeskIds.has(desk.id)) errors.push(`desk "${deskCode}" assigned more than once in file`);
      seenDeskIds.add(desk.id);
    }
    let team = null;
    if (teamName) {
      team = idx.teamByName.get(teamName.toLowerCase());
      if (!team) errors.push(`team "${teamName}" not found`);
    }
    if (errors.length) rowErrors.push({ row: rowNumber, message: errors.join("; ") });
    else parsedRows.push({ rowNumber, email, name, team, location, building, floor, desk });
  });
  return { rowErrors, parsedRows };
}

async function loadCatalog(base44) {
  const [locations, buildings, floors, desks, teams, employees] = await Promise.all([
    base44.asServiceRole.entities.Location.list("-created_date", 5000),
    base44.asServiceRole.entities.Building.list("-created_date", 5000),
    base44.asServiceRole.entities.FloorZone.list("-created_date", 5000),
    base44.asServiceRole.entities.Desk.list("-created_date", 10000),
    base44.asServiceRole.entities.Team.list("-created_date", 5000),
    base44.asServiceRole.entities.Employee.list("-created_date", 10000),
  ]);
  return { locations, buildings, floors, desks, teams, employees };
}

function impactSummary(parsedRows, catalog) {
  const idx = buildCatalogIndexes(catalog);
  const targetEmails = new Set(parsedRows.map((r) => r.email));
  const targetDeskIds = new Set(parsedRows.map((r) => r.desk.id));
  let newEmployees = 0;
  let existingEmployeesToUpdate = 0;
  let employeesLosing = 0;
  let employeesChanging = 0;
  for (const r of parsedRows) {
    const existing = idx.employeeByEmail.get(r.email);
    if (!existing) newEmployees += 1;
    else {
      existingEmployeesToUpdate += 1;
      if (existing.fixed_desk_id && existing.fixed_desk_id !== r.desk.id) employeesChanging += 1;
    }
  }
  for (const e of catalog.employees || []) {
    if (!e.fixed_desk_id) continue;
    const same = targetEmails.has(normalizeEmail(e.email)) && parsedRows.find((r) => r.email === normalizeEmail(e.email))?.desk?.id === e.fixed_desk_id;
    if (!same) employeesLosing += 1;
  }
  return { rowsProcessed: parsedRows.length, assignmentsApplied: parsedRows.length, assignmentsRemoved: targetDeskIds.size, newEmployees, existingEmployeesToUpdate, employeesChanging, employeesLosing };
}

async function invitationDecision(base44, row, options) {
  const res = await base44.functions.invoke('manageUserInvitation', {
    email: row.email,
    employeeRole: 'Employee',
    employeeId: options.employeeByEmail.get(row.email)?.id,
    sendEnabled: !!options.sendInvitations,
    forceResendPending: !!options.resendPending,
    forceResendExpiredOrFailed: !!options.resendExpiredOrFailed,
    source: 'FixedDeskImport',
    dryRun: true,
    writeAudit: false,
  });
  const data = res.data || res;
  return { rowNumber: row.rowNumber, ...data };
}

function summarizeInvitations(outcomes) {
  return {
    invitationsSentCount: outcomes.filter((o) => o.action === 'sent').length,
    invitationsResentCount: outcomes.filter((o) => o.action === 'resent').length,
    invitationsSkippedActivatedCount: outcomes.filter((o) => o.reason === 'already_activated').length,
    invitationsSkippedPendingCount: outcomes.filter((o) => o.reason === 'pending_skipped').length,
    invitationsSkippedDisabledCount: outcomes.filter((o) => o.reason === 'send_disabled').length,
    invitationsFailedCount: outcomes.filter((o) => o.action === 'failed').length,
    expiredFailedEligibleCount: outcomes.filter((o) => o.reason === 'expired_eligible' || o.reason === 'failed_retry').length,
  };
}

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ ok: false, errors: ["Unauthorized"] }, { status: 401 });
    const matches = await base44.asServiceRole.entities.Employee.filter({ email: normalizeEmail(user.email) });
    const isAdmin = user.role === "Admin" || user.role === "admin" || matches[0]?.role === "Admin";
    if (!isAdmin) return Response.json({ ok: false, errors: ["Forbidden: Admin access required"] }, { status: 403 });

    const body = await req.json().catch(() => ({}));
    const mode = body.mode || body.action || 'preview';
    const colCheck = validateColumns(body.headers || []);
    if (!colCheck.ok) return Response.json({ ok: false, stage: "headers", missingColumns: colCheck.missing, message: `Required columns missing: ${colCheck.missing.join(", ")}` });

    const catalog = await loadCatalog(base44);
    const { rowErrors, parsedRows } = validateRows(body.rows || [], catalog);
    if (rowErrors.length) return Response.json({ ok: false, stage: "rows", rowErrors });

    const employeeByEmail = new Map((catalog.employees || []).map((e) => [normalizeEmail(e.email), e]));
    const inviteOptions = { sendInvitations: !!body.sendInvitations, resendPending: !!body.resendPending, resendExpiredOrFailed: !!body.resendExpiredOrFailed, employeeByEmail };
    const invitationPlan = [];
    for (const row of parsedRows) invitationPlan.push(await invitationDecision(base44, row, inviteOptions));
    const impact = impactSummary(parsedRows, catalog);
    const invitationSummary = summarizeInvitations(invitationPlan);

    if (mode === 'preview') {
      return Response.json({ ok: true, mode: 'preview', impact, invitationPlan, invitationSummary });
    }
    if (mode !== 'execute') return Response.json({ ok: false, errors: ["Unsupported mode"] }, { status: 400 });

    const executedAt = new Date().toISOString();
    let assignmentsRemoved = 0;
    let assignmentsApplied = 0;
    let newEmployeesCreated = 0;
    let existingEmployeesUpdated = 0;
    let employeesLosingAssignment = 0;
    let employeesChangingAssignment = 0;
    const errors = [];

    const parsedByEmail = new Map(parsedRows.map((r) => [r.email, r]));
    for (const emp of (catalog.employees || []).filter((e) => e.fixed_desk_id)) {
      const target = parsedByEmail.get(normalizeEmail(emp.email));
      const keepingSame = target && target.desk.id === emp.fixed_desk_id;
      if (keepingSame) continue;
      await base44.asServiceRole.entities.Employee.update(emp.id, { ...emp, email: normalizeEmail(emp.email), fixed_desk_id: null });
      assignmentsRemoved += 1;
      if (!target) employeesLosingAssignment += 1; else employeesChangingAssignment += 1;
    }

    const targetDeskIds = new Set(parsedRows.map((r) => r.desk.id));
    for (const existingDesk of (catalog.desks || [])) {
      const hasFixedAssignment = existingDesk.desk_type === "Fixed" || existingDesk.assigned_employee_id || existingDesk.assigned_team_id;
      if (!hasFixedAssignment || targetDeskIds.has(existingDesk.id)) continue;
      await base44.asServiceRole.entities.Desk.update(existingDesk.id, { desk_type: "Bookable", assigned_employee_id: "", assigned_team_id: "" });
    }

    const finalEmployeeByEmail = new Map(employeeByEmail);
    for (const r of parsedRows) {
      let emp = finalEmployeeByEmail.get(r.email);
      if (!emp) {
        emp = await base44.asServiceRole.entities.Employee.create({ name: r.name, email: r.email, team_id: r.team?.id, default_location_id: r.location.id, default_building_id: r.building.id, default_floor_id: r.floor.id, fixed_desk_id: r.desk.id, role: "Employee", is_active: true, invitation_status: "Not Sent" });
        finalEmployeeByEmail.set(r.email, emp);
        newEmployeesCreated += 1;
      } else {
        emp = await base44.asServiceRole.entities.Employee.update(emp.id, { ...emp, email: r.email, name: r.name || emp.name, team_id: r.team?.id ?? emp.team_id, default_location_id: r.location.id, default_building_id: r.building.id, default_floor_id: r.floor.id, fixed_desk_id: r.desk.id, invitation_status: normalizeStatus(emp.invitation_status) });
        finalEmployeeByEmail.set(r.email, emp);
        existingEmployeesUpdated += 1;
      }
      await base44.asServiceRole.entities.Desk.update(r.desk.id, { desk_type: "Fixed", assigned_employee_id: emp.id, assigned_team_id: r.team?.id || "" });
      assignmentsApplied += 1;
    }

    const invitationResults = [];
    for (const r of parsedRows) {
      const emp = finalEmployeeByEmail.get(r.email);
      const res = await base44.functions.invoke('manageUserInvitation', { email: r.email, employeeRole: emp.role, employeeId: emp.id, sendEnabled: !!body.sendInvitations, forceResendPending: !!body.resendPending, forceResendExpiredOrFailed: !!body.resendExpiredOrFailed, source: 'FixedDeskImport', writeAudit: false });
      invitationResults.push({ rowNumber: r.rowNumber, ...(res.data || res) });
    }
    const finalInvitationSummary = summarizeInvitations(invitationResults);
    const warningErrors = invitationResults.filter((r) => r.action === 'failed').map((r) => `${r.normalizedEmail}: ${r.errorMessage}`);

    const log = await base44.asServiceRole.entities.ImportLog.create({
      executed_by: user.email,
      executed_at: executedAt,
      import_type: "FixedDeskImport",
      file_name: body.fileName || "",
      rows_processed: parsedRows.length,
      assignments_applied: assignmentsApplied,
      assignments_removed: assignmentsRemoved,
      new_employees_created: newEmployeesCreated,
      employees_losing_assignment: employeesLosingAssignment,
      employees_changing_assignment: employeesChangingAssignment,
      sendInvitationsRequested: !!body.sendInvitations,
      resendExpiredOrFailedRequested: !!body.resendExpiredOrFailed,
      resendPendingRequested: !!body.resendPending,
      ...finalInvitationSummary,
      invitationOutcomeSummary: JSON.stringify(finalInvitationSummary),
      rowInvitationOutcomes: JSON.stringify(invitationResults.slice(0, 200)),
      status: errors.length ? "Failed" : "Success",
      error_summary: [...errors, ...warningErrors].slice(0, 20).join(" | "),
    });

    await base44.asServiceRole.entities.AuditLog.create({
      actor_user_id: user.email,
      action_type: 'Fixed Desk Import Executed',
      affected_object_type: 'ImportLog',
      affected_object_id: log.id,
      summary: `Fixed Desk Import Executed: sendInvitations=${!!body.sendInvitations}, resendExpiredOrFailed=${!!body.resendExpiredOrFailed}, resendPending=${!!body.resendPending}, sent=${finalInvitationSummary.invitationsSentCount}, resent=${finalInvitationSummary.invitationsResentCount}, skippedActivated=${finalInvitationSummary.invitationsSkippedActivatedCount}, skippedPending=${finalInvitationSummary.invitationsSkippedPendingCount}, failed=${finalInvitationSummary.invitationsFailedCount}`,
      status: errors.length ? 'failed' : 'success',
      timestamp: executedAt,
    });

    return Response.json({ ok: true, importLogId: log.id, summary: { rowsProcessed: parsedRows.length, assignmentsApplied, assignmentsRemoved, newEmployeesCreated, existingEmployeesUpdated, employeesLosingAssignment, ...finalInvitationSummary }, invitationResults, partialErrors: warningErrors.length ? warningErrors : undefined });
  } catch (error) {
    return Response.json({ ok: false, errors: [error.message] }, { status: 500 });
  }
});
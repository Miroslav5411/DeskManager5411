import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

const normalizeEmail = (email = '') => String(email).trim().toLowerCase();
const normalizeStatus = (status) => {
  if (status === 'Sent') return 'Sent/Pending';
  return status || 'Not Sent';
};
const platformRoleFor = (role) => role === 'Admin' ? 'admin' : 'user';

function decideInvitation({ employee, email, employeeRole, sendEnabled, forceResendPending, forceResendExpiredOrFailed }) {
  const normalizedEmail = normalizeEmail(email);
  const platformRole = platformRoleFor(employeeRole || employee?.role || 'Employee');
  // Base44 platform User lookup is not exposed here, so activation is resolved from Employee fields only.
  // Activated status must be explicit and always overrides all invitation states.
  const before = employee?.invitation_status === 'Activated' ? 'Activated' : normalizeStatus(employee?.invitation_status);

  if (before === 'Activated') {
    return { normalizedEmail, platformRole, action: 'skipped', reason: 'already_activated', invitationStatusBefore: before, invitationStatusAfter: 'Activated' };
  }
  if (!sendEnabled) {
    return { normalizedEmail, platformRole, action: 'skipped', reason: 'send_disabled', invitationStatusBefore: before, invitationStatusAfter: before };
  }
  if (before === 'Sent/Pending' && !forceResendPending) {
    return { normalizedEmail, platformRole, action: 'skipped', reason: 'pending_skipped', invitationStatusBefore: before, invitationStatusAfter: before };
  }
  if ((before === 'Expired' || before === 'Failed') && !forceResendExpiredOrFailed) {
    return { normalizedEmail, platformRole, action: 'skipped', reason: before === 'Expired' ? 'expired_eligible' : 'failed_retry', invitationStatusBefore: before, invitationStatusAfter: before };
  }

  const resend = before === 'Sent/Pending' || before === 'Expired' || before === 'Failed';
  return {
    normalizedEmail,
    platformRole,
    action: resend ? 'resent' : 'sent',
    reason: before === 'Expired' ? 'expired_resend' : before === 'Failed' ? 'failed_retry' : before === 'Sent/Pending' ? 'pending_resend' : (employee ? 'not_sent' : 'new_user'),
    invitationStatusBefore: before,
    invitationStatusAfter: 'Sent/Pending',
  };
}

async function findEmployee(base44, normalizedEmail, employeeId) {
  if (employeeId) {
    const byId = await base44.asServiceRole.entities.Employee.filter({ id: employeeId });
    if (byId[0]) return byId[0];
  }
  const matches = await base44.asServiceRole.entities.Employee.filter({ email: normalizedEmail });
  return matches[0] || null;
}

async function audit(base44, { user, source, employee, result, manual }) {
  try {
    await base44.asServiceRole.entities.AuditLog.create({
      actor_user_id: user?.email || '',
      action_type: manual ? 'Manual Invitation Action' : 'Invitation Decision',
      affected_object_type: 'Employee',
      affected_object_id: employee?.id || '',
      summary: `${source || 'Manual'} invitation ${result.action}: ${result.normalizedEmail} (${result.reason})`,
      reason: result.errorMessage || '',
      status: result.action === 'failed' ? 'failed' : 'success',
      timestamp: new Date().toISOString(),
    });
  } catch (_e) { /* audit must not block invitation flow */ }
}

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const body = await req.json().catch(() => ({}));
    const normalizedEmail = normalizeEmail(body.email);
    if (!normalizedEmail) return Response.json({ error: 'Email is required' }, { status: 400 });

    const employee = await findEmployee(base44, normalizedEmail, body.employeeId);
    const sendEnabled = body.sendEnabled !== false;
    const decision = decideInvitation({
      employee,
      email: normalizedEmail,
      employeeRole: body.employeeRole,
      sendEnabled,
      forceResendPending: !!body.forceResendPending,
      forceResendExpiredOrFailed: !!body.forceResendExpiredOrFailed,
    });

    const result = {
      email: body.email,
      normalizedEmail,
      action: decision.action,
      reason: decision.reason,
      invitationStatusBefore: decision.invitationStatusBefore,
      invitationStatusAfter: decision.invitationStatusAfter,
      platformRole: decision.platformRole,
      errorMessage: '',
    };

    if (body.dryRun || decision.action === 'skipped') {
      if (!body.dryRun && employee && decision.invitationStatusAfter !== decision.invitationStatusBefore) {
        await base44.asServiceRole.entities.Employee.update(employee.id, { invitation_status: decision.invitationStatusAfter });
      }
      if (!body.dryRun && body.writeAudit !== false) await audit(base44, { user, source: body.source, employee, result, manual: body.source !== 'FixedDeskImport' });
      return Response.json(result);
    }

    try {
      await base44.users.inviteUser(normalizedEmail, decision.platformRole);
      const now = new Date().toISOString();
      if (employee) {
        await base44.asServiceRole.entities.Employee.update(employee.id, {
          invitation_status: 'Sent/Pending',
          last_invitation_sent_at: now,
          last_invitation_error: '',
          invitation_source: body.source === 'FixedDeskImport' ? 'FixedDeskImport' : (decision.action === 'resent' ? 'Resend' : 'Manual'),
        });
      }
      if (body.writeAudit !== false) await audit(base44, { user, source: body.source, employee, result, manual: body.source !== 'FixedDeskImport' });
      return Response.json(result);
    } catch (error) {
      const failed = { ...result, action: 'failed', reason: 'api_error', invitationStatusAfter: 'Failed', errorMessage: error.message };
      if (employee) {
        await base44.asServiceRole.entities.Employee.update(employee.id, {
          invitation_status: 'Failed',
          last_invitation_error: error.message,
          invitation_source: body.source === 'FixedDeskImport' ? 'FixedDeskImport' : 'Manual',
        });
      }
      if (body.writeAudit !== false) await audit(base44, { user, source: body.source, employee, result: failed, manual: body.source !== 'FixedDeskImport' });
      return Response.json(failed);
    }
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});
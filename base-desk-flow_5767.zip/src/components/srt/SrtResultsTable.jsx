import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

const statusStyle = {
  PASS: "bg-green-100 text-green-700 hover:bg-green-100",
  FAIL: "bg-red-100 text-red-700 hover:bg-red-100",
  WARNING: "bg-amber-100 text-amber-700 hover:bg-amber-100",
};

export default function SrtResultsTable({ rows, lastRun }) {
  if (!rows.length) {
    return <p className="rounded-2xl border bg-card p-8 text-center text-sm text-muted-foreground">No test results yet. Click "Run all tests" to start.</p>;
  }
  const ts = lastRun ? new Date(lastRun).toLocaleString() : "—";
  return (
    <Card className="rounded-3xl">
      <CardContent className="p-0">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-secondary text-xs uppercase tracking-wide text-muted-foreground">
              <tr>
                <th className="px-4 py-3 text-left">Test ID</th>
                <th className="px-4 py-3 text-left">Test name</th>
                <th className="px-4 py-3 text-left">Suite</th>
                <th className="px-4 py-3 text-left">Status</th>
                <th className="px-4 py-3 text-left">Details</th>
                <th className="px-4 py-3 text-left">Timestamp</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((r) => (
                <tr key={r.testId} className="border-t align-top">
                  <td className="whitespace-nowrap px-4 py-3 font-mono text-xs">{r.testId}</td>
                  <td className="px-4 py-3">{r.name}</td>
                  <td className="whitespace-nowrap px-4 py-3 text-muted-foreground">{r.suite}</td>
                  <td className="px-4 py-3"><Badge className={statusStyle[r.status] || ""}>{r.status}</Badge></td>
                  <td className="px-4 py-3 text-xs text-muted-foreground">{r.details || "—"}</td>
                  <td className="whitespace-nowrap px-4 py-3 text-xs text-muted-foreground">{ts}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </CardContent>
    </Card>
  );
}
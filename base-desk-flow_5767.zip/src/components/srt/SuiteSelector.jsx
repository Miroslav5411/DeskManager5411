import React from "react";
import { Checkbox } from "@/components/ui/checkbox";
import { Card, CardContent } from "@/components/ui/card";

export default function SuiteSelector({ suites, selected, onChange }) {
  const toggle = (key) => {
    if (selected.includes(key)) onChange(selected.filter((k) => k !== key));
    else onChange([...selected, key]);
  };
  return (
    <Card className="rounded-2xl">
      <CardContent className="p-4">
        <p className="mb-3 text-xs uppercase tracking-wide text-muted-foreground">Test suites</p>
        <div className="grid grid-cols-2 gap-2 md:grid-cols-4">
          {suites.map((s) => (
            <label key={s.key} className="flex items-center gap-2 rounded-lg border p-2 text-sm">
              <Checkbox checked={selected.includes(s.key)} onCheckedChange={() => toggle(s.key)} />
              <span>{s.label}</span>
            </label>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
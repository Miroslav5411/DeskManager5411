import React from "react";
import { Card, CardContent } from "@/components/ui/card";

const Card1 = ({ label, value, tone }) => (
  <Card className="rounded-2xl">
    <CardContent className="p-4">
      <p className="text-xs uppercase tracking-wide text-muted-foreground">{label}</p>
      <p className={`mt-1 text-2xl font-semibold ${tone || ""}`}>{value}</p>
    </CardContent>
  </Card>
);

export default function SrtSummaryCards({ summary, lastRun }) {
  return (
    <div className="mb-6 grid gap-3 md:grid-cols-3 lg:grid-cols-5">
      <Card1 label="Total tests" value={summary?.total ?? 0} />
      <Card1 label="Passed" value={summary?.passed ?? 0} tone="text-green-600" />
      <Card1 label="Failed" value={summary?.failed ?? 0} tone="text-red-600" />
      <Card1 label="Warnings" value={summary?.warnings ?? 0} tone="text-amber-600" />
      <Card1 label="Last run" value={lastRun ? new Date(lastRun).toLocaleString() : "—"} />
    </div>
  );
}
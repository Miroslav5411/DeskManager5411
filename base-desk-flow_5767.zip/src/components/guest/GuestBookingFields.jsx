import React from "react";
import { Input } from "@/components/ui/input";

export const emptyGuestBooking = {
  guest_name: "",
  guest_role_reason: "",
  guest_email: "",
  guest_phone: "",
  vehicle_plate_number: "",
};

const EMAIL_REGEX = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

export const hasRequiredGuestFields = (guest, includeVehicle = false) => {
  const baseFields = [guest.guest_name, guest.guest_role_reason, guest.guest_phone];
  const allTextFilled = baseFields.every((value) => value?.trim());
  const emailValid = !!guest.guest_email?.trim() && EMAIL_REGEX.test(guest.guest_email.trim());
  return allTextFilled && emailValid && (!includeVehicle || guest.vehicle_plate_number?.trim());
};

export default function GuestBookingFields({ guest, onChange, includeVehicle = false }) {
  const update = (field, value) => onChange({ ...guest, [field]: value });

  return (
    <div className="space-y-3 rounded-3xl border bg-secondary/40 p-4">
      <h3 className="font-semibold">Guest details</h3>
      <Input value={guest.guest_name} onChange={(event) => update("guest_name", event.target.value)} placeholder="Guest name" />
      <Input value={guest.guest_role_reason} onChange={(event) => update("guest_role_reason", event.target.value)} placeholder="Guest role / reason for visit" />
      <Input type="email" value={guest.guest_email} onChange={(event) => update("guest_email", event.target.value)} placeholder="Guest email" />
      <Input value={guest.guest_phone} onChange={(event) => update("guest_phone", event.target.value)} placeholder="Guest phone" />
      {includeVehicle && <Input value={guest.vehicle_plate_number} onChange={(event) => update("vehicle_plate_number", event.target.value)} placeholder="Vehicle plate number" />}
    </div>
  );
}
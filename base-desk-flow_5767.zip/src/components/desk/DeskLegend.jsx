import React from "react";

const items = [
  ["bg-muted", "Available"],
  ["bg-destructive", "Booked"],
  ["bg-accent", "Your booking"],
  ["bg-primary", "Fixed desk"],
  ["bg-foreground", "Blocked"],
];

export default function DeskLegend() {
  return (
    <div className="flex flex-wrap gap-3 text-xs text-muted-foreground">
      {items.map(([color, label]) => (
        <span key={label} className="inline-flex items-center gap-2">
          <span className={`h-3 w-3 rounded-full ${color}`} /> {label}
        </span>
      ))}
    </div>
  );
}
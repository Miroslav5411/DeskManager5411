import React from "react";
import { getRollingDateWindow } from "@/utils/dateWindow";

const dates = getRollingDateWindow();

export default function DateMultiSelect({ selectedDates, onChange }) {
  const toggleDate = (date) => {
    const next = selectedDates.includes(date)
      ? selectedDates.filter((item) => item !== date)
      : [...selectedDates, date].sort();
    onChange(next);
  };

  return (
    <div className="grid grid-cols-2 gap-2 sm:grid-cols-3 lg:grid-cols-5">
      {dates.map((date) => (
        <button
          key={date.key}
          type="button"
          onClick={() => toggleDate(date.key)}
          className={`rounded-2xl border px-3 py-2 text-left text-sm transition ${selectedDates.includes(date.key) ? "border-primary bg-primary text-primary-foreground" : "bg-card hover:border-primary"}`}
        >
          <span className="block font-medium">{date.label}</span>
          <span className="text-xs opacity-70">{date.key}</span>
        </button>
      ))}
    </div>
  );
}
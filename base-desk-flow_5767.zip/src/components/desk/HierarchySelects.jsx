import React from "react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

export default function HierarchySelects({ locations, buildings, floors, locationId, buildingId, floorId, onLocation, onBuilding, onFloor }) {
  const filteredBuildings = buildings.filter((building) => building.location_id === locationId && building.is_active !== false);
  const filteredFloors = floors.filter((floor) => floor.building_id === buildingId && floor.is_active !== false);

  return (
    <div className="grid gap-3 md:grid-cols-3">
      <Select value={locationId} onValueChange={onLocation}>
        <SelectTrigger><SelectValue placeholder="Location" /></SelectTrigger>
        <SelectContent>{locations.filter((item) => item.is_active !== false).map((item) => <SelectItem key={item.id} value={item.id}>{item.name}</SelectItem>)}</SelectContent>
      </Select>
      <Select value={buildingId} onValueChange={onBuilding} disabled={!locationId}>
        <SelectTrigger><SelectValue placeholder="Building" /></SelectTrigger>
        <SelectContent>{filteredBuildings.map((item) => <SelectItem key={item.id} value={item.id}>{item.name}</SelectItem>)}</SelectContent>
      </Select>
      <Select value={floorId} onValueChange={onFloor} disabled={!buildingId}>
        <SelectTrigger><SelectValue placeholder="Floor" /></SelectTrigger>
        <SelectContent>{filteredFloors.map((item) => <SelectItem key={item.id} value={item.id}>{item.name}</SelectItem>)}</SelectContent>
      </Select>
    </div>
  );
}
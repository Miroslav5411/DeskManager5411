import React, { useState } from "react";
import { getDeskAvailability, isGuestBooking } from "@/utils/deskFlow";
import { Button } from "@/components/ui/button";
import { ZoomIn, ZoomOut, RotateCcw } from "lucide-react";
import DeskLegend from "./DeskLegend";

// Desks are stored in the ORIGINAL (portrait) coordinate space. The floor image
// is rotated 90° CCW to lay horizontally, so markers must be transformed the same
// way the admin editor does (DeskMapCanvas): displayed_x = original_y, displayed_y = 100 - original_x.
const toDisplay = (x, y) => ({ x: y, y: 100 - x });

const DEFAULT_ZOOM = 1;
const MIN_ZOOM = 0.6;
const MAX_ZOOM = 3;
const ZOOM_STEP = 0.2;

export default function FloorDeskMap({ floor, desks, teams, employees = [], selectedDates, activeBookings, employeeId, selectedDeskId, onSelectDesk }) {
  const [zoom, setZoom] = useState(DEFAULT_ZOOM);
  const clampZoom = (value) => Math.min(MAX_ZOOM, Math.max(MIN_ZOOM, Math.round(value * 100) / 100));
  const zoomIn = () => setZoom((z) => clampZoom(z + ZOOM_STEP));
  const zoomOut = () => setZoom((z) => clampZoom(z - ZOOM_STEP));
  const resetZoom = () => setZoom(DEFAULT_ZOOM);
  const handleWheel = (event) => {
    if (!event.ctrlKey && !event.metaKey) return;
    event.preventDefault();
    setZoom((z) => clampZoom(z + (event.deltaY < 0 ? ZOOM_STEP : -ZOOM_STEP)));
  };

  const teamById = Object.fromEntries(teams.map((team) => [team.id, team]));
  const employeeById = Object.fromEntries(employees.map((employee) => [employee.id, employee]));

  const buttonStyle = (desk, state) => {
    if (state === "fixed") return { backgroundColor: teamById[desk.assigned_team_id]?.color || "#E30613", color: "white" };
    return undefined;
  };

  const buttonClass = (state, isSelected) => {
    const base = "absolute flex min-h-[15px] min-w-[15px] -translate-x-1/2 -translate-y-1/2 items-center justify-center rounded-full border px-[3px] text-[6px] font-semibold shadow-md transition";
    if (isSelected) return `${base} border-primary ring-4 ring-primary/20`;
    if (state === "available") return `${base} border-border bg-muted text-foreground hover:border-primary`;
    if (state === "booked") return `${base} border-destructive bg-destructive text-destructive-foreground`;
    if (state === "mine") return `${base} border-accent bg-accent text-accent-foreground`;
    if (state === "fixed") return `${base} border-white`;
    return `${base} border-foreground bg-foreground text-background`;
  };

  const getTitle = (desk, availability) => {
    if (availability.state === "fixed") {
      const assignedEmployee = employeeById[desk.assigned_employee_id];
      return assignedEmployee
        ? `${assignedEmployee.name}\n${assignedEmployee.email || "No email"}\nDesk: ${desk.code}`
        : `Fixed desk\nDesk: ${desk.code}`;
    }

    const booking = activeBookings.find((item) => item.desk_id === desk.id && selectedDates.includes(item.date));
    if (booking && isGuestBooking(booking)) {
      const host = employeeById[booking.host_employee_id || booking.employee_id]?.name || "Host";
      return `Guest: ${booking.guest_name}\nReason: ${booking.guest_role_reason}\nHost: ${host}\nDate: ${booking.date}\nDesk: ${desk.code}`;
    }
    return availability.conflicts?.length ? `Conflicts: ${availability.conflicts.join(", ")}` : desk.code;
  };

  return (
    <div className="space-y-4">
      <DeskLegend />
      <div className="relative w-full overflow-hidden rounded-3xl border bg-secondary" style={{ aspectRatio: "16 / 9" }} onWheel={handleWheel}>
        <div className="absolute right-3 top-3 z-20 flex items-center gap-1 rounded-full border bg-card/95 p-1 shadow-lg">
          <Button type="button" variant="ghost" size="icon" className="h-7 w-7 rounded-full" onClick={zoomOut} disabled={zoom <= MIN_ZOOM} title="Zoom out">
            <ZoomOut className="h-4 w-4" />
          </Button>
          <span className="min-w-[44px] text-center text-xs font-semibold tabular-nums">{Math.round(zoom * 100)}%</span>
          <Button type="button" variant="ghost" size="icon" className="h-7 w-7 rounded-full" onClick={zoomIn} disabled={zoom >= MAX_ZOOM} title="Zoom in">
            <ZoomIn className="h-4 w-4" />
          </Button>
          <Button type="button" variant="ghost" size="icon" className="h-7 w-7 rounded-full" onClick={resetZoom} title="Reset zoom">
            <RotateCcw className="h-4 w-4" />
          </Button>
        </div>
        <div className="absolute inset-0" style={{ transform: `scale(${zoom})`, transformOrigin: "center center" }}>
          {floor?.map_image_reference ? (
            <img src={floor.map_image_reference} alt={floor.name} className="absolute inset-0 h-full w-full object-contain opacity-80" style={{ transform: "rotate(-90deg)", transformOrigin: "center center" }} />
          ) : (
            <div className="absolute inset-0 bg-[linear-gradient(to_right,hsl(var(--border))_1px,transparent_1px),linear-gradient(to_bottom,hsl(var(--border))_1px,transparent_1px)] bg-[size:40px_40px]" />
          )}
          {desks.map((desk) => {
            const availability = getDeskAvailability({ desk, selectedDates, activeBookings, employeeId });
            const isSelected = desk.id === selectedDeskId;
            const disabled = availability.state !== "available";
            const display = toDisplay(desk.x_pos ?? 50, desk.y_pos ?? 50);
            return (
              <button
                key={desk.id}
                type="button"
                disabled={disabled}
                title={getTitle(desk, availability)}
                onClick={() => onSelectDesk(desk.id)}
                className={buttonClass(availability.state, isSelected)}
                style={{ left: `${display.x}%`, top: `${display.y}%`, ...buttonStyle(desk, availability.state) }}
              >
                {desk.code}
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
}
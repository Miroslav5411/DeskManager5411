import React from "react";
import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { getEmployeeByUser } from "@/utils/deskFlow";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

export default function EmployeeGate({ children }) {
  const { data, isLoading } = useQuery({
    queryKey: ["employee-access"],
    queryFn: async () => {
      const user = await base44.auth.me();
      const employees = await base44.entities.Employee.list();
      return { user, employee: getEmployeeByUser(employees, user) };
    },
  });

  if (isLoading) return <div className="py-12 text-center text-muted-foreground">Loading...</div>;

  if (!data?.employee) {
    return (
      <Card className="mx-auto max-w-xl rounded-3xl">
        <CardContent className="p-8 text-center">
          <h2 className="text-2xl font-semibold">Employee profile required</h2>
          <p className="mt-3 text-sm text-muted-foreground">Your login email must match an active employee record before using desk booking.</p>
          <Button className="mt-6" onClick={() => base44.auth.logout()}>Sign out</Button>
        </CardContent>
      </Card>
    );
  }

  return children(data);
}
import React from "react";
import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { normalizeEmail } from "@/utils/workspaceRules";

export default function AdminGate({ children }) {
  const { data, isLoading } = useQuery({
    queryKey: ["current-admin-profile"],
    queryFn: async () => {
      const user = await base44.auth.me();
      const employees = await base44.entities.Employee.filter({ email: normalizeEmail(user.email) });
      return { user, employee: employees[0] };
    },
  });

  if (isLoading) {
    return <div className="rounded-3xl border bg-card p-8 text-muted-foreground">Checking permissions...</div>;
  }

  const base44Admin = data?.user?.role === "Admin" || data?.user?.role === "admin";
  const employeeAdmin = data?.employee?.role === "Admin" && data?.employee?.is_active;

  if (!base44Admin && !employeeAdmin) {
    return (
      <div className="rounded-3xl border bg-card p-8">
        <h2 className="text-2xl font-semibold">Admin access required</h2>
        <p className="mt-2 text-muted-foreground">Only Admin users can access the workspace administration tools.</p>
      </div>
    );
  }

  return children;
}
import React from "react";
import { format, parseISO } from "date-fns";
import { CalendarDays, MessageSquareText, UserX } from "lucide-react";

// Single row in the "Unavailable Employees" admin dashboard.
// Receives a fully-resolved row: { employee, returnDate, reason, unavailableUntil }
export default function UnavailableEmployeeRow({ row }) {
  const { employee, returnDate, reason, unavailableUntil } = row;
  const formattedReturn = returnDate ? format(parseISO(returnDate), "EEE, MMM d, yyyy") : "—";
  const formattedUntil = unavailableUntil ? format(parseISO(unavailableUntil), "MMM d") : null;

  return (
    <div className="rounded-2xl border bg-card p-4 shadow-sm">
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <div className="flex items-center gap-2">
            <UserX className="h-4 w-4 text-primary" />
            <p className="truncate text-sm font-semibold">{employee.name}</p>
          </div>
          <p className="mt-0.5 truncate text-xs text-muted-foreground">{employee.email}</p>
        </div>
        <span className="shrink-0 rounded-full bg-primary/10 px-2.5 py-1 text-[11px] font-medium text-primary">
          Unavailable{formattedUntil ? ` · until ${formattedUntil}` : ""}
        </span>
      </div>

      <div className="mt-3 grid gap-2 text-xs">
        <div className="flex items-center gap-2">
          <CalendarDays className="h-3.5 w-3.5 text-muted-foreground" />
          <span className="text-muted-foreground">Returns:</span>
          <span className="font-medium text-foreground">{formattedReturn}</span>
        </div>
        <div className="flex items-start gap-2">
          <MessageSquareText className="mt-0.5 h-3.5 w-3.5 text-muted-foreground" />
          <span className="text-muted-foreground">Reason:</span>
          <span className="font-medium text-foreground">{reason || "—"}</span>
        </div>
      </div>
    </div>
  );
}
import React from "react";
import EmptyState from "@/components/common/EmptyState";
import StatusPill from "@/components/admin/StatusPill";
import InvitationActionButton from "./InvitationActionButton";
import InvitationStatusBlock from "./InvitationStatusBlock";
import { Button } from "@/components/ui/button";
import { UserX } from "lucide-react";

export default function EmployeesList({ employees, teams, onInvite, invitePendingId, onSetUnavailable, onToggleActive }) {
  if (employees.length === 0) return <EmptyState title="No employees yet" description="Create the first Admin business profile to unlock setup." />;
  return (
    <div className="space-y-3">
      {employees.map((employee) => (
        <div key={employee.id} className="rounded-2xl border p-4">
          <div className="flex items-start justify-between gap-3">
            <div>
              <p className="font-medium">{employee.name}</p>
              <p className="text-sm text-muted-foreground">{employee.email} · {employee.role}</p>
              <p className="text-xs text-muted-foreground">{teams.find((teamItem) => teamItem.id === employee.team_id)?.name || "No team"} · {employee.department || "No department"}</p>
              <InvitationStatusBlock employee={employee} />
            </div>
            <StatusPill active={employee.is_active} />
          </div>
          <div className="mt-4 flex flex-wrap gap-2">
            <InvitationActionButton employee={employee} onInvite={onInvite} disabled={invitePendingId === employee.id} />
            <Button size="sm" variant="outline" className="gap-1 rounded-full" onClick={() => onSetUnavailable(employee)}><UserX className="h-3.5 w-3.5" />Set Unavailable</Button>
            <Button size="sm" variant={employee.is_active ? "destructive" : "outline"} className="rounded-full" onClick={() => onToggleActive(employee)}>{employee.is_active ? "Deactivate" : "Reactivate"}</Button>
          </div>
        </div>
      ))}
    </div>
  );
}
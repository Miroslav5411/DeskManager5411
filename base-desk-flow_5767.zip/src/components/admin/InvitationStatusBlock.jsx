import React from "react";

const formatDate = (value) => value ? new Date(value).toLocaleString() : "—";

export default function InvitationStatusBlock({ employee }) {
  return (
    <div className="mt-2 space-y-1 text-xs text-muted-foreground">
      <p>Invitation Status: <span className="font-medium text-foreground">{employee.invitation_status || "Not Sent"}</span></p>
      <p>Last Invitation Sent: {formatDate(employee.last_invitation_sent_at)}</p>
      {employee.activated_at && <p>Activated At: {formatDate(employee.activated_at)}</p>}
      {employee.invitation_status === "Failed" && employee.last_invitation_error && (
        <p className="text-destructive">Last Error: {employee.last_invitation_error}</p>
      )}
    </div>
  );
}
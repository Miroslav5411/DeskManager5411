import React, { useState } from "react";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { NOTIFICATION_CATEGORIES, validateNotificationPayload } from "@/utils/notificationRules";

const blank = {
  title: "",
  body: "",
  category: "General",
  start_date: "",
  end_date: "",
  is_pinned: false,
  is_active: true,
};

export default function NotificationForm({ initial, onSubmit, onCancel, submitLabel = "Save" }) {
  const [form, setForm] = useState(() => ({ ...blank, ...(initial || {}) }));
  const [error, setError] = useState("");
  const [submitting, setSubmitting] = useState(false);

  const update = (patch) => setForm((prev) => ({ ...prev, ...patch }));

  const handleSubmit = async (e) => {
    e.preventDefault();
    const v = validateNotificationPayload(form);
    if (!v.ok) { setError(v.message); return; }
    setError("");
    setSubmitting(true);
    try {
      await onSubmit(form);
    } catch (err) {
      setError(err?.message || "Failed to save notification.");
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div>
        <Label htmlFor="notif-title">Title *</Label>
        <Input id="notif-title" value={form.title} onChange={(e) => update({ title: e.target.value })} placeholder="Short title" />
      </div>
      <div>
        <Label htmlFor="notif-body">Body *</Label>
        <Textarea id="notif-body" rows={5} value={form.body} onChange={(e) => update({ body: e.target.value })} placeholder="Full message shown to users" />
      </div>
      <div className="grid gap-4 md:grid-cols-3">
        <div>
          <Label>Category *</Label>
          <Select value={form.category} onValueChange={(v) => update({ category: v })}>
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>
              {NOTIFICATION_CATEGORIES.map((c) => <SelectItem key={c} value={c}>{c}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>
        <div>
          <Label htmlFor="notif-start">Start date *</Label>
          <Input id="notif-start" type="date" value={form.start_date || ""} onChange={(e) => update({ start_date: e.target.value })} />
        </div>
        <div>
          <Label htmlFor="notif-end">End date *</Label>
          <Input id="notif-end" type="date" value={form.end_date || ""} onChange={(e) => update({ end_date: e.target.value })} />
        </div>
      </div>
      <div className="flex flex-wrap items-center gap-6 pt-2">
        <div className="flex items-center gap-2">
          <Switch id="notif-pinned" checked={!!form.is_pinned} onCheckedChange={(v) => update({ is_pinned: v })} />
          <Label htmlFor="notif-pinned">Urgent / pinned</Label>
        </div>
        <div className="flex items-center gap-2">
          <Switch id="notif-active" checked={form.is_active !== false} onCheckedChange={(v) => update({ is_active: v })} />
          <Label htmlFor="notif-active">Active</Label>
        </div>
      </div>
      {error && <p className="text-sm text-destructive">{error}</p>}
      <div className="flex gap-2">
        <Button type="submit" disabled={submitting}>{submitting ? "Saving…" : submitLabel}</Button>
        {onCancel && <Button type="button" variant="outline" onClick={onCancel}>Cancel</Button>}
      </div>
    </form>
  );
}
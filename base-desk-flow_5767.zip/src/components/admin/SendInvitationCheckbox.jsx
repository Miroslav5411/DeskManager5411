import React from "react";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";

export default function SendInvitationCheckbox({ checked, onCheckedChange, disabled }) {
  return (
    <div className="flex items-center justify-between rounded-2xl border p-3 md:col-span-2">
      <Label>Send email invitation to sign up for the app</Label>
      <Switch checked={checked} onCheckedChange={onCheckedChange} disabled={disabled} />
    </div>
  );
}
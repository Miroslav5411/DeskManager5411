import React from "react";
import { Button } from "@/components/ui/button";

export default function InvitationActionButton({ employee, onInvite, disabled }) {
  const status = employee.invitation_status || "Not Sent";
  if (status === "Activated") {
    return <Button size="sm" variant="outline" className="rounded-full" disabled>Already activated — invitation not needed</Button>;
  }
  const label = status === "Failed" ? "Retry Invitation" : status === "Not Sent" ? "Send Invitation" : "Resend Invitation";
  return <Button size="sm" variant="outline" className="rounded-full" disabled={disabled} onClick={() => onInvite(employee)}>{label}</Button>;
}
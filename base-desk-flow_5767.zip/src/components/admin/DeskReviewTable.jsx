import React from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";

const deskTypes = ["Fixed", "Bookable", "Blocked"];

export default function DeskReviewTable({ desks, teams, selectedDeskId, onSelect, onUpdate, onDelete }) {
  if (!desks.length) return <p className="rounded-3xl border border-dashed p-6 text-center text-sm text-muted-foreground">No desks placed on this floor yet.</p>;

  return (
    <div className="overflow-hidden rounded-3xl border bg-card">
      <div className="grid grid-cols-12 gap-2 border-b bg-secondary px-4 py-3 text-xs font-semibold uppercase tracking-wide text-muted-foreground">
        <span className="col-span-2">Code</span><span className="col-span-2">Type</span><span className="col-span-2">Team</span><span className="col-span-1">X</span><span className="col-span-1">Y</span><span className="col-span-2">Active</span><span className="col-span-2">Actions</span>
      </div>
      {desks.map((desk) => (
        <div key={desk.id} className={`grid grid-cols-1 gap-2 border-b px-4 py-3 last:border-b-0 md:grid-cols-12 md:items-center ${selectedDeskId === desk.id ? "bg-primary/5" : ""}`}>
          <Input className="md:col-span-2" value={desk.code || ""} onFocus={() => onSelect(desk.id)} onChange={(e) => onUpdate(desk, { code: e.target.value })} />
          <Select value={desk.desk_type} onValueChange={(desk_type) => onUpdate(desk, { desk_type, assigned_team_id: desk_type === "Fixed" ? desk.assigned_team_id : "", assigned_employee_id: desk_type === "Fixed" ? desk.assigned_employee_id : "", block_reason: desk_type === "Blocked" ? desk.block_reason : "" })}><SelectTrigger className="md:col-span-2"><SelectValue /></SelectTrigger><SelectContent>{deskTypes.map((type) => <SelectItem key={type} value={type}>{type}</SelectItem>)}</SelectContent></Select>
          <Select value={desk.assigned_team_id || "none"} disabled={desk.desk_type !== "Fixed"} onValueChange={(assigned_team_id) => onUpdate(desk, { assigned_team_id: assigned_team_id === "none" ? "" : assigned_team_id })}><SelectTrigger className="md:col-span-2"><SelectValue /></SelectTrigger><SelectContent><SelectItem value="none">No team</SelectItem>{teams.map((team) => <SelectItem key={team.id} value={team.id}>{team.name}</SelectItem>)}</SelectContent></Select>
          <Input className="md:col-span-1" type="number" min="0" max="100" value={desk.x_pos} onChange={(e) => onUpdate(desk, { x_pos: Number(e.target.value) })} />
          <Input className="md:col-span-1" type="number" min="0" max="100" value={desk.y_pos} onChange={(e) => onUpdate(desk, { y_pos: Number(e.target.value) })} />
          <div className="flex items-center gap-2 md:col-span-2"><Switch checked={desk.is_active !== false} onCheckedChange={(is_active) => onUpdate(desk, { is_active })} /><span className="text-sm">{desk.is_active === false ? "Inactive" : "Active"}</span></div>
          <div className="flex gap-2 md:col-span-2"><Button size="sm" variant="outline" onClick={() => onSelect(desk.id)}>Select</Button><Button size="sm" variant="destructive" onClick={() => onDelete(desk.id)}>Delete</Button></div>
        </div>
      ))}
    </div>
  );
}
import React from "react";

export default function StatusPill({ active = true }) {
  return (
    <span className={`rounded-full px-3 py-1 text-xs font-medium ${active ? "bg-emerald-50 text-emerald-700" : "bg-muted text-muted-foreground"}`}>
      {active ? "Active" : "Inactive"}
    </span>
  );
}
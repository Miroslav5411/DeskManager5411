import React from "react";
import { Link } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { UserX, ArrowRight } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { todayStr, distinctUnavailableEmployees, UNAVAILABLE } from "@/utils/unavailableInsights";
import { isWithinRetention } from "@/utils/reportWindow";

// Small shortcut card for the Admin Dashboard linking to the Unavailable Insights tab.
export default function UnavailableInsightsShortcut() {
  const { data } = useQuery({
    queryKey: ["unavailable-insights-shortcut"],
    queryFn: async () => {
      const [statuses, employees] = await Promise.all([
        base44.entities.DailyWorkStatus.filter({ status_type: UNAVAILABLE }, "-date", 2000),
        base44.entities.Employee.list("-created_date", 5000),
      ]);
      return { statuses, employees };
    },
  });

  const today = todayStr();
  const retained = (data?.statuses || []).filter((s) => isWithinRetention(s.date));
  const todayCount = distinctUnavailableEmployees(retained, [today]);
  const activeCount = (data?.employees || []).filter((e) => e.is_active !== false).length;
  const pct = activeCount > 0 ? Math.round((todayCount / activeCount) * 1000) / 10 : 0;

  return (
    <Card className="rounded-3xl border-primary/20 bg-primary/5">
      <CardContent className="p-6">
        <div className="flex items-center gap-3">
          <div className="rounded-xl bg-primary/10 p-2 text-primary">
            <UserX className="h-5 w-5" />
          </div>
          <div>
            <p className="text-xs uppercase tracking-wide text-muted-foreground">Unavailable Insights</p>
            <h3 className="text-lg font-semibold">{todayCount} unavailable today · {pct}% of active</h3>
          </div>
        </div>
        <p className="mt-2 text-sm text-muted-foreground">
          See the full list, team breakdown, and holiday proximity analytics.
        </p>
        <Button asChild variant="outline" className="mt-3 gap-2">
          <Link to="/reports?tab=unavailable">Open Unavailable Insights <ArrowRight className="h-4 w-4" /></Link>
        </Button>
      </CardContent>
    </Card>
  );
}
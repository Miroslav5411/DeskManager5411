import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { ListChecks } from "lucide-react";

const Stat = ({ label, value }) => (
  <div className="rounded-xl border bg-card p-4">
    <p className="text-xs uppercase tracking-wide text-muted-foreground">{label}</p>
    <p className="mt-1 text-2xl font-semibold">{value}</p>
  </div>
);

export default function ImpactSummaryCard({ impact }) {
  if (!impact) return null;
  return (
    <Card className="rounded-2xl">
      <CardContent className="p-6">
        <h3 className="flex items-center gap-2 text-lg font-semibold">
          <ListChecks className="h-5 w-5" /> Impact summary — review before confirming
        </h3>
        <p className="mt-1 text-sm text-muted-foreground">
          This is what will happen if you confirm. The import replaces ALL fixed-desk assignments.
        </p>
        <div className="mt-4 grid gap-3 md:grid-cols-3 lg:grid-cols-5">
          <Stat label="Rows processed" value={impact.rowsProcessed} />
          <Stat label="Assignments applied" value={impact.assignmentsApplied} />
          <Stat label="Previous assignments removed" value={impact.assignmentsRemoved} />
          <Stat label="New employees" value={impact.newEmployees} />
          <Stat label="Employees losing desk" value={impact.employeesLosingAssignment} />
          <Stat label="Changing team" value={impact.employeesChangingTeam} />
          <Stat label="Changing location" value={impact.employeesChangingLocation} />
          <Stat label="Changing building" value={impact.employeesChangingBuilding} />
          <Stat label="Changing floor" value={impact.employeesChangingFloor} />
          <Stat label="Changing desk" value={impact.employeesChangingDesk} />
        </div>
      </CardContent>
    </Card>
  );
}
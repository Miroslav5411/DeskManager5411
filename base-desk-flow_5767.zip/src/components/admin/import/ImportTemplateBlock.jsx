import React from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Download, FileSpreadsheet } from "lucide-react";
import * as XLSX from "xlsx";
import { REQUIRED_COLUMNS, TEMPLATE_ROW } from "@/utils/fixedDeskImport";

export default function ImportTemplateBlock() {
  const handleDownload = () => {
    const ws = XLSX.utils.json_to_sheet([TEMPLATE_ROW], { header: REQUIRED_COLUMNS });
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "FixedDeskImport");
    XLSX.writeFile(wb, "fixed-desk-import-template.xlsx");
  };

  return (
    <Card className="rounded-2xl border-blue-200 bg-blue-50/40">
      <CardContent className="flex flex-col gap-3 p-6 md:flex-row md:items-center md:justify-between">
        <div className="flex items-start gap-3">
          <FileSpreadsheet className="mt-0.5 h-5 w-5 text-blue-700" />
          <div>
            <h3 className="font-semibold text-blue-900">Required columns</h3>
            <p className="mt-1 text-sm text-blue-900/80">
              {REQUIRED_COLUMNS.join(" · ")}
            </p>
            <p className="mt-1 text-xs text-blue-900/70">
              Only .xlsx files are accepted. Column names must match exactly.
            </p>
          </div>
        </div>
        <Button variant="outline" className="gap-2" onClick={handleDownload}>
          <Download className="h-4 w-4" /> Download template
        </Button>
      </CardContent>
    </Card>
  );
}
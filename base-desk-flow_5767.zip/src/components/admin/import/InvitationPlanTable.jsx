import React from "react";
import { Card, CardContent } from "@/components/ui/card";

const LABELS = {
  new_user: "New User — Will invite",
  not_sent: "Existing Employee — Not Sent — Will invite",
  already_activated: "Already Activated — Skipped",
  pending_skipped: "Invitation Sent/Pending — Skipped by default",
  pending_resend: "Invitation Sent/Pending — Will resend",
  expired_eligible: "Invitation Expired — Eligible for resend",
  expired_resend: "Invitation Expired — Will resend",
  failed_retry: "Invitation Failed — Eligible for retry",
  send_disabled: "Invitation disabled — no email will be sent",
  failed_retry_send: "Invitation Failed — Will retry",
  api_error: "Invitation failed",
};

export default function InvitationPlanTable({ plan = [] }) {
  if (!plan.length) return null;
  return (
    <Card className="rounded-2xl">
      <CardContent className="p-6">
        <h3 className="mb-4 text-lg font-semibold">Invitation preview</h3>
        <div className="max-h-80 overflow-auto rounded-xl border">
          <table className="w-full text-left text-sm">
            <thead className="bg-secondary text-xs uppercase text-muted-foreground">
              <tr><th className="p-3">Row</th><th className="p-3">Email</th><th className="p-3">Action</th></tr>
            </thead>
            <tbody>
              {plan.map((item) => (
                <tr key={`${item.rowNumber}-${item.normalizedEmail}`} className="border-t">
                  <td className="p-3">{item.rowNumber}</td>
                  <td className="p-3 font-mono text-xs">{item.normalizedEmail}</td>
                  <td className="p-3">{LABELS[item.reason] || item.reason}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </CardContent>
    </Card>
  );
}
import React from "react";

const Stat = ({ label, value }) => (
  <div className="rounded-xl border bg-card p-4">
    <p className="text-xs uppercase tracking-wide text-muted-foreground">{label}</p>
    <p className="mt-1 text-2xl font-semibold">{value || 0}</p>
  </div>
);

export default function InvitationSummaryGrid({ summary = {} }) {
  return (
    <div className="grid gap-3 md:grid-cols-3 lg:grid-cols-5">
      <Stat label="Invitations sent" value={summary.invitationsSentCount} />
      <Stat label="Resent" value={summary.invitationsResentCount} />
      <Stat label="Skipped activated" value={summary.invitationsSkippedActivatedCount} />
      <Stat label="Skipped pending" value={summary.invitationsSkippedPendingCount} />
      <Stat label="Failures" value={summary.invitationsFailedCount} />
    </div>
  );
}
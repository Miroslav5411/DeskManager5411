import React from "react";
import { ShieldAlert } from "lucide-react";

export default function RowErrorsList({ errors }) {
  if (!errors || errors.length === 0) return null;

  return (
    <div className="rounded-2xl border border-red-200 bg-red-50 p-5 text-red-900">
      <h3 className="flex items-center gap-2 font-semibold">
        <ShieldAlert className="h-5 w-5" /> {errors.length} row error{errors.length === 1 ? "" : "s"} — import is blocked
      </h3>
      <p className="mt-1 text-xs text-red-900/70">
        Fix every row below and re-upload. Nothing is changed until all rows are valid.
      </p>
      <ul className="mt-3 max-h-72 space-y-1 overflow-auto pr-2 text-sm">
        {errors.map((e, i) => (
          <li key={i} className="rounded bg-white/60 px-3 py-1.5">
            <span className="font-mono text-xs text-red-700">Row {e.row}</span>
            <span className="ml-2">{e.message}</span>
          </li>
        ))}
      </ul>
    </div>
  );
}
import React from "react";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";

export default function ImportInvitationOptions({ sendInvitations, setSendInvitations, resendExpiredOrFailed, setResendExpiredOrFailed, resendPending, setResendPending }) {
  return (
    <div className="space-y-3 rounded-2xl border p-4">
      <div className="flex items-center justify-between gap-4">
        <Label>Send email invitations to new users without an activated profile</Label>
        <Switch checked={sendInvitations} onCheckedChange={setSendInvitations} />
      </div>
      {sendInvitations && (
        <>
          <div className="flex items-center justify-between gap-4">
            <Label>Also resend invitations to users with expired or failed invitations</Label>
            <Switch checked={resendExpiredOrFailed} onCheckedChange={setResendExpiredOrFailed} />
          </div>
          <div className="flex items-center justify-between gap-4">
            <Label>Also resend invitations to users with pending invitations</Label>
            <Switch checked={resendPending} onCheckedChange={setResendPending} />
          </div>
        </>
      )}
    </div>
  );
}
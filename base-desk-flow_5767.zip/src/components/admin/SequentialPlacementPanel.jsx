import React from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";

const deskTypes = ["Bookable", "Fixed", "Blocked"];

export default function SequentialPlacementPanel({ config, setConfig, active, paused, progress, nextCode, onStart, onPause, onUndo }) {
  return (
    <div className="space-y-4 rounded-3xl border bg-secondary/60 p-4">
      <div>
        <h3 className="text-lg font-semibold">Sequential Desk Placement</h3>
        <p className="text-sm text-muted-foreground">Create a pending 1–69 desk checklist and click the map to place each desk.</p>
      </div>
      <div className="grid gap-3 md:grid-cols-2">
        <div><Label>Start desk number</Label><Input type="number" min="1" value={config.start} onChange={(e) => setConfig({ ...config, start: Number(e.target.value) })} /></div>
        <div><Label>End desk number</Label><Input type="number" min="1" value={config.end} onChange={(e) => setConfig({ ...config, end: Number(e.target.value) })} /></div>
      </div>
      <div className="grid gap-3 md:grid-cols-2">
        <div><Label>Default desk type</Label><Select value={config.desk_type} onValueChange={(desk_type) => setConfig({ ...config, desk_type })}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent>{deskTypes.map((type) => <SelectItem key={type} value={type}>{type}</SelectItem>)}</SelectContent></Select></div>
        <div className="flex items-center justify-between rounded-2xl border bg-card p-3"><Label>Default active status</Label><Switch checked={config.is_active} onCheckedChange={(is_active) => setConfig({ ...config, is_active })} /></div>
      </div>
      <div className="rounded-2xl bg-card p-3 text-sm">
        <p className="font-medium">Placed {progress.placed} of {progress.total} desks.</p>
        <p className="text-muted-foreground">Next desk: {active && !paused ? nextCode || "Complete" : "Not active"}</p>
      </div>
      <div className="flex flex-wrap gap-2">
        <Button onClick={onStart} disabled={config.start > config.end}>{active ? "Restart sequence" : "Start sequence"}</Button>
        <Button variant="outline" onClick={onPause} disabled={!active}>{paused ? "Resume" : "Pause"}</Button>
        <Button variant="outline" onClick={onUndo} disabled={progress.placed === 0}>Undo last marker</Button>
      </div>
    </div>
  );
}
import React from "react";

const items = [
  ["bg-muted border", "Bookable"],
  ["bg-primary", "Fixed / team color"],
  ["bg-foreground", "Blocked"],
  ["bg-muted border opacity-40", "Inactive"],
];

export default function DeskMapLegend() {
  return (
    <div className="flex flex-wrap gap-3 text-xs text-muted-foreground">
      {items.map(([color, label]) => (
        <span key={label} className="inline-flex items-center gap-2">
          <span className={`h-3 w-3 rounded-full ${color}`} /> {label}
        </span>
      ))}
    </div>
  );
}
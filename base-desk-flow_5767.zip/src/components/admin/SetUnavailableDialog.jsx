import React, { useEffect, useMemo, useState } from "react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import DateMultiSelect from "@/components/desk/DateMultiSelect";
import { AlertTriangle, CheckCircle2, Loader2, ShieldAlert, UserX } from "lucide-react";

// Focused, self-contained dialog for the Admin "Set User as Unavailable" action.
// Two-step flow: (1) pick dates -> Preview, (2) review impact -> Confirm.
export default function SetUnavailableDialog({ employee, open, onOpenChange, onSuccess }) {
  const [step, setStep] = useState("dates"); // "dates" | "review" | "done"
  const [selectedDates, setSelectedDates] = useState([]);
  const [reason, setReason] = useState("");
  const [preview, setPreview] = useState(null);
  const [executionResult, setExecutionResult] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    if (!open) {
      setStep("dates");
      setSelectedDates([]);
      setReason("");
      setPreview(null);
      setExecutionResult(null);
      setError("");
      setLoading(false);
    }
  }, [open]);

  const guestCount = useMemo(() => {
    if (!preview) return 0;
    return (preview.guestDeskBookings?.length || 0) + (preview.guestParkingBookings?.length || 0);
  }, [preview]);

  const callPreview = async () => {
    setError("");
    setLoading(true);
    try {
      const res = await base44.functions.invoke("setUserUnavailable", {
        action: "preview",
        employeeId: employee.id,
        dates: selectedDates,
      });
      if (res.data?.ok) {
        setPreview(res.data);
        setStep("review");
      } else {
        setError(res.data?.error || "Preview failed");
      }
    } catch (e) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  };

  const callExecute = async () => {
    setError("");
    setLoading(true);
    try {
      const res = await base44.functions.invoke("setUserUnavailable", {
        action: "execute",
        employeeId: employee.id,
        dates: selectedDates,
        reason,
      });
      if (res.data?.ok) {
        setExecutionResult(res.data);
        setStep("done");
        onSuccess?.(res.data);
      } else {
        setError(res.data?.error || "Execution failed");
      }
    } catch (e) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  };

  if (!employee) return null;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <UserX className="h-5 w-5 text-primary" />
            {step === "done" ? "Employee set as Unavailable" : "Set employee as Unavailable?"}
          </DialogTitle>
          <DialogDescription>
            {employee.name} · {employee.email}
          </DialogDescription>
        </DialogHeader>

        {step === "dates" && (
          <div className="space-y-4">
            <div className="rounded-2xl border border-amber-200 bg-amber-50 p-3 text-xs text-amber-900">
              <div className="flex items-center gap-2 font-medium"><ShieldAlert className="h-4 w-4" /> Admin-only action</div>
              <p className="mt-1 leading-snug">This affects another user. Their personal desk + parking bookings will be released and DailyWorkStatus will be set to Unavailable for the selected dates.</p>
            </div>
            <div>
              <Label className="text-sm">Select date(s) within the next 30 days</Label>
              <div className="mt-2 max-h-64 overflow-y-auto rounded-2xl border p-2">
                <DateMultiSelect selectedDates={selectedDates} onChange={setSelectedDates} />
              </div>
              <p className="mt-1 text-xs text-muted-foreground">{selectedDates.length} date(s) selected</p>
            </div>
            {error && <p className="text-sm font-medium text-destructive">{error}</p>}
          </div>
        )}

        {step === "review" && preview && (
          <div className="space-y-4 text-sm">
            <div className="rounded-2xl border bg-muted/30 p-3">
              <p className="font-medium">Selected date(s)</p>
              <p className="mt-1 text-muted-foreground">{preview.dates.join(", ")}</p>
            </div>

            <div className="rounded-2xl border p-3">
              <p className="font-medium">Personal desk bookings to release ({preview.personalDeskBookings.length})</p>
              {preview.personalDeskBookings.length === 0 ? (
                <p className="mt-1 text-xs text-muted-foreground">None</p>
              ) : (
                <ul className="mt-2 space-y-1 text-xs">
                  {preview.personalDeskBookings.map((b) => (
                    <li key={b.id} className="font-mono">{b.date} · desk {b.desk_id}</li>
                  ))}
                </ul>
              )}
            </div>

            <div className="rounded-2xl border p-3">
              <p className="font-medium">Personal parking bookings to release ({preview.personalParkingBookings.length})</p>
              {preview.personalParkingBookings.length === 0 ? (
                <p className="mt-1 text-xs text-muted-foreground">None</p>
              ) : (
                <ul className="mt-2 space-y-1 text-xs">
                  {preview.personalParkingBookings.map((b) => (
                    <li key={b.id} className="font-mono">{b.date} · space {b.parking_space_id}</li>
                  ))}
                </ul>
              )}
            </div>

            {guestCount > 0 && (
              <div className="rounded-2xl border border-amber-300 bg-amber-50 p-3 text-amber-900">
                <div className="flex items-center gap-2 font-medium"><AlertTriangle className="h-4 w-4" /> Guest bookings warning</div>
                <p className="mt-1 text-xs leading-snug">
                  This employee has guest bookings on one or more selected dates. Guest bookings will remain active and must be cancelled separately if needed.
                </p>
                <ul className="mt-2 space-y-1 text-xs">
                  {preview.guestDeskBookings.map((b) => (
                    <li key={`gd-${b.id}`} className="font-mono">{b.date} · desk · {b.guest_name}</li>
                  ))}
                  {preview.guestParkingBookings.map((b) => (
                    <li key={`gp-${b.id}`} className="font-mono">{b.date} · parking · {b.guest_name}</li>
                  ))}
                </ul>
              </div>
            )}

            <div>
              <Label className="text-sm">Reason (optional)</Label>
              <Input value={reason} onChange={(e) => setReason(e.target.value)} placeholder="Optional: written into AuditLog" />
            </div>

            {error && <p className="text-sm font-medium text-destructive">{error}</p>}
          </div>
        )}

        {step === "done" && executionResult && (
          <div className="space-y-3 text-sm">
            <div className="flex items-center gap-2 rounded-2xl border border-green-200 bg-green-50 p-3 text-green-800">
              <CheckCircle2 className="h-5 w-5" />
              <span>{executionResult.employee.name} set as Unavailable for {executionResult.dates.length} date(s).</span>
            </div>
            <ul className="rounded-2xl border p-3 text-xs">
              <li>Desk bookings released: <span className="font-mono">{executionResult.assignmentsReleased.desk}</span></li>
              <li>Parking bookings released: <span className="font-mono">{executionResult.assignmentsReleased.parking}</span></li>
              <li>DailyWorkStatus created: <span className="font-mono">{executionResult.statusesCreated}</span></li>
              <li>DailyWorkStatus updated: <span className="font-mono">{executionResult.statusesUpdated}</span></li>
              <li>Guest bookings preserved: <span className="font-mono">{executionResult.guestBookingsPreserved.desk}</span> desk, <span className="font-mono">{executionResult.guestBookingsPreserved.parking}</span> parking</li>
              <li>AuditLog id: <span className="font-mono">{executionResult.auditLogId || "—"}</span></li>
            </ul>
          </div>
        )}

        <DialogFooter>
          {step === "dates" && (
            <>
              <Button variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
              <Button onClick={callPreview} disabled={loading || selectedDates.length === 0} className="gap-2">
                {loading && <Loader2 className="h-4 w-4 animate-spin" />}
                Preview impact
              </Button>
            </>
          )}
          {step === "review" && (
            <>
              <Button variant="outline" onClick={() => setStep("dates")} disabled={loading}>Back</Button>
              <Button onClick={callExecute} disabled={loading} className="gap-2">
                {loading && <Loader2 className="h-4 w-4 animate-spin" />}
                Confirm and set Unavailable
              </Button>
            </>
          )}
          {step === "done" && (
            <Button onClick={() => onOpenChange(false)}>Close</Button>
          )}
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
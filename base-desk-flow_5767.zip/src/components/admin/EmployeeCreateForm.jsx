import React from "react";
import { Plus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import SendInvitationCheckbox from "./SendInvitationCheckbox";
import { ROLE_OPTIONS } from "@/utils/workspaceRules";

export default function EmployeeCreateForm({ employee, setEmployee, teams, employees, locations, filteredBuildings, filteredFloors, filteredDesks, duplicateEmail, sendInvitation, setSendInvitation, onCreate, creating }) {
  return (
    <div className="space-y-4">
      <h3 className="text-xl font-semibold">Add employee</h3>
      <div className="grid gap-4 md:grid-cols-2">
        <div><Label>Name</Label><Input value={employee.name} onChange={(e) => setEmployee({ ...employee, name: e.target.value })} /></div>
        <div><Label>Email</Label><Input type="email" value={employee.email} onChange={(e) => setEmployee({ ...employee, email: e.target.value })} /></div>
        <div><Label>Role (Admin-only)</Label><Select value={employee.role} onValueChange={(role) => setEmployee({ ...employee, role })}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent>{ROLE_OPTIONS.map((role) => <SelectItem key={role} value={role}>{role}</SelectItem>)}</SelectContent></Select></div>
        <div><Label>Team</Label><Select value={employee.team_id || "none"} onValueChange={(team_id) => setEmployee({ ...employee, team_id: team_id === "none" ? "" : team_id })}><SelectTrigger><SelectValue placeholder="Optional" /></SelectTrigger><SelectContent><SelectItem value="none">No team yet</SelectItem>{teams.map((t) => <SelectItem key={t.id} value={t.id}>{t.name}</SelectItem>)}</SelectContent></Select></div>
        <div><Label>Department</Label><Input value={employee.department} onChange={(e) => setEmployee({ ...employee, department: e.target.value })} /></div>
        <div><Label>Manager</Label><Select value={employee.manager_id || "none"} onValueChange={(manager_id) => setEmployee({ ...employee, manager_id: manager_id === "none" ? "" : manager_id })}><SelectTrigger><SelectValue placeholder="Optional" /></SelectTrigger><SelectContent><SelectItem value="none">No manager</SelectItem>{employees.map((manager) => <SelectItem key={manager.id} value={manager.id}>{manager.name}</SelectItem>)}</SelectContent></Select></div>
        <div><Label>Default Location</Label><Select value={employee.default_location_id || "none"} onValueChange={(default_location_id) => setEmployee({ ...employee, default_location_id: default_location_id === "none" ? "" : default_location_id, default_building_id: "", default_floor_id: "", fixed_desk_id: "" })}><SelectTrigger><SelectValue placeholder="Optional" /></SelectTrigger><SelectContent><SelectItem value="none">No default location</SelectItem>{locations.map((location) => <SelectItem key={location.id} value={location.id}>{location.name}</SelectItem>)}</SelectContent></Select></div>
        <div><Label>Default Building</Label><Select value={employee.default_building_id || "none"} onValueChange={(default_building_id) => setEmployee({ ...employee, default_building_id: default_building_id === "none" ? "" : default_building_id, default_floor_id: "", fixed_desk_id: "" })}><SelectTrigger><SelectValue placeholder="Optional" /></SelectTrigger><SelectContent><SelectItem value="none">No default building</SelectItem>{filteredBuildings.map((building) => <SelectItem key={building.id} value={building.id}>{building.name}</SelectItem>)}</SelectContent></Select></div>
        <div><Label>Default Floor</Label><Select value={employee.default_floor_id || "none"} onValueChange={(default_floor_id) => setEmployee({ ...employee, default_floor_id: default_floor_id === "none" ? "" : default_floor_id, fixed_desk_id: "" })}><SelectTrigger><SelectValue placeholder="Optional" /></SelectTrigger><SelectContent><SelectItem value="none">No default floor</SelectItem>{filteredFloors.map((floor) => <SelectItem key={floor.id} value={floor.id}>{floor.name}</SelectItem>)}</SelectContent></Select></div>
        <div><Label>Fixed Desk</Label><Select value={employee.fixed_desk_id || "none"} onValueChange={(fixed_desk_id) => setEmployee({ ...employee, fixed_desk_id: fixed_desk_id === "none" ? "" : fixed_desk_id })}><SelectTrigger><SelectValue placeholder="Optional" /></SelectTrigger><SelectContent><SelectItem value="none">No fixed desk</SelectItem>{filteredDesks.map((deskItem) => <SelectItem key={deskItem.id} value={deskItem.id}>{deskItem.code}</SelectItem>)}</SelectContent></Select></div>
        <SendInvitationCheckbox checked={sendInvitation} onCheckedChange={setSendInvitation} disabled={!employee.email || duplicateEmail} />
        <div className="flex items-center justify-between rounded-2xl border p-3"><Label>Active</Label><Switch checked={employee.is_active} onCheckedChange={(is_active) => setEmployee({ ...employee, is_active })} /></div>
      </div>
      {duplicateEmail && <p className="text-sm font-medium text-destructive">Email must be unique.</p>}
      <Button className="rounded-full" onClick={onCreate} disabled={!employee.name || !employee.email || duplicateEmail || creating}><Plus className="mr-2 h-4 w-4" />{creating ? "Creating..." : "Create employee"}</Button>
    </div>
  );
}
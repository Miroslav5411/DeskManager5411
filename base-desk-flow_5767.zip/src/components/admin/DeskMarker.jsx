import React from "react";

export default function DeskMarker({ desk, team, employee, selected, onSelect, onMove }) {
  const [dragging, setDragging] = React.useState(false);
  const [position, setPosition] = React.useState({ x_pos: desk.x_pos, y_pos: desk.y_pos });

  React.useEffect(() => {
    setPosition({ x_pos: desk.x_pos, y_pos: desk.y_pos });
  }, [desk.x_pos, desk.y_pos]);

  const innerClass = () => {
    const base = "flex items-center justify-center rounded-full border font-semibold shadow-md transition min-h-[15px] min-w-[15px] px-[3px] text-[6px] pointer-events-none";
    const state = selected ? "border-primary ring-4 ring-primary/25" : "border-white ring-1 ring-black/10";
    const inactive = desk.is_active === false ? "opacity-40" : "";
    if (desk.desk_type === "Blocked") return `${base} ${state} ${inactive} bg-foreground text-background`;
    if (desk.desk_type === "Fixed") return `${base} ${state} ${inactive} text-white`;
    return `${base} ${state} ${inactive} bg-muted text-foreground`;
  };

  const title = desk.desk_type === "Fixed" && employee
    ? `${employee.name}\n${employee.email || "No email"}\nDesk: ${desk.code}`
    : desk.code;

  const updateFromPointer = (event, commit) => {
    const rect = event.currentTarget.parentElement.getBoundingClientRect();
    const x_pos = Math.max(0, Math.min(100, Math.round(((event.clientX - rect.left) / rect.width) * 1000) / 10));
    const y_pos = Math.max(0, Math.min(100, Math.round(((event.clientY - rect.top) / rect.height) * 1000) / 10));
    setPosition({ x_pos, y_pos });
    if (commit) onMove(desk, x_pos, y_pos);
  };

  return (
    <button
      type="button"
      aria-label={title}
      title={title}
      className="absolute z-10 flex h-7 w-7 -translate-x-1/2 -translate-y-1/2 cursor-grab items-center justify-center rounded-full bg-transparent active:cursor-grabbing"
      style={{ left: `${position.x_pos}%`, top: `${position.y_pos}%` }}
      onClick={(event) => { event.stopPropagation(); onSelect(desk.id); }}
      onPointerDown={(event) => { event.stopPropagation(); setDragging(true); event.currentTarget.setPointerCapture(event.pointerId); }}
      onPointerMove={(event) => { if (dragging) updateFromPointer(event, false); }}
      onPointerUp={(event) => { event.stopPropagation(); if (dragging) updateFromPointer(event, true); setDragging(false); }}
    >
      <span
        className={innerClass()}
        style={{ backgroundColor: desk.desk_type === "Fixed" ? (team?.color || "#E30613") : undefined }}
      >
        {desk.code}
      </span>
    </button>
  );
}
import React, { useRef, useState } from "react";
import DeskMarker from "./DeskMarker";
import { Button } from "@/components/ui/button";
import { ZoomIn, ZoomOut, RotateCcw } from "lucide-react";

// The source floor image is portrait. We rotate it 90° counter-clockwise so it
// lays horizontally and fits the 16:9 canvas. Desk markers are stored in the
// ORIGINAL (portrait) coordinate space, so we transform them on render and on
// click — keeping persisted data unchanged.
//
// Rotation 90° CCW mapping (original portrait → rotated landscape):
//   displayed_x = original_y
//   displayed_y = 100 - original_x
// Inverse (click on rotated landscape → original portrait):
//   original_x = 100 - displayed_y
//   original_y = displayed_x

const toDisplay = (x, y) => ({ x_pos: y, y_pos: 100 - x });
const toOriginal = (x, y) => ({ x_pos: 100 - y, y_pos: x });

const DEFAULT_ZOOM = 1.45;
const MIN_ZOOM = 0.6;
const MAX_ZOOM = 3;
const ZOOM_STEP = 0.2;

export default function DeskMapCanvas({ floor, desks, teams, employees = [], selectedDeskId, onSelectDesk, onMapClick, onMoveDesk, placementHint }) {
  const imageRef = useRef(null);
  const [zoom, setZoom] = useState(DEFAULT_ZOOM);

  const clampZoom = (value) => Math.min(MAX_ZOOM, Math.max(MIN_ZOOM, Math.round(value * 100) / 100));
  const zoomIn = () => setZoom((z) => clampZoom(z + ZOOM_STEP));
  const zoomOut = () => setZoom((z) => clampZoom(z - ZOOM_STEP));
  const resetZoom = () => setZoom(DEFAULT_ZOOM);

  const handleClick = (event) => {
    if (!onMapClick) return;
    const target = imageRef.current || event.currentTarget;
    const rect = target.getBoundingClientRect();
    if (!rect.width || !rect.height) return;
    const displayX = Math.max(0, Math.min(100, Math.round(((event.clientX - rect.left) / rect.width) * 1000) / 10));
    const displayY = Math.max(0, Math.min(100, Math.round(((event.clientY - rect.top) / rect.height) * 1000) / 10));
    const original = toOriginal(displayX, displayY);
    onMapClick({ clientX: event.clientX, clientY: event.clientY, currentTarget: target, _computed: original });
  };

  const handleMoveDesk = (deskItem, displayX, displayY) => {
    if (!onMoveDesk) return;
    const original = toOriginal(displayX, displayY);
    onMoveDesk(deskItem, original.x_pos, original.y_pos);
  };

  const handleWheel = (event) => {
    if (!event.ctrlKey && !event.metaKey) return;
    event.preventDefault();
    setZoom((z) => clampZoom(z + (event.deltaY < 0 ? ZOOM_STEP : -ZOOM_STEP)));
  };

  return (
    <div className="relative w-full overflow-hidden rounded-3xl border bg-secondary">
      {placementHint && (
        <div className="absolute left-3 top-3 z-20 rounded-full border bg-card/95 px-3 py-1.5 text-xs font-semibold shadow-lg">
          {placementHint}
        </div>
      )}
      <div className="absolute right-3 top-3 z-20 flex items-center gap-1 rounded-full border bg-card/95 p-1 shadow-lg">
        <Button type="button" variant="ghost" size="icon" className="h-7 w-7 rounded-full" onClick={zoomOut} disabled={zoom <= MIN_ZOOM} title="Zoom out">
          <ZoomOut className="h-4 w-4" />
        </Button>
        <span className="min-w-[44px] text-center text-xs font-semibold tabular-nums">{Math.round(zoom * 100)}%</span>
        <Button type="button" variant="ghost" size="icon" className="h-7 w-7 rounded-full" onClick={zoomIn} disabled={zoom >= MAX_ZOOM} title="Zoom in">
          <ZoomIn className="h-4 w-4" />
        </Button>
        <Button type="button" variant="ghost" size="icon" className="h-7 w-7 rounded-full" onClick={resetZoom} title="Reset zoom">
          <RotateCcw className="h-4 w-4" />
        </Button>
      </div>
      <div className="relative w-full" style={{ aspectRatio: "16 / 9" }} onClick={handleClick} onWheel={handleWheel}>
        <div className="absolute inset-0" style={{ transform: `scale(${zoom})`, transformOrigin: "center center" }}>
          {floor?.map_image_reference ? (
            <img
              ref={imageRef}
              src={floor.map_image_reference}
              alt={floor.name}
              className="absolute inset-0 h-full w-full object-contain"
              style={{ transform: "rotate(-90deg)", transformOrigin: "center center" }}
              draggable={false}
            />
          ) : (
            <div className="absolute inset-0 grid place-items-center text-muted-foreground">No uploaded map image set</div>
          )}
          {desks.map((desk) => {
            const display = toDisplay(desk.x_pos, desk.y_pos);
            return (
              <DeskMarker
                key={desk.id}
                desk={{ ...desk, x_pos: display.x_pos, y_pos: display.y_pos }}
                team={teams.find((team) => team.id === desk.assigned_team_id)}
                employee={employees.find((employee) => employee.id === desk.assigned_employee_id)}
                selected={selectedDeskId === desk.id}
                onSelect={onSelectDesk}
                onMove={(_, x_pos, y_pos) => handleMoveDesk(desk, x_pos, y_pos)}
              />
            );
          })}
        </div>
      </div>
    </div>
  );
}
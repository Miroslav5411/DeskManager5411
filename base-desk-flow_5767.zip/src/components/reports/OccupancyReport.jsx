import React, { useState, useMemo } from "react";
import { isGuestBooking } from "@/utils/deskFlow";
import { getMonthOptions, isWithinRetention, getMonthRange } from "@/utils/reportWindow";
import { buildLookups, locationName, buildingName, floorName, isInMonth, toOptions } from "@/utils/reportData";
import { exportRowsToXlsx } from "@/utils/reportExport";
import KpiRow from "./KpiRow";
import ReportFilters from "./ReportFilters";
import ReportTable from "./ReportTable";

const ACTIVE_STATUS = new Set(["Active"]);

export default function OccupancyReport({ data }) {
  const [filters, setFilters] = useState({
    month: getMonthOptions()[0].key,
    location: "",
    building: "",
    floor: "",
  });

  const lookups = useMemo(() => buildLookups(data), [data]);

  const { rows, totalDays } = useMemo(() => {
    const range = getMonthRange(filters.month);
    const officeFloors = data.floors.filter((f) => f.type === "Office Floor" && f.is_active !== false);

    const grouped = {};
    officeFloors.forEach((floor) => {
      if (filters.location && floor.location_id !== filters.location) return;
      if (filters.building && floor.building_id !== filters.building) return;
      if (filters.floor && floor.id !== filters.floor) return;

      const desksOnFloor = data.desks.filter((d) => d.floor_id === floor.id);
      const bookable = desksOnFloor.filter((d) => d.desk_type === "Bookable" && d.is_active !== false);
      const fixed = desksOnFloor.filter((d) => d.desk_type === "Fixed" && d.is_active !== false);
      const blocked = desksOnFloor.filter((d) => d.desk_type === "Blocked" || d.is_active === false);

      const bookableIds = new Set(bookable.map((d) => d.id));
      const monthBookings = data.deskBookings.filter(
        (b) => ACTIVE_STATUS.has(b.status) && bookableIds.has(b.desk_id) && isWithinRetention(b.date) && isInMonth(b.date, filters.month) && b.date >= range.start && b.date <= range.end
      );

      const dateCounts = {};
      monthBookings.forEach((b) => {
        dateCounts[b.date] = (dateCounts[b.date] || 0) + 1;
      });
      const uniqueDays = Object.keys(dateCounts).length;
      const totalBookings = monthBookings.length;
      const peakEntry = Object.entries(dateCounts).sort((a, b) => b[1] - a[1])[0];
      const peakDay = peakEntry ? `${peakEntry[0]} (${peakEntry[1]})` : "—";
      const avgDaily = uniqueDays > 0 ? (totalBookings / uniqueDays).toFixed(1) : "0";
      const occupancyPct = bookable.length > 0 && uniqueDays > 0 ? `${Math.round((totalBookings / (bookable.length * uniqueDays)) * 100)}%` : "—";

      grouped[floor.id] = {
        id: floor.id,
        location: locationName(lookups, floor.location_id),
        building: buildingName(lookups, floor.building_id),
        floor: floor.name,
        bookable: bookable.length,
        fixed: fixed.length,
        blocked: blocked.length,
        total_bookings: totalBookings,
        unique_days: uniqueDays,
        avg_daily: avgDaily,
        peak_day: peakDay,
        occupancy_pct: occupancyPct,
      };
    });

    return { rows: Object.values(grouped), totalDays: 0 };
  }, [data, filters, lookups]);

  const kpis = useMemo(() => [
    { label: "Floors reported", value: rows.length },
    { label: "Bookable desks", value: rows.reduce((sum, r) => sum + r.bookable, 0) },
    { label: "Fixed desks", value: rows.reduce((sum, r) => sum + r.fixed, 0) },
    { label: "Blocked / Inactive", value: rows.reduce((sum, r) => sum + r.blocked, 0) },
    { label: "Active bookings", value: rows.reduce((sum, r) => sum + r.total_bookings, 0) },
  ], [rows]);

  const columns = [
    { header: "Location", accessor: "location" },
    { header: "Building", accessor: "building" },
    { header: "Floor", accessor: "floor" },
    { header: "Bookable desks", accessor: "bookable" },
    { header: "Fixed desks", accessor: "fixed" },
    { header: "Blocked / Inactive", accessor: "blocked" },
    { header: "Active bookings", accessor: "total_bookings" },
    { header: "Unique booking days", accessor: "unique_days" },
    { header: "Avg daily occupancy", accessor: "avg_daily" },
    { header: "Peak day", accessor: "peak_day" },
    { header: "Occupancy %", accessor: "occupancy_pct" },
  ];

  const filteredBuildings = data.buildings.filter((b) => !filters.location || b.location_id === filters.location);
  const filteredFloors = data.floors.filter((f) => f.type === "Office Floor" && (!filters.location || f.location_id === filters.location) && (!filters.building || f.building_id === filters.building));

  const fields = [
    { key: "location", label: "Location", options: toOptions(data.locations) },
    { key: "building", label: "Building", options: toOptions(filteredBuildings) },
    { key: "floor", label: "Floor", options: toOptions(filteredFloors) },
  ];

  const handleExport = () => {
    exportRowsToXlsx({
      rows,
      columns,
      sheetName: "Occupancy",
      fileName: `occupancy-${filters.month}.xlsx`,
    });
  };

  return (
    <div>
      <KpiRow kpis={kpis} />
      <ReportFilters filters={filters} onChange={setFilters} fields={fields} onExport={handleExport} exportDisabled={!rows.length} />
      <ReportTable columns={columns} rows={rows} emptyMessage="No floors match the filters." />
    </div>
  );
}
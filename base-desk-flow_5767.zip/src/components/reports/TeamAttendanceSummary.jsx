import React, { useState, useMemo } from "react";
import { getMonthOptions, isWithinRetention } from "@/utils/reportWindow";
import { buildLookups, isInMonth, toOptions } from "@/utils/reportData";
import { exportRowsToXlsx } from "@/utils/reportExport";
import KpiRow from "./KpiRow";
import ReportFilters from "./ReportFilters";
import ReportTable from "./ReportTable";

const ALLOWED_STATUSES = new Set(["Office", "Home Office", "Unavailable"]);

const pct = (n, d) => (d > 0 ? `${Math.round((n / d) * 100)}%` : "0%");

export default function TeamAttendanceSummary({ data }) {
  const [filters, setFilters] = useState({
    month: getMonthOptions()[0].key,
    team: "",
    location: "",
    building: "",
  });

  const lookups = useMemo(() => buildLookups(data), [data]);

  const rows = useMemo(() => {
    const teams = filters.team ? data.teams.filter((t) => t.id === filters.team) : data.teams;
    const statuses = data.dailyStatuses
      .filter((s) => ALLOWED_STATUSES.has(s.status_type))
      .filter((s) => isWithinRetention(s.date) && isInMonth(s.date, filters.month))
      .filter((s) => !filters.location || s.location_id === filters.location)
      .filter((s) => !filters.building || s.building_id === filters.building);

    return teams
      .filter((t) => t.is_active !== false)
      .map((team) => {
        const teamEmpIds = new Set(data.employees.filter((e) => e.team_id === team.id).map((e) => e.id));
        const teamStatuses = statuses.filter((s) => teamEmpIds.has(s.employee_id));
        const office = teamStatuses.filter((s) => s.status_type === "Office").length;
        const home = teamStatuses.filter((s) => s.status_type === "Home Office").length;
        const unavailable = teamStatuses.filter((s) => s.status_type === "Unavailable").length;
        const total = teamStatuses.length;
        return {
          id: team.id,
          team: team.name,
          office,
          home,
          unavailable,
          total,
          office_pct: pct(office, total),
          home_pct: pct(home, total),
          unavailable_pct: pct(unavailable, total),
        };
      })
      .filter((r) => r.total > 0)
      .sort((a, b) => a.team.localeCompare(b.team));
  }, [data, filters, lookups]);

  const kpis = useMemo(() => [
    { label: "Teams reported", value: rows.length },
    { label: "Office", value: rows.reduce((s, r) => s + r.office, 0) },
    { label: "Home Office", value: rows.reduce((s, r) => s + r.home, 0) },
    { label: "Unavailable", value: rows.reduce((s, r) => s + r.unavailable, 0) },
    { label: "Total status records", value: rows.reduce((s, r) => s + r.total, 0) },
  ], [rows]);

  const columns = [
    { header: "Team", accessor: "team" },
    { header: "Office", accessor: "office" },
    { header: "Home Office", accessor: "home" },
    { header: "Unavailable", accessor: "unavailable" },
    { header: "Total records", accessor: "total" },
    { header: "Office %", accessor: "office_pct" },
    { header: "Home Office %", accessor: "home_pct" },
    { header: "Unavailable %", accessor: "unavailable_pct" },
  ];

  const filteredBuildings = data.buildings.filter((b) => !filters.location || b.location_id === filters.location);

  const fields = [
    { key: "team", label: "Team", options: toOptions(data.teams) },
    { key: "location", label: "Location", options: toOptions(data.locations) },
    { key: "building", label: "Building", options: toOptions(filteredBuildings) },
  ];

  const handleExport = () => {
    exportRowsToXlsx({
      rows,
      columns,
      sheetName: "Team Attendance",
      fileName: `team-attendance-${filters.month}.xlsx`,
    });
  };

  return (
    <div>
      <KpiRow kpis={kpis} />
      <ReportFilters filters={filters} onChange={setFilters} fields={fields} onExport={handleExport} exportDisabled={!rows.length} />
      <ReportTable columns={columns} rows={rows} emptyMessage="No team attendance records match the filters." />
    </div>
  );
}
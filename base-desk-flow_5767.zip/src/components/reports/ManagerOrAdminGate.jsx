import React from "react";
import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { normalizeEmail } from "@/utils/workspaceRules";

export default function ManagerOrAdminGate({ children }) {
  const { data, isLoading } = useQuery({
    queryKey: ["current-manager-or-admin"],
    queryFn: async () => {
      const user = await base44.auth.me();
      const employees = await base44.entities.Employee.filter({ email: normalizeEmail(user.email) });
      return { user, employee: employees[0] };
    },
  });

  if (isLoading) {
    return <div className="rounded-3xl border bg-card p-8 text-muted-foreground">Checking permissions...</div>;
  }

  const role = data?.employee?.role;
  const allowed = data?.employee?.is_active && (role === "Admin" || role === "Team Manager");
  const platformAdmin = data?.user?.role === "Admin" || data?.user?.role === "admin";

  if (!allowed && !platformAdmin) {
    return (
      <div className="rounded-3xl border bg-card p-8">
        <h2 className="text-2xl font-semibold">Reports access required</h2>
        <p className="mt-2 text-muted-foreground">Reports & Analytics is available to Team Managers and Admins only.</p>
      </div>
    );
  }

  return children;
}
import React, { useState, useMemo } from "react";
import { isGuestBooking } from "@/utils/deskFlow";
import { getMonthOptions, isWithinRetention } from "@/utils/reportWindow";
import { buildLookups, employeeName, teamName, locationName, buildingName, formatTimestamp, isInMonth, toOptions } from "@/utils/reportData";
import { exportRowsToXlsx } from "@/utils/reportExport";
import KpiRow from "./KpiRow";
import ReportFilters from "./ReportFilters";
import ReportTable from "./ReportTable";

const TYPE_OPTIONS = [
  { value: "Desk", label: "Desk" },
  { value: "Parking", label: "Parking" },
];

const STATUS_OPTIONS = [
  { value: "Active", label: "Active" },
  { value: "Cancelled", label: "Cancelled" },
  { value: "Released by User", label: "Released by User" },
  { value: "Cancelled by Host", label: "Cancelled by Host" },
];

export default function GuestBookingsReport({ data }) {
  const [filters, setFilters] = useState({
    month: getMonthOptions()[0].key,
    booking_type: "",
    host: "",
    team: "",
    location: "",
    building: "",
    status: "",
  });

  const lookups = useMemo(() => buildLookups(data), [data]);

  const rows = useMemo(() => {
    const buildRow = (b, type) => {
      const hostId = b.host_employee_id || b.employee_id;
      return {
        id: `${type}-${b.id}`,
        booking_type: type,
        date: b.date,
        host: employeeName(lookups, hostId),
        host_team: teamName(lookups, lookups.employee(hostId)?.team_id),
        guest_name: b.guest_name || "—",
        guest_role: b.guest_role_reason || "",
        guest_email: b.guest_email || "",
        guest_phone: b.guest_phone || "",
        location: locationName(lookups, b.location_id),
        building: buildingName(lookups, b.building_id),
        floor_zone: type === "Desk" ? lookups.floor(b.floor_id)?.name || "—" : lookups.floor(b.floor_zone_id)?.name || "—",
        resource: type === "Desk" ? lookups.desk(b.desk_id)?.code || "—" : lookups.parkingSpace(b.parking_space_id)?.code || "—",
        plate: type === "Parking" ? b.vehicle_plate_number || "" : "",
        status: b.status,
        created_at: formatTimestamp(b.created_date),
        cancelled_at: formatTimestamp(b.cancelled_at),
        host_id: hostId,
      };
    };

    const desks = data.deskBookings.filter(isGuestBooking).map((b) => buildRow(b, "Desk"));
    const parking = data.parkingBookings.filter(isGuestBooking).map((b) => buildRow(b, "Parking"));

    return [...desks, ...parking]
      .filter((r) => isWithinRetention(r.date) && isInMonth(r.date, filters.month))
      .filter((r) => !filters.booking_type || r.booking_type === filters.booking_type)
      .filter((r) => !filters.host || r.host_id === filters.host)
      .filter((r) => !filters.team || lookups.employee(r.host_id)?.team_id === filters.team)
      .filter((r) => !filters.location || locationName(lookups, lookups.employee(r.host_id)?.default_location_id) === filters.location || r.location === locationName(lookups, filters.location))
      .filter((r) => !filters.building || r.building === buildingName(lookups, filters.building))
      .filter((r) => !filters.status || r.status === filters.status)
      .sort((a, b) => a.date.localeCompare(b.date) || a.host.localeCompare(b.host));
  }, [data, filters, lookups]);

  const kpis = useMemo(() => [
    { label: "Total guest bookings", value: rows.length },
    { label: "Guest desk", value: rows.filter((r) => r.booking_type === "Desk").length },
    { label: "Guest parking", value: rows.filter((r) => r.booking_type === "Parking").length },
    { label: "Active", value: rows.filter((r) => r.status === "Active").length },
    { label: "Released / Cancelled", value: rows.filter((r) => r.status !== "Active").length },
  ], [rows]);

  const columns = [
    { header: "Type", accessor: "booking_type" },
    { header: "Date", accessor: "date" },
    { header: "Host", accessor: "host" },
    { header: "Host team", accessor: "host_team" },
    { header: "Guest", accessor: "guest_name" },
    { header: "Reason", accessor: "guest_role" },
    { header: "Email", accessor: "guest_email" },
    { header: "Phone", accessor: "guest_phone" },
    { header: "Location", accessor: "location" },
    { header: "Building", accessor: "building" },
    { header: "Floor / Zone", accessor: "floor_zone" },
    { header: "Resource", accessor: "resource" },
    { header: "Vehicle plate", accessor: "plate" },
    { header: "Status", accessor: "status" },
    { header: "Created", accessor: "created_at" },
    { header: "Cancelled at", accessor: "cancelled_at" },
  ];

  const fields = [
    { key: "booking_type", label: "Booking type", options: TYPE_OPTIONS },
    { key: "host", label: "Host", options: toOptions(data.employees) },
    { key: "team", label: "Host team", options: toOptions(data.teams) },
    { key: "location", label: "Location", options: toOptions(data.locations) },
    { key: "building", label: "Building", options: toOptions(data.buildings) },
    { key: "status", label: "Status", options: STATUS_OPTIONS },
  ];

  const handleExport = () => {
    exportRowsToXlsx({
      rows,
      columns,
      sheetName: "Guest Bookings",
      fileName: `guest-bookings-${filters.month}.xlsx`,
    });
  };

  return (
    <div>
      <KpiRow kpis={kpis} />
      <ReportFilters filters={filters} onChange={setFilters} fields={fields} onExport={handleExport} exportDisabled={!rows.length} />
      <ReportTable columns={columns} rows={rows} emptyMessage="No guest bookings match the filters." />
    </div>
  );
}
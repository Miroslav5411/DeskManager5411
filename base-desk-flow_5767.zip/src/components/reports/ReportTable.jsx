import React from "react";
import { Card, CardContent } from "@/components/ui/card";

export default function ReportTable({ columns, rows, emptyMessage = "No records." }) {
  return (
    <Card className="rounded-3xl">
      <CardContent className="p-0">
        {rows.length === 0 ? (
          <p className="p-8 text-center text-sm text-muted-foreground">{emptyMessage}</p>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-secondary text-xs uppercase tracking-wide text-muted-foreground">
                <tr>
                  {columns.map((col) => (
                    <th key={col.header} className="whitespace-nowrap px-4 py-3 text-left">
                      {col.header}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {rows.map((row, idx) => (
                  <tr key={row.id || idx} className="border-t">
                    {columns.map((col) => {
                      const value = typeof col.accessor === "function" ? col.accessor(row) : row[col.accessor];
                      return (
                        <td key={col.header} className="whitespace-nowrap px-4 py-3">
                          {value || "—"}
                        </td>
                      );
                    })}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, LineChart, Line, CartesianGrid, Legend } from "recharts";

const ChartCard = ({ title, children }) => (
  <Card className="rounded-2xl">
    <CardContent className="p-4">
      <p className="mb-3 text-xs uppercase tracking-wide text-muted-foreground">{title}</p>
      <div className="h-64 w-full">
        <ResponsiveContainer width="100%" height="100%">{children}</ResponsiveContainer>
      </div>
    </CardContent>
  </Card>
);

export default function UnavailableCharts({ byDay, byTeam, holidayChart }) {
  return (
    <div className="grid gap-4 md:grid-cols-2">
      <ChartCard title="Unavailable count by day">
        <LineChart data={byDay}>
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis dataKey="date" tick={{ fontSize: 11 }} />
          <YAxis allowDecimals={false} tick={{ fontSize: 11 }} />
          <Tooltip />
          <Line type="monotone" dataKey="count" stroke="#E30613" strokeWidth={2} dot={false} />
        </LineChart>
      </ChartCard>

      <ChartCard title="Unavailable count by team (this month)">
        <BarChart data={byTeam}>
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis dataKey="team" tick={{ fontSize: 11 }} />
          <YAxis allowDecimals={false} tick={{ fontSize: 11 }} />
          <Tooltip />
          <Bar dataKey="count" fill="#E30613" />
        </BarChart>
      </ChartCard>

      <ChartCard title="Unavailable percentage by team (today)">
        <BarChart data={byTeam}>
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis dataKey="team" tick={{ fontSize: 11 }} />
          <YAxis tick={{ fontSize: 11 }} unit="%" />
          <Tooltip />
          <Bar dataKey="pctToday" fill="#F4B400" />
        </BarChart>
      </ChartCard>

      <ChartCard title="Unavailable around holidays">
        <BarChart data={holidayChart}>
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis dataKey="holidayName" tick={{ fontSize: 11 }} />
          <YAxis allowDecimals={false} tick={{ fontSize: 11 }} />
          <Tooltip />
          <Legend />
          <Bar dataKey="prev2Count" name="2 days before" fill="#E30613" />
          <Bar dataKey="next2Count" name="2 days after" fill="#F4B400" />
        </BarChart>
      </ChartCard>
    </div>
  );
}
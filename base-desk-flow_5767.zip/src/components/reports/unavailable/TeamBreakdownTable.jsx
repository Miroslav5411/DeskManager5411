import React from "react";
import ReportTable from "@/components/reports/ReportTable";

export default function TeamBreakdownTable({ rows }) {
  const columns = [
    { header: "Team", accessor: "team" },
    { header: "Active employees", accessor: "active" },
    { header: "Unavailable today", accessor: "today" },
    { header: "Unavailable this week", accessor: "week" },
    { header: "Unavailable this month", accessor: "month" },
    { header: "% today", accessor: "pctToday" },
    { header: "% this week", accessor: "pctWeek" },
  ];
  return <ReportTable columns={columns} rows={rows} emptyMessage="No team data." />;
}
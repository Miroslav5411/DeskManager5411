import React from "react";
import ReportTable from "@/components/reports/ReportTable";

export default function HolidayProximityTable({ rows }) {
  const columns = [
    { header: "Holiday", accessor: "holidayName" },
    { header: "Date", accessor: "holidayDate" },
    { header: "Prev working day", accessor: "prevWorkingDay" },
    { header: "Unavailable on prev", accessor: "prevCount" },
    { header: "On holiday", accessor: "onCount" },
    { header: "Next working day", accessor: "nextWorkingDay" },
    { header: "Unavailable on next", accessor: "nextCount" },
    { header: "Within 2 working days before", accessor: "prev2Count" },
    { header: "Within 2 working days after", accessor: "next2Count" },
    { header: "% around holiday", accessor: (r) => `${r.aroundPct}%` },
  ];
  return <ReportTable columns={columns} rows={rows} emptyMessage="No public holidays configured. Add holidays under Admin → Public Holidays." />;
}
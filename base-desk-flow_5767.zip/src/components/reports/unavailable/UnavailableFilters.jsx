import React from "react";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Download } from "lucide-react";
import { format } from "date-fns";
import { getRetentionCutoffDate } from "@/utils/reportWindow";
import { todayStr } from "@/utils/unavailableInsights";

const ALL = "__all";

const Field = ({ label, value, onChange, options, placeholder }) => (
  <div>
    <Label className="text-xs uppercase tracking-wide text-muted-foreground">{label}</Label>
    <Select value={value || ALL} onValueChange={(v) => onChange(v === ALL ? "" : v)}>
      <SelectTrigger className="mt-1">
        <SelectValue placeholder={placeholder} />
      </SelectTrigger>
      <SelectContent>
        <SelectItem value={ALL}>All</SelectItem>
        {options.map((option) => (
          <SelectItem key={option.value} value={option.value}>
            {option.label}
          </SelectItem>
        ))}
      </SelectContent>
    </Select>
  </div>
);

const SOURCE_OPTIONS = [
  { value: "Manual", label: "Manual" },
  { value: "Admin Set", label: "Admin Set" },
];

export default function UnavailableFilters({ filters, onChange, optionLists, onExport, exportDisabled }) {
  const minDate = format(getRetentionCutoffDate(), "yyyy-MM-dd");
  const maxDate = todayStr();

  return (
    <div className="mb-6 rounded-2xl border bg-card p-4">
      <div className="grid grid-cols-1 gap-4 md:grid-cols-3 lg:grid-cols-4">
        <div>
          <Label className="text-xs uppercase tracking-wide text-muted-foreground">Date</Label>
          <Input
            type="date"
            min={minDate}
            max={maxDate}
            value={filters.dateExact || ""}
            onChange={(e) => onChange({ ...filters, dateExact: e.target.value, dateFrom: "", dateTo: "" })}
          />
        </div>
        <div>
          <Label className="text-xs uppercase tracking-wide text-muted-foreground">From</Label>
          <Input
            type="date"
            min={minDate}
            max={maxDate}
            value={filters.dateFrom || ""}
            onChange={(e) => onChange({ ...filters, dateFrom: e.target.value, dateExact: "" })}
          />
        </div>
        <div>
          <Label className="text-xs uppercase tracking-wide text-muted-foreground">To</Label>
          <Input
            type="date"
            min={minDate}
            max={maxDate}
            value={filters.dateTo || ""}
            onChange={(e) => onChange({ ...filters, dateTo: e.target.value, dateExact: "" })}
          />
        </div>
        <Field label="Source" value={filters.source} onChange={(v) => onChange({ ...filters, source: v })} options={SOURCE_OPTIONS} placeholder="Source" />
        <Field label="Team" value={filters.team} onChange={(v) => onChange({ ...filters, team: v })} options={optionLists.teams} placeholder="Team" />
        <Field label="Department" value={filters.department} onChange={(v) => onChange({ ...filters, department: v })} options={optionLists.departments} placeholder="Department" />
        <Field label="Manager" value={filters.manager} onChange={(v) => onChange({ ...filters, manager: v })} options={optionLists.managers} placeholder="Manager" />
        <Field label="Location" value={filters.location} onChange={(v) => onChange({ ...filters, location: v })} options={optionLists.locations} placeholder="Location" />
        <Field label="Building" value={filters.building} onChange={(v) => onChange({ ...filters, building: v })} options={optionLists.buildings} placeholder="Building" />
      </div>

      {onExport && (
        <div className="mt-4 flex justify-end">
          <Button onClick={onExport} disabled={exportDisabled} className="gap-2">
            <Download className="h-4 w-4" /> Export XLSX
          </Button>
        </div>
      )}
    </div>
  );
}
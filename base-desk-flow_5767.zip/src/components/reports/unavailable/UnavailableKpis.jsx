import React from "react";
import KpiRow from "@/components/reports/KpiRow";

// Focused KPI block for the Unavailable Insights tab.
export default function UnavailableKpis({ kpis }) {
  return <KpiRow kpis={kpis} />;
}
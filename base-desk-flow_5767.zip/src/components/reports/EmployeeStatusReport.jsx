import React, { useState, useMemo } from "react";
import { getMonthOptions, isWithinRetention } from "@/utils/reportWindow";
import { buildLookups, employeeName, teamName, locationName, buildingName, floorName, isInMonth, toOptions } from "@/utils/reportData";
import { exportRowsToXlsx } from "@/utils/reportExport";
import KpiRow from "./KpiRow";
import ReportFilters from "./ReportFilters";
import ReportTable from "./ReportTable";

const STATUS_OPTIONS = [
  { value: "Office", label: "Office" },
  { value: "Home Office", label: "Home Office" },
  { value: "Unavailable", label: "Unavailable" },
];

const ALLOWED_STATUSES = new Set(["Office", "Home Office", "Unavailable"]);

export default function EmployeeStatusReport({ data }) {
  const [filters, setFilters] = useState({
    month: getMonthOptions()[0].key,
    team: "",
    status: "",
    location: "",
    building: "",
    floor: "",
    employee: "",
  });

  const lookups = useMemo(() => buildLookups(data), [data]);

  const rows = useMemo(() => {
    return data.dailyStatuses
      .filter((s) => ALLOWED_STATUSES.has(s.status_type))
      .filter((s) => isWithinRetention(s.date) && isInMonth(s.date, filters.month))
      .filter((s) => !filters.status || s.status_type === filters.status)
      .filter((s) => !filters.employee || s.employee_id === filters.employee)
      .filter((s) => !filters.team || lookups.employee(s.employee_id)?.team_id === filters.team)
      .filter((s) => !filters.location || s.location_id === filters.location)
      .filter((s) => !filters.building || s.building_id === filters.building)
      .filter((s) => !filters.floor || s.floor_id === filters.floor)
      .map((s) => {
        const employee = lookups.employee(s.employee_id);
        return {
          id: s.id,
          date: s.date,
          employee: employee?.name || "—",
          team: teamName(lookups, employee?.team_id),
          status: s.status_type,
          source: s.source || "Manual",
          location: s.status_type === "Office" ? locationName(lookups, s.location_id) : "",
          building: s.status_type === "Office" ? buildingName(lookups, s.building_id) : "",
          floor: s.status_type === "Office" ? floorName(lookups, s.floor_id) : "",
          desk_code: s.status_type === "Office" ? lookups.desk(s.desk_id)?.code || "" : "",
        };
      })
      .sort((a, b) => a.date.localeCompare(b.date));
  }, [data, filters, lookups]);

  const kpis = useMemo(() => [
    { label: "Office", value: rows.filter((r) => r.status === "Office").length },
    { label: "Home Office", value: rows.filter((r) => r.status === "Home Office").length },
    { label: "Unavailable", value: rows.filter((r) => r.status === "Unavailable").length },
    { label: "Unique employees", value: new Set(rows.map((r) => r.employee)).size },
  ], [rows]);

  const columns = [
    { header: "Date", accessor: "date" },
    { header: "Employee", accessor: "employee" },
    { header: "Team", accessor: "team" },
    { header: "Status", accessor: "status" },
    { header: "Source", accessor: "source" },
    { header: "Location", accessor: "location" },
    { header: "Building", accessor: "building" },
    { header: "Floor", accessor: "floor" },
    { header: "Desk", accessor: "desk_code" },
  ];

  const filteredBuildings = data.buildings.filter((b) => !filters.location || b.location_id === filters.location);
  const filteredFloors = data.floors.filter((f) => f.type === "Office Floor" && (!filters.location || f.location_id === filters.location) && (!filters.building || f.building_id === filters.building));

  const fields = [
    { key: "team", label: "Team", options: toOptions(data.teams) },
    { key: "status", label: "Status", options: STATUS_OPTIONS },
    { key: "location", label: "Location", options: toOptions(data.locations) },
    { key: "building", label: "Building", options: toOptions(filteredBuildings) },
    { key: "floor", label: "Floor", options: toOptions(filteredFloors) },
    { key: "employee", label: "Employee", options: toOptions(data.employees) },
  ];

  const handleExport = () => {
    exportRowsToXlsx({
      rows,
      columns,
      sheetName: "Employee Status",
      fileName: `employee-status-${filters.month}.xlsx`,
    });
  };

  return (
    <div>
      <KpiRow kpis={kpis} />
      <ReportFilters filters={filters} onChange={setFilters} fields={fields} onExport={handleExport} exportDisabled={!rows.length} />
      <ReportTable columns={columns} rows={rows} emptyMessage="No status records match the filters." />
    </div>
  );
}
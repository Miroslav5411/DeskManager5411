import React, { useState, useMemo } from "react";
import { isGuestBooking } from "@/utils/deskFlow";
import { getMonthOptions, isWithinRetention } from "@/utils/reportWindow";
import { buildLookups, employeeName, teamName, locationName, buildingName, formatTimestamp, isInMonth, toOptions } from "@/utils/reportData";
import { exportRowsToXlsx } from "@/utils/reportExport";
import KpiRow from "./KpiRow";
import ReportFilters from "./ReportFilters";
import ReportTable from "./ReportTable";

const STATUS_OPTIONS = [
  { value: "Active", label: "Active" },
  { value: "Cancelled", label: "Cancelled" },
  { value: "Released by User", label: "Released by User" },
  { value: "Cancelled by Host", label: "Cancelled by Host" },
];

const OWNER_OPTIONS = [
  { value: "Employee", label: "Employee" },
  { value: "Guest", label: "Guest" },
];

export default function ParkingBookingsReport({ data }) {
  const [filters, setFilters] = useState({
    month: getMonthOptions()[0].key,
    team: "",
    location: "",
    building: "",
    floor_zone: "",
    employee: "",
    status: "",
    owner_type: "",
  });

  const lookups = useMemo(() => buildLookups(data), [data]);

  const rows = useMemo(() => {
    return data.parkingBookings
      .filter((b) => isWithinRetention(b.date) && isInMonth(b.date, filters.month))
      .filter((b) => !filters.location || b.location_id === filters.location)
      .filter((b) => !filters.building || b.building_id === filters.building)
      .filter((b) => !filters.floor_zone || b.floor_zone_id === filters.floor_zone)
      .filter((b) => !filters.status || b.status === filters.status)
      .filter((b) => !filters.owner_type || (b.owner_type || "Employee") === filters.owner_type)
      .filter((b) => {
        if (!filters.employee) return true;
        const target = isGuestBooking(b) ? b.host_employee_id : b.employee_id;
        return target === filters.employee;
      })
      .filter((b) => {
        if (!filters.team) return true;
        const empId = isGuestBooking(b) ? b.host_employee_id : b.employee_id;
        return lookups.employee(empId)?.team_id === filters.team;
      })
      .map((b) => {
        const isGuest = isGuestBooking(b);
        const hostId = b.host_employee_id || b.employee_id;
        return {
          id: b.id,
          date: b.date,
          person: isGuest ? b.guest_name || "—" : employeeName(lookups, b.employee_id),
          host: isGuest ? employeeName(lookups, hostId) : "",
          team: teamName(lookups, lookups.employee(hostId)?.team_id),
          location: locationName(lookups, b.location_id),
          building: buildingName(lookups, b.building_id),
          floor_zone: lookups.floor(b.floor_zone_id)?.name || "—",
          space_code: lookups.parkingSpace(b.parking_space_id)?.code || "—",
          plate: b.vehicle_plate_number || "",
          owner_type: b.owner_type || "Employee",
          status: b.status,
          created_by: b.created_by || "",
          created_at: formatTimestamp(b.created_date),
          cancelled_at: formatTimestamp(b.cancelled_at),
          cancel_reason: b.cancel_reason || "",
        };
      })
      .sort((a, b) => a.date.localeCompare(b.date));
  }, [data, filters, lookups]);

  const kpis = useMemo(() => [
    { label: "Total bookings", value: rows.length },
    { label: "Active", value: rows.filter((r) => r.status === "Active").length },
    { label: "Released / Cancelled", value: rows.filter((r) => r.status !== "Active").length },
    { label: "Guest bookings", value: rows.filter((r) => r.owner_type === "Guest").length },
    { label: "Unique employees", value: new Set(rows.filter((r) => r.owner_type !== "Guest").map((r) => r.person)).size },
  ], [rows]);

  const columns = [
    { header: "Date", accessor: "date" },
    { header: "Person", accessor: "person" },
    { header: "Host", accessor: "host" },
    { header: "Team", accessor: "team" },
    { header: "Location", accessor: "location" },
    { header: "Building", accessor: "building" },
    { header: "Floor / Zone", accessor: "floor_zone" },
    { header: "Spot", accessor: "space_code" },
    { header: "Vehicle plate", accessor: "plate" },
    { header: "Owner type", accessor: "owner_type" },
    { header: "Status", accessor: "status" },
    { header: "Created by", accessor: "created_by" },
    { header: "Created", accessor: "created_at" },
    { header: "Cancelled at", accessor: "cancelled_at" },
    { header: "Reason", accessor: "cancel_reason" },
  ];

  const filteredBuildings = data.buildings.filter((b) => !filters.location || b.location_id === filters.location);
  const filteredZones = data.floors.filter((f) => f.type !== "Office Floor" && (!filters.location || f.location_id === filters.location) && (!filters.building || f.building_id === filters.building));

  const fields = [
    { key: "team", label: "Team", options: toOptions(data.teams) },
    { key: "location", label: "Location", options: toOptions(data.locations) },
    { key: "building", label: "Building", options: toOptions(filteredBuildings) },
    { key: "floor_zone", label: "Floor / Zone", options: toOptions(filteredZones) },
    { key: "employee", label: "Employee", options: toOptions(data.employees) },
    { key: "status", label: "Booking status", options: STATUS_OPTIONS },
    { key: "owner_type", label: "Owner type", options: OWNER_OPTIONS },
  ];

  const handleExport = () => {
    exportRowsToXlsx({
      rows,
      columns,
      sheetName: "Parking Bookings",
      fileName: `parking-bookings-${filters.month}.xlsx`,
    });
  };

  return (
    <div>
      <KpiRow kpis={kpis} />
      <ReportFilters filters={filters} onChange={setFilters} fields={fields} onExport={handleExport} exportDisabled={!rows.length} />
      <ReportTable columns={columns} rows={rows} emptyMessage="No parking bookings match the filters." />
    </div>
  );
}
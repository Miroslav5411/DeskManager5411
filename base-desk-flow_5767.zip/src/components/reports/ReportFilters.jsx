import React from "react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Download } from "lucide-react";
import { getMonthOptions } from "@/utils/reportWindow";

const ALL = "__all";

const FilterField = ({ label, value, onChange, options, placeholder }) => (
  <div>
    <Label className="text-xs uppercase tracking-wide text-muted-foreground">{label}</Label>
    <Select value={value || ALL} onValueChange={(v) => onChange(v === ALL ? "" : v)}>
      <SelectTrigger className="mt-1">
        <SelectValue placeholder={placeholder} />
      </SelectTrigger>
      <SelectContent>
        <SelectItem value={ALL}>All</SelectItem>
        {options.map((option) => (
          <SelectItem key={option.value} value={option.value}>
            {option.label}
          </SelectItem>
        ))}
      </SelectContent>
    </Select>
  </div>
);

export default function ReportFilters({ filters, onChange, fields, onExport, exportDisabled, hideMonth = false }) {
  const months = getMonthOptions();

  return (
    <div className="mb-6 rounded-2xl border bg-card p-4">
      <div className="grid grid-cols-1 gap-4 md:grid-cols-3 lg:grid-cols-4">
        {!hideMonth && (
          <div>
            <Label className="text-xs uppercase tracking-wide text-muted-foreground">Month</Label>
            <Select value={filters.month} onValueChange={(v) => onChange({ ...filters, month: v })}>
              <SelectTrigger className="mt-1">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {months.map((m) => (
                  <SelectItem key={m.key} value={m.key}>
                    {m.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        )}

        {fields.map((field) => (
          <FilterField
            key={field.key}
            label={field.label}
            value={filters[field.key]}
            onChange={(v) => onChange({ ...filters, [field.key]: v })}
            options={field.options}
            placeholder={field.label}
          />
        ))}
      </div>

      {onExport && (
        <div className="mt-4 flex justify-end">
          <Button onClick={onExport} disabled={exportDisabled} className="gap-2">
            <Download className="h-4 w-4" /> Export XLSX
          </Button>
        </div>
      )}
    </div>
  );
}
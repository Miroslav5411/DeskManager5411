import React, { useMemo, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { startOfWeek, endOfWeek, format, parseISO } from "date-fns";
import { exportRowsToXlsx } from "@/utils/reportExport";
import { isWithinRetention } from "@/utils/reportWindow";
import {
  UNAVAILABLE,
  todayStr,
  filterUnavailableRows,
  distinctUnavailableEmployees,
  buildHolidayProximity,
  isWorkingDay,
  nextWorkingDay,
  addDays,
} from "@/utils/unavailableInsights";
import { buildLookups, employeeName, teamName, locationName, buildingName, formatTimestamp, toOptions } from "@/utils/reportData";
import UnavailableKpis from "./unavailable/UnavailableKpis";
import UnavailableFilters from "./unavailable/UnavailableFilters";
import TeamBreakdownTable from "./unavailable/TeamBreakdownTable";
import HolidayProximityTable from "./unavailable/HolidayProximityTable";
import UnavailableCharts from "./unavailable/UnavailableCharts";
import ReportTable from "./ReportTable";
import { Card, CardContent } from "@/components/ui/card";

const SOURCE_LABEL = (s) => s || "Manual";

export default function UnavailableInsights({ data }) {
  const [filters, setFilters] = useState({
    dateExact: "",
    dateFrom: "",
    dateTo: "",
    team: "",
    department: "",
    location: "",
    building: "",
    manager: "",
    source: "",
  });

  const { data: holidays = [] } = useQuery({
    queryKey: ["public-holidays"],
    queryFn: () => base44.entities.PublicHoliday.list("-holiday_date", 500),
  });

  const lookups = useMemo(() => buildLookups(data), [data]);
  const today = todayStr();

  // List rows (filtered + retention applied).
  const rows = useMemo(() => {
    const effectiveFilters = filters.dateExact
      ? { ...filters, dateFrom: filters.dateExact, dateTo: filters.dateExact }
      : filters;
    const filtered = filterUnavailableRows(data.dailyStatuses, data.employees, effectiveFilters);
    return filtered
      .map((s) => {
        const emp = lookups.employee(s.employee_id);
        return {
          id: s.id,
          date: s.date,
          employee: emp?.name || "—",
          team: teamName(lookups, emp?.team_id),
          department: emp?.department || "",
          manager: employeeName(lookups, emp?.manager_id),
          location: locationName(lookups, emp?.default_location_id),
          building: buildingName(lookups, emp?.default_building_id),
          status: UNAVAILABLE,
          source: SOURCE_LABEL(s.source),
          updated: formatTimestamp(s.updated_date || s.created_date),
        };
      })
      .sort((a, b) => a.date.localeCompare(b.date) || a.employee.localeCompare(b.employee));
  }, [data, filters, lookups]);

  // KPI math — use raw retention-filtered statuses (not user filters), per spec.
  const retentionStatuses = useMemo(
    () => data.dailyStatuses.filter((s) => s.status_type === UNAVAILABLE && isWithinRetention(s.date)),
    [data.dailyStatuses]
  );

  const activeEmployees = useMemo(() => data.employees.filter((e) => e.is_active !== false), [data.employees]);
  const activeCount = activeEmployees.length;

  const weekStart = format(startOfWeek(new Date(), { weekStartsOn: 1 }), "yyyy-MM-dd");
  const weekEnd = format(endOfWeek(new Date(), { weekStartsOn: 1 }), "yyyy-MM-dd");
  const monthKey = today.slice(0, 7);

  const todayDates = [today];
  const weekDates = useMemo(() => {
    const out = [];
    let cur = weekStart;
    while (cur <= weekEnd) { out.push(cur); cur = addDays(cur, 1); }
    return out;
  }, [weekStart, weekEnd]);
  const monthDates = useMemo(() => retentionStatuses.filter((s) => s.date.startsWith(monthKey)).map((s) => s.date), [retentionStatuses, monthKey]);

  const todayCount = distinctUnavailableEmployees(retentionStatuses, todayDates);
  const weekCount = distinctUnavailableEmployees(retentionStatuses, weekDates);
  const monthCount = distinctUnavailableEmployees(retentionStatuses, monthDates);
  const pctToday = activeCount > 0 ? Math.round((todayCount / activeCount) * 1000) / 10 : 0;

  // Top team today
  const teamCountsToday = useMemo(() => {
    const counts = new Map();
    for (const s of retentionStatuses) {
      if (s.date !== today) continue;
      const emp = lookups.employee(s.employee_id);
      if (!emp) continue;
      counts.set(emp.team_id, (counts.get(emp.team_id) || 0) + 1);
    }
    return counts;
  }, [retentionStatuses, today, lookups]);
  const topTeamToday = (() => {
    let bestId = null; let bestN = 0;
    for (const [id, n] of teamCountsToday) { if (n > bestN) { bestN = n; bestId = id; } }
    return bestId ? `${teamName(lookups, bestId)} (${bestN})` : "—";
  })();

  // Upcoming working day with highest unavailable count (within retention/future window)
  const upcomingTop = useMemo(() => {
    const counts = new Map();
    for (const s of retentionStatuses) {
      if (s.date < today) continue;
      if (!isWorkingDay(s.date)) continue;
      counts.set(s.date, (counts.get(s.date) || new Set()));
      counts.get(s.date).add(s.employee_id);
    }
    let bestDate = null; let bestN = 0;
    for (const [date, ids] of counts) { if (ids.size > bestN) { bestN = ids.size; bestDate = date; } }
    return bestDate ? `${bestDate} (${bestN})` : "—";
  }, [retentionStatuses, today]);

  const kpis = [
    { label: "Unavailable today", value: todayCount },
    { label: "Unavailable this week", value: weekCount },
    { label: "Unavailable this month", value: monthCount },
    { label: "% active unavailable today", value: `${pctToday}%` },
    { label: "Top team today", value: topTeamToday },
    { label: "Upcoming peak day", value: upcomingTop },
  ];

  // Team breakdown
  const teamRows = useMemo(() => {
    const teamsActiveCount = new Map();
    for (const e of activeEmployees) {
      teamsActiveCount.set(e.team_id, (teamsActiveCount.get(e.team_id) || 0) + 1);
    }
    return data.teams
      .filter((t) => t.is_active !== false)
      .map((t) => {
        const active = teamsActiveCount.get(t.id) || 0;
        const inTeam = (s) => {
          const emp = lookups.employee(s.employee_id);
          return emp && emp.team_id === t.id;
        };
        const teamStatuses = retentionStatuses.filter(inTeam);
        const tToday = distinctUnavailableEmployees(teamStatuses, todayDates);
        const tWeek = distinctUnavailableEmployees(teamStatuses, weekDates);
        const tMonth = teamStatuses.filter((s) => s.date.startsWith(monthKey)).length;
        return {
          id: t.id,
          team: t.name,
          active,
          today: tToday,
          week: tWeek,
          month: tMonth,
          pctToday: active > 0 ? `${Math.round((tToday / active) * 1000) / 10}%` : "0%",
          pctWeek: active > 0 ? `${Math.round((tWeek / active) * 1000) / 10}%` : "0%",
        };
      })
      .sort((a, b) => b.today - a.today);
  }, [data.teams, retentionStatuses, lookups, activeEmployees, todayDates, weekDates, monthKey]);

  // Holiday proximity rows
  const holidayRows = useMemo(() => {
    return holidays
      .filter((h) => h.is_active !== false && isWithinRetention(h.holiday_date))
      .map((h) => buildHolidayProximity({ holiday: h, statuses: retentionStatuses, activeEmployeeCount: activeCount }))
      .sort((a, b) => a.holidayDate.localeCompare(b.holidayDate));
  }, [holidays, retentionStatuses, activeCount]);

  // Charts data
  const byDay = useMemo(() => {
    const map = new Map();
    for (const s of retentionStatuses) {
      const set = map.get(s.date) || new Set();
      set.add(s.employee_id);
      map.set(s.date, set);
    }
    return Array.from(map.entries())
      .map(([date, ids]) => ({ date, count: ids.size }))
      .sort((a, b) => a.date.localeCompare(b.date));
  }, [retentionStatuses]);

  const byTeam = teamRows.map((r) => ({ team: r.team, count: r.month, pctToday: parseFloat(r.pctToday) }));
  const holidayChart = holidayRows.map((r) => ({ holidayName: r.holidayName, prev2Count: r.prev2Count, next2Count: r.next2Count }));

  // Filters option lists
  const optionLists = {
    teams: toOptions(data.teams),
    departments: Array.from(new Set(data.employees.map((e) => e.department).filter(Boolean))).sort().map((d) => ({ value: d, label: d })),
    managers: data.employees.filter((e) => e.role === "Team Manager" || e.role === "Admin").map((e) => ({ value: e.id, label: e.name })),
    locations: toOptions(data.locations),
    buildings: toOptions(data.buildings.filter((b) => !filters.location || b.location_id === filters.location)),
  };

  // Columns for the main list
  const listColumns = [
    { header: "Date", accessor: "date" },
    { header: "Employee", accessor: "employee" },
    { header: "Team", accessor: "team" },
    { header: "Department", accessor: "department" },
    { header: "Manager", accessor: "manager" },
    { header: "Default location", accessor: "location" },
    { header: "Default building", accessor: "building" },
    { header: "Status", accessor: "status" },
    { header: "Source", accessor: "source" },
    { header: "Last updated", accessor: "updated" },
  ];

  const handleExport = () => {
    // Multi-sheet XLSX: list + team breakdown + holiday proximity + applied filters
    const filtersSheet = [{
      "Date exact": filters.dateExact || "",
      "From": filters.dateFrom || "",
      "To": filters.dateTo || "",
      "Source": filters.source || "All",
      "Team": filters.team ? teamName(lookups, filters.team) : "All",
      "Department": filters.department || "All",
      "Manager": filters.manager ? employeeName(lookups, filters.manager) : "All",
      "Location": filters.location ? locationName(lookups, filters.location) : "All",
      "Building": filters.building ? buildingName(lookups, filters.building) : "All",
      "Generated": new Date().toLocaleString(),
    }];

    // Use single helper for the list, then append other sheets via xlsx directly.
    // Re-using exportRowsToXlsx with a workaround would break its single-sheet output —
    // so we do a small inline multi-sheet write here.
    import("xlsx").then((XLSX) => {
      const wb = XLSX.utils.book_new();
      const toSheet = (rs, cols) => {
        const data = rs.map((row) => {
          const out = {};
          cols.forEach((c) => {
            const v = typeof c.accessor === "function" ? c.accessor(row) : row[c.accessor];
            out[c.header] = v === null || v === undefined ? "" : v;
          });
          return out;
        });
        return XLSX.utils.json_to_sheet(data);
      };
      XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(filtersSheet), "Filters");
      XLSX.utils.book_append_sheet(wb, toSheet(rows, listColumns), "Unavailable list");
      XLSX.utils.book_append_sheet(wb, toSheet(teamRows, [
        { header: "Team", accessor: "team" },
        { header: "Active", accessor: "active" },
        { header: "Today", accessor: "today" },
        { header: "Week", accessor: "week" },
        { header: "Month", accessor: "month" },
        { header: "% Today", accessor: "pctToday" },
        { header: "% Week", accessor: "pctWeek" },
      ]), "Team breakdown");
      XLSX.utils.book_append_sheet(wb, toSheet(holidayRows, [
        { header: "Holiday", accessor: "holidayName" },
        { header: "Date", accessor: "holidayDate" },
        { header: "Prev WD", accessor: "prevWorkingDay" },
        { header: "Unavail prev", accessor: "prevCount" },
        { header: "Unavail on", accessor: "onCount" },
        { header: "Next WD", accessor: "nextWorkingDay" },
        { header: "Unavail next", accessor: "nextCount" },
        { header: "Within 2 before", accessor: "prev2Count" },
        { header: "Within 2 after", accessor: "next2Count" },
        { header: "% around", accessor: "aroundPct" },
      ]), "Holiday proximity");
      XLSX.writeFile(wb, `unavailable-insights-${todayStr()}.xlsx`);
    });
  };

  return (
    <div>
      <UnavailableKpis kpis={kpis} />
      <UnavailableFilters
        filters={filters}
        onChange={setFilters}
        optionLists={optionLists}
        onExport={handleExport}
        exportDisabled={!rows.length && !teamRows.length && !holidayRows.length}
      />

      <Card className="mb-6 rounded-2xl">
        <CardContent className="p-4">
          <p className="mb-3 text-xs uppercase tracking-wide text-muted-foreground">Unavailable employees</p>
          <ReportTable columns={listColumns} rows={rows} emptyMessage="No Unavailable records match the filters." />
        </CardContent>
      </Card>

      <Card className="mb-6 rounded-2xl">
        <CardContent className="p-4">
          <p className="mb-3 text-xs uppercase tracking-wide text-muted-foreground">Team breakdown</p>
          <TeamBreakdownTable rows={teamRows} />
        </CardContent>
      </Card>

      <Card className="mb-6 rounded-2xl">
        <CardContent className="p-4">
          <p className="mb-1 text-xs uppercase tracking-wide text-muted-foreground">Holiday proximity</p>
          <p className="mb-3 text-xs text-muted-foreground">
            Neutral metric — counts employees marked Unavailable around configured public holidays. No reasons or HR-sensitive data shown.
          </p>
          <HolidayProximityTable rows={holidayRows} />
        </CardContent>
      </Card>

      <UnavailableCharts byDay={byDay} byTeam={byTeam} holidayChart={holidayChart} />
    </div>
  );
}
import React from "react";
import { Card, CardContent } from "@/components/ui/card";

export default function KpiRow({ kpis }) {
  if (!kpis?.length) return null;
  return (
    <div className="mb-6 grid gap-3 md:grid-cols-3 lg:grid-cols-5">
      {kpis.map((kpi) => (
        <Card key={kpi.label} className="rounded-2xl">
          <CardContent className="p-4">
            <p className="text-xs uppercase tracking-wide text-muted-foreground">{kpi.label}</p>
            <p className="mt-1 text-2xl font-semibold">{kpi.value}</p>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}
import React from "react";
import { Button } from "@/components/ui/button";
import { buildPlaceLabel } from "@/utils/deskFlow";
import { ALLOWED_WORK_STATUSES, isAllowedWorkStatus } from "@/utils/workspaceRules";

export default function ScheduleTable({ dates, rows, onSetStatus }) {
  return (
    <div className="overflow-hidden rounded-3xl border bg-card">
      <div className="grid grid-cols-12 border-b bg-secondary px-4 py-3 text-xs font-semibold uppercase tracking-wide text-muted-foreground">
        <span className="col-span-3">Date</span>
        <span className="col-span-3">Status</span>
        <span className="col-span-3">Desk</span>
        <span className="col-span-3">Actions</span>
      </div>
      {dates.map((date) => {
        const row = rows[date.key] || {};
        // Defensive: only render a status_type that is in the allowed set.
        const displayStatus = isAllowedWorkStatus(row.status?.status_type) ? row.status.status_type : "Not set";
        return (
          <div key={date.key} className="grid grid-cols-1 gap-3 border-b px-4 py-4 last:border-b-0 md:grid-cols-12 md:items-center">
            <div className="md:col-span-3"><p className="font-medium">{date.label}</p><p className="text-xs text-muted-foreground">{date.key}</p></div>
            <div className="md:col-span-3">{displayStatus}</div>
            <div className="text-sm text-muted-foreground md:col-span-3">{buildPlaceLabel(row.place)}</div>
            <div className="flex flex-wrap gap-2 md:col-span-3">
              {ALLOWED_WORK_STATUSES.map((status) => (
                <Button key={status} variant="outline" size="sm" onClick={() => onSetStatus(date.key, status)}>{status}</Button>
              ))}
            </div>
          </div>
        );
      })}
    </div>
  );
}
import React, { useState, useEffect, useRef, useCallback } from "react";
import { useLocation } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { normalizeEmail } from "@/utils/workspaceRules";
import { QUICK_PROMPTS } from "@/data/platformHelpKnowledge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { MessageCircleQuestion, X, Send, Bot } from "lucide-react";
import { cn } from "@/lib/utils";
import MessageBubble from "./MessageBubble";

const AGENT_NAME = "platform_assistant";

// Map a raw route to a general, sanitized page name (no record IDs).
function sanitizeRoute(pathname) {
  const map = {
    "/": "Dashboard",
    "/book-desk": "Book Desk",
    "/book-parking": "Book Parking",
    "/my-schedule": "My Schedule",
    "/people": "Who Is Where",
    "/notifications": "Notifications",
    "/reports": "Reports",
  };
  if (map[pathname]) return map[pathname];
  if (pathname.startsWith("/admin")) return "Admin Tools";
  return "the app";
}

// Resolve the role-aware quick prompts (Manager/Admin get extra chips).
function promptsForRole(role) {
  const base = [...QUICK_PROMPTS.Employee];
  if (role === "Team Manager") return [...base, ...QUICK_PROMPTS["Team Manager"]];
  if (role === "Admin") return [...base, ...QUICK_PROMPTS["Team Manager"], ...QUICK_PROMPTS.Admin];
  return base;
}

export default function PlatformChat() {
  const location = useLocation();
  const [open, setOpen] = useState(false);
  const [conversation, setConversation] = useState(null);
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState("");
  const [sending, setSending] = useState(false);
  const scrollRef = useRef(null);
  const unsubRef = useRef(null);

  // Minimal, non-sensitive context only: display name + application role.
  const { data: identity } = useQuery({
    queryKey: ["assistant-identity"],
    queryFn: async () => {
      const user = await base44.auth.me();
      const employees = await base44.entities.Employee.filter({ email: normalizeEmail(user.email) });
      const emp = employees[0];
      const isAdmin = emp?.role === "Admin" || user.role === "Admin" || user.role === "admin";
      return {
        userName: emp?.name || user.full_name || "there",
        userRole: emp?.role || (isAdmin ? "Admin" : "Employee"),
      };
    },
  });

  const userRole = identity?.userRole || "Employee";
  const currentRoute = sanitizeRoute(location.pathname);

  useEffect(() => {
    if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
  }, [messages, open]);

  // Clean up the subscription when the component unmounts.
  useEffect(() => () => { if (unsubRef.current) unsubRef.current(); }, []);

  // Handle a snapshot of conversation messages (used by the live subscription).
  const handleSnapshot = useCallback((data) => {
    if (!data?.messages) return;
    setMessages(data.messages);
    const last = data.messages[data.messages.length - 1];
    if (last?.role === "assistant" && last.content) setSending(false);
  }, []);

  const ensureConversation = useCallback(async () => {
    if (conversation) return conversation;
    const convo = await base44.agents.createConversation({
      agent_name: AGENT_NAME,
      metadata: {
        name: "Help Assistant",
        // Minimal, sanitized context ONLY — no entities, IDs, emails, or phones.
        userName: identity?.userName || "there",
        userRole,
        currentRoute,
      },
    });
    setConversation(convo);
    // Subscribe IMMEDIATELY (not via effect) so we don't miss the streamed reply
    // due to the render-cycle race between createConversation and the listener.
    if (!unsubRef.current) {
      unsubRef.current = base44.agents.subscribeToConversation(convo.id, handleSnapshot);
    }
    return convo;
  }, [conversation, identity, userRole, currentRoute, handleSnapshot]);

  const send = async (text) => {
    const content = (text ?? input).trim();
    if (!content || sending) return;
    setInput("");
    setSending(true);
    setMessages((prev) => [...prev, { role: "user", content }]);
    const convo = await ensureConversation();
    await base44.agents.addMessage(convo, { role: "user", content });
  };

  const quickPrompts = promptsForRole(userRole);

  return (
    <>
      {/* Floating launcher */}
      {!open && (
        <button
          onClick={() => setOpen(true)}
          data-testid="assistant-launcher"
          className="fixed bottom-5 right-5 z-50 flex h-14 w-14 items-center justify-center rounded-full bg-primary text-primary-foreground shadow-lg transition hover:scale-105"
          aria-label="Open Help Assistant"
        >
          <MessageCircleQuestion className="h-6 w-6" />
        </button>
      )}

      {open && (
        <div className="fixed bottom-5 right-5 z-50 flex h-[560px] max-h-[calc(100vh-2.5rem)] w-[calc(100vw-2.5rem)] max-w-[380px] flex-col overflow-hidden rounded-2xl border bg-background shadow-2xl">
          {/* Header */}
          <div className="flex items-center justify-between gap-2 border-b bg-primary px-4 py-3 text-primary-foreground">
            <div className="flex items-center gap-2">
              <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary-foreground/15">
                <Bot className="h-4.5 w-4.5" />
              </div>
              <div className="leading-tight">
                <p className="text-sm font-semibold">Help Assistant</p>
                <p className="text-[10px] uppercase tracking-[0.18em] text-primary-foreground/70">{userRole} · Guide</p>
              </div>
            </div>
            <button onClick={() => setOpen(false)} className="rounded-full p-1 hover:bg-primary-foreground/15" aria-label="Close">
              <X className="h-4 w-4" />
            </button>
          </div>

          {/* Messages */}
          <div ref={scrollRef} className="flex-1 space-y-3 overflow-y-auto p-3.5">
            {messages.length === 0 && (
              <div className="rounded-xl border bg-muted/40 p-3 text-sm text-muted-foreground">
                Hi {identity?.userName || "there"} 👋 I can help you navigate the platform — how to book a desk or parking, set your status, find colleagues, and more. I can guide you, but I can't make changes for you.
              </div>
            )}
            {messages.map((m, i) => (
              <MessageBubble key={i} message={m} />
            ))}
            {sending && (
              <div className="flex items-center gap-2 pl-1 text-xs text-muted-foreground">
                <span className="h-1.5 w-1.5 animate-bounce rounded-full bg-muted-foreground [animation-delay:-0.2s]" />
                <span className="h-1.5 w-1.5 animate-bounce rounded-full bg-muted-foreground [animation-delay:-0.1s]" />
                <span className="h-1.5 w-1.5 animate-bounce rounded-full bg-muted-foreground" />
              </div>
            )}
          </div>

          {/* Quick prompts */}
          {messages.length === 0 && (
            <div className="flex flex-wrap gap-1.5 border-t px-3 py-2.5">
              {quickPrompts.map((p) => (
                <button
                  key={p}
                  onClick={() => send(p)}
                  className="rounded-full border bg-background px-2.5 py-1 text-xs text-muted-foreground transition hover:bg-muted hover:text-foreground"
                >
                  {p}
                </button>
              ))}
            </div>
          )}

          {/* Composer */}
          <form
            onSubmit={(e) => { e.preventDefault(); send(); }}
            className="flex items-center gap-2 border-t p-2.5"
          >
            <Input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Ask how to use the platform…"
              className="h-9"
            />
            <Button type="submit" size="icon" disabled={!input.trim() || sending} className="h-9 w-9 shrink-0">
              <Send className="h-4 w-4" />
            </Button>
          </form>
        </div>
      )}
    </>
  );
}
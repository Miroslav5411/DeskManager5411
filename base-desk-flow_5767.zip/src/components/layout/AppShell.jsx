import React from "react";
import { NavLink, Outlet } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import { LayoutDashboard, Map, Car, CalendarDays, Users, Bell, BarChart3 } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { normalizeEmail } from "@/utils/workspaceRules";
import AdminMenu from "@/components/layout/AdminMenu";
import PlatformChat from "@/components/agents/PlatformChat";

// Top-level product nav — clean, role-based, no build-phase labels.
const baseNavItems = [
  { label: "Dashboard", path: "/", icon: LayoutDashboard },
  { label: "Book Desk", path: "/book-desk", icon: Map },
  { label: "Book Parking", path: "/book-parking", icon: Car },
  { label: "My Schedule", path: "/my-schedule", icon: CalendarDays },
  { label: "Who Is Where", path: "/people", icon: Users },
  { label: "Notifications", path: "/notifications", icon: Bell },
];
const reportsItem = { label: "Reports", path: "/reports", icon: BarChart3 };

export default function AppShell() {
  const { data } = useQuery({
    queryKey: ["nav-current-role"],
    queryFn: async () => {
      const user = await base44.auth.me();
      const employees = await base44.entities.Employee.filter({ email: normalizeEmail(user.email) });
      return { user, employee: employees[0] };
    },
  });

  const role = data?.employee?.role;
  const isAdmin = role === "Admin" || data?.user?.role === "Admin" || data?.user?.role === "admin";
  const canAccessReports = isAdmin || role === "Team Manager";

  const navItems = [...baseNavItems, ...(canAccessReports ? [reportsItem] : [])];
  const displayName = data?.employee?.name || data?.user?.full_name || "";
  const displayRole = role || (isAdmin ? "Admin" : "Employee");

  return (
    <div className="min-h-screen bg-background text-foreground">
      <header
        data-testid="app-header"
        className="sticky top-0 z-40 border-b bg-primary text-primary-foreground shadow-sm"
      >
        <div className="mx-auto flex max-w-[1400px] items-center justify-between gap-6 px-4 py-3 md:px-6">
          <div className="min-w-0">
            <p className="text-[10px] uppercase tracking-[0.35em] text-primary-foreground/60">Workspace</p>
            <h1 className="truncate text-base font-semibold tracking-tight md:text-lg">Management System</h1>
          </div>
          <nav data-testid="primary-nav" className="hidden flex-1 items-center justify-center gap-1 lg:flex">
            {navItems.map((item) => {
              const Icon = item.icon;
              return (
                <NavLink
                  key={item.path}
                  to={item.path}
                  end={item.path === "/"}
                  className={({ isActive }) =>
                    `flex items-center gap-2 rounded-full px-3 py-2 text-sm transition ${
                      isActive
                        ? "bg-primary-foreground text-primary"
                        : "text-primary-foreground/80 hover:bg-primary-foreground/10 hover:text-primary-foreground"
                    }`
                  }
                >
                  <Icon className="h-4 w-4" />
                  {item.label}
                </NavLink>
              );
            })}
          </nav>
          <div className="flex items-center gap-3">
            {isAdmin && <AdminMenu />}
            <div className="hidden text-right md:block">
              <p className="text-xs font-medium leading-tight">{displayName}</p>
              <p className="text-[10px] uppercase tracking-[0.2em] text-primary-foreground/70">{displayRole}</p>
            </div>
          </div>
        </div>
        {/* Tablet / mid-screen secondary row */}
        <nav className="border-t border-primary-foreground/10 bg-primary/95 lg:hidden">
          <div className="mx-auto flex max-w-[1400px] items-center gap-1 overflow-x-auto px-4 py-2 md:px-6">
            {navItems.map((item) => {
              const Icon = item.icon;
              return (
                <NavLink
                  key={item.path}
                  to={item.path}
                  end={item.path === "/"}
                  className={({ isActive }) =>
                    `flex shrink-0 items-center gap-1.5 rounded-full px-3 py-1.5 text-xs transition ${
                      isActive
                        ? "bg-primary-foreground text-primary"
                        : "text-primary-foreground/80 hover:bg-primary-foreground/10"
                    }`
                  }
                >
                  <Icon className="h-3.5 w-3.5" />
                  {item.label}
                </NavLink>
              );
            })}
          </div>
        </nav>
      </header>
      <main className="mx-auto max-w-[1400px] px-4 py-6 md:px-6 md:py-10">
        <Outlet />
      </main>
      <PlatformChat />
    </div>
  );
}
import React from "react";
import { Link, useLocation } from "react-router-dom";
import { ShieldCheck, ChevronDown } from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

// Grouped Admin tools — mirrors pages/admin/AdminTools.jsx so navigation feels consistent.
export const ADMIN_GROUPS = [
  {
    title: "People & Organization",
    items: [
      { label: "Employees", path: "/admin/people" },
      { label: "Unavailable Employees", path: "/admin/unavailable-employees" },
      { label: "Public Holidays", path: "/admin/public-holidays" },
    ],
  },
  {
    title: "Workspace Setup",
    items: [
      { label: "Locations", path: "/admin/locations" },
      { label: "Floors & Maps", path: "/admin/floors" },
      { label: "Desk Map", path: "/admin/desk-map" },
      { label: "Parking Map", path: "/admin/parking-map" },
    ],
  },
  {
    title: "Operations",
    items: [
      { label: "Guest Bookings This Week", path: "/admin/guest-bookings" },
      { label: "Notifications Admin", path: "/admin/notifications" },
      { label: "Fixed-Desk Import", path: "/admin/fixed-desk-import" },
    ],
  },
  {
    title: "Governance",
    items: [
      { label: "SRT / QA Tests", path: "/admin/srt-tests" },
    ],
  },
];

export default function AdminMenu() {
  const { pathname } = useLocation();
  const isActive = pathname.startsWith("/admin");

  return (
    <DropdownMenu>
      <DropdownMenuTrigger
        data-testid="admin-menu-trigger"
        className={`flex items-center gap-2 rounded-full px-4 py-2 text-sm transition ${
          isActive
            ? "bg-primary-foreground text-primary"
            : "text-primary-foreground/75 hover:bg-primary-foreground/10 hover:text-primary-foreground"
        }`}
      >
        <ShieldCheck className="h-4 w-4" />
        Admin
        <ChevronDown className="h-3.5 w-3.5 opacity-70" />
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-72 max-h-[70vh] overflow-y-auto">
        <DropdownMenuItem asChild>
          <Link to="/admin" className="font-medium">Admin Tools (overview)</Link>
        </DropdownMenuItem>
        <DropdownMenuSeparator />
        {ADMIN_GROUPS.map((group, idx) => (
          <React.Fragment key={group.title}>
            <DropdownMenuLabel className="text-[11px] uppercase tracking-[0.2em] text-muted-foreground">
              {group.title}
            </DropdownMenuLabel>
            {group.items.map((item) => (
              <DropdownMenuItem key={item.path} asChild>
                <Link to={item.path}>{item.label}</Link>
              </DropdownMenuItem>
            ))}
            {idx < ADMIN_GROUPS.length - 1 && <DropdownMenuSeparator />}
          </React.Fragment>
        ))}
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
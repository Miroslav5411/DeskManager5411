import React, { useMemo, useState } from "react";
import { Link } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Bell } from "lucide-react";
import NotificationCard from "./NotificationCard";
import NotificationDetailDialog from "./NotificationDetailDialog";
import { buildVisibleNotifications } from "@/utils/notificationRules";

export default function DashboardNotificationsSection() {
  const { data, isLoading } = useQuery({
    queryKey: ["dashboard-notifications"],
    queryFn: () => base44.entities.Notification.list("-updated_date", 200),
  });
  const [open, setOpen] = useState(null);

  const visible = useMemo(() => buildVisibleNotifications(data || []), [data]);
  const top = visible.slice(0, 5);

  return (
    <Card className="mt-6 rounded-3xl">
      <CardContent className="p-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Bell className="h-5 w-5 text-primary" />
            <h3 className="text-lg font-semibold">Notifications</h3>
          </div>
          <Button asChild variant="outline" size="sm"><Link to="/notifications">View all</Link></Button>
        </div>
        {isLoading && <p className="mt-4 text-sm text-muted-foreground">Loading…</p>}
        {!isLoading && top.length === 0 && (
          <p className="mt-4 text-sm text-muted-foreground">No active notifications.</p>
        )}
        <div className="mt-4 grid gap-3 md:grid-cols-2">
          {top.map((n) => (
            <NotificationCard key={n.id} notification={n} compact onOpen={setOpen} />
          ))}
        </div>
        <NotificationDetailDialog notification={open} onClose={() => setOpen(null)} />
      </CardContent>
    </Card>
  );
}
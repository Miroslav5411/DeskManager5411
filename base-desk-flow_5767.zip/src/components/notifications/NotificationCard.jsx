import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { AlertTriangle, Pin } from "lucide-react";

export default function NotificationCard({ notification, onOpen, compact = false }) {
  if (!notification) return null;
  const { title, body, category, start_date, end_date, is_pinned } = notification;
  const preview = (body || "").length > 140 ? `${body.slice(0, 140)}…` : body;

  return (
    <button
      type="button"
      onClick={() => onOpen?.(notification)}
      className="w-full text-left"
    >
      <Card className={`rounded-3xl transition hover:shadow-md ${is_pinned ? "border-primary/60 ring-1 ring-primary/30" : ""}`}>
        <CardContent className={compact ? "p-4" : "p-6"}>
          <div className="flex flex-wrap items-center gap-2">
            {is_pinned && (
              <Badge className="gap-1 bg-primary text-primary-foreground">
                <AlertTriangle className="h-3 w-3" /> Urgent
              </Badge>
            )}
            <Badge variant="secondary">{category || "General"}</Badge>
            {is_pinned && <Pin className="h-3.5 w-3.5 text-primary" aria-hidden />}
          </div>
          <h3 className={`mt-2 font-semibold ${compact ? "text-base" : "text-lg"}`}>{title}</h3>
          <p className={`mt-1 text-muted-foreground ${compact ? "text-xs" : "text-sm"}`}>{preview}</p>
          <p className="mt-2 text-xs text-muted-foreground">
            {start_date} → {end_date}
          </p>
        </CardContent>
      </Card>
    </button>
  );
}
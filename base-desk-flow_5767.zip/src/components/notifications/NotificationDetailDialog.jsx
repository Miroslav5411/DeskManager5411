import React from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { AlertTriangle } from "lucide-react";

export default function NotificationDetailDialog({ notification, onClose }) {
  const open = !!notification;
  return (
    <Dialog open={open} onOpenChange={(v) => { if (!v) onClose?.(); }}>
      <DialogContent className="max-w-lg">
        {notification && (
          <>
            <DialogHeader>
              <div className="flex flex-wrap items-center gap-2">
                {notification.is_pinned && (
                  <Badge className="gap-1 bg-primary text-primary-foreground">
                    <AlertTriangle className="h-3 w-3" /> Urgent
                  </Badge>
                )}
                <Badge variant="secondary">{notification.category}</Badge>
              </div>
              <DialogTitle className="text-xl">{notification.title}</DialogTitle>
            </DialogHeader>
            <p className="whitespace-pre-wrap text-sm leading-6 text-foreground">{notification.body}</p>
            <p className="mt-4 text-xs text-muted-foreground">
              Active from {notification.start_date} to {notification.end_date}
            </p>
          </>
        )}
      </DialogContent>
    </Dialog>
  );
}
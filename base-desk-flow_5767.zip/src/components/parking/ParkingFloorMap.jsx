import React from "react";
import { Car } from "lucide-react";

const stateStyles = {
  available: "border-emerald-600 bg-emerald-500 text-white hover:bg-emerald-600",
  selected: "border-primary bg-primary text-primary-foreground ring-4 ring-primary/20",
  booked: "border-slate-400 bg-slate-300 text-slate-700 cursor-not-allowed",
  fixed: "border-blue-600 bg-blue-500 text-white cursor-not-allowed",
  blocked: "border-red-600 bg-red-500 text-white cursor-not-allowed",
};

const isGuestBooking = (booking) => booking?.owner_type === "Guest";

export default function ParkingFloorMap({ floor, spaces, bookings, employees = [], selectedSpaceId, onSelect }) {
  const bookedIds = new Set(bookings.map((booking) => booking.parking_space_id));
  const employeeById = Object.fromEntries(employees.map((employee) => [employee.id, employee]));

  const getState = (space) => {
    if (space.id === selectedSpaceId) return "selected";
    if (space.space_type === "Blocked") return "blocked";
    if (space.space_type === "Company Car Fixed") return "fixed";
    if (bookedIds.has(space.id)) return "booked";
    return "available";
  };

  const getTitle = (space) => {
    const booking = bookings.find((item) => item.parking_space_id === space.id);
    if (booking && isGuestBooking(booking)) {
      const host = employeeById[booking.host_employee_id || booking.employee_id]?.name || "Host";
      return `Guest: ${booking.guest_name}\nReason: ${booking.guest_role_reason}\nHost: ${host}\nVehicle: ${booking.vehicle_plate_number}\nDate: ${booking.date}\nParking: ${space.code}`;
    }
    return `${space.code} · ${space.space_type}`;
  };

  return (
    <div className="relative min-h-[640px] overflow-hidden rounded-3xl border bg-secondary">
      {floor?.map_image_reference ? (
        <img src={floor.map_image_reference} alt={`${floor.name} parking map`} className="absolute inset-0 h-full w-full object-contain" />
      ) : (
        <div className="absolute inset-0 flex items-center justify-center text-center text-sm text-muted-foreground">
          No parking map image uploaded for this floor or zone.
        </div>
      )}

      {spaces.map((space) => {
        const state = getState(space);
        const disabled = state === "booked" || state === "fixed" || state === "blocked";
        return (
          <button
            key={space.id}
            type="button"
            disabled={disabled}
            onClick={() => onSelect(space)}
            className={`absolute flex min-h-7 min-w-7 -translate-x-1/2 -translate-y-1/2 items-center justify-center rounded-full border px-1.5 text-[9px] font-semibold shadow-md transition ${stateStyles[state]}`}
            style={{ left: `${space.x_pos || 50}%`, top: `${space.y_pos || 50}%` }}
            title={getTitle(space)}
          >
            <Car className="h-3 w-3" />
            <span className="ml-1">{space.code}</span>
          </button>
        );
      })}
    </div>
  );
}
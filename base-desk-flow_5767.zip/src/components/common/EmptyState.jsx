import React from "react";

export default function EmptyState({ title, description }) {
  return (
    <div className="rounded-3xl border border-dashed bg-card p-10 text-center">
      <h3 className="text-lg font-semibold">{title}</h3>
      <p className="mx-auto mt-2 max-w-md text-sm text-muted-foreground">{description}</p>
    </div>
  );
}
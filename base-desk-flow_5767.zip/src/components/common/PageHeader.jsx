import React from "react";

export default function PageHeader({ eyebrow, title, description, action }) {
  return (
    <div className="mb-8 flex flex-col justify-between gap-4 md:flex-row md:items-end">
      <div className="max-w-3xl">
        {eyebrow && <p className="mb-2 text-xs font-semibold uppercase tracking-[0.28em] text-primary">{eyebrow}</p>}
        <h2 className="text-3xl font-semibold tracking-tight md:text-5xl">{title}</h2>
        {description && <p className="mt-3 text-sm leading-6 text-muted-foreground md:text-base">{description}</p>}
      </div>
      {action}
    </div>
  );
}
import { Toaster } from "@/components/ui/toaster"
import { QueryClientProvider } from '@tanstack/react-query'
import { queryClientInstance } from '@/lib/query-client'
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import PageNotFound from './lib/PageNotFound';
import { AuthProvider, useAuth } from '@/lib/AuthContext';
import UserNotRegisteredError from '@/components/UserNotRegisteredError';
// Add page imports here
import AppShell from './components/layout/AppShell';
import AdminGate from './components/admin/AdminGate';
import Home from './pages/Home';
import Dashboard from './pages/Dashboard';
import BookDesk from './pages/BookDesk';
import MySchedule from './pages/MySchedule';
import PeopleWhere from './pages/PeopleWhere';
import SetPassword from './pages/SetPassword';
import People from './pages/admin/People';
import Locations from './pages/admin/Locations';
import Floors from './pages/admin/Floors';
import DeskMap from './pages/admin/DeskMap';
import BookParking from './pages/BookParking';
import ParkingMap from './pages/admin/ParkingMap';
import GuestBookings from './pages/admin/GuestBookings';
import Reports from './pages/Reports';
import SrtTests from './pages/admin/SrtTests';
import NotificationsPage from './pages/Notifications';
import AdminNotifications from './pages/admin/Notifications';
import FixedDeskImport from './pages/admin/FixedDeskImport';
import UnavailableEmployees from './pages/admin/UnavailableEmployees';
import PublicHolidays from './pages/admin/PublicHolidays';
import AdminTools from './pages/admin/AdminTools';

const AuthenticatedApp = () => {
  const { isLoadingAuth, isLoadingPublicSettings, authError, navigateToLogin } = useAuth();

  // Show loading spinner while checking app public settings or auth
  if (isLoadingPublicSettings || isLoadingAuth) {
    return (
      <div className="fixed inset-0 flex items-center justify-center">
        <div className="w-8 h-8 border-4 border-slate-200 border-t-slate-800 rounded-full animate-spin"></div>
      </div>
    );
  }

  // Handle authentication errors
  if (authError) {
    if (authError.type === 'user_not_registered') {
      return <UserNotRegisteredError />;
    } else if (authError.type === 'auth_required') {
      // Redirect to login automatically
      navigateToLogin();
      return null;
    }
  }

  // Render the main app
  return (
    <Routes>
      <Route element={<AppShell />}>
        <Route path="/" element={<Dashboard />} />
        <Route path="/phase-1" element={<Home />} />
        <Route path="/book-desk" element={<BookDesk />} />
        <Route path="/book-parking" element={<BookParking />} />
        <Route path="/my-schedule" element={<MySchedule />} />
        <Route path="/people" element={<PeopleWhere />} />
        <Route path="/set-password" element={<SetPassword />} />
        <Route path="/admin/people" element={<AdminGate><People /></AdminGate>} />
        <Route path="/admin/locations" element={<AdminGate><Locations /></AdminGate>} />
        <Route path="/admin/floors" element={<AdminGate><Floors /></AdminGate>} />
        <Route path="/admin/desk-map" element={<AdminGate><DeskMap /></AdminGate>} />
        <Route path="/admin/parking-map" element={<AdminGate><ParkingMap /></AdminGate>} />
        <Route path="/admin/guest-bookings" element={<AdminGate><GuestBookings /></AdminGate>} />
        <Route path="/reports" element={<Reports />} />
        <Route path="/admin/srt-tests" element={<AdminGate><SrtTests /></AdminGate>} />
        <Route path="/notifications" element={<NotificationsPage />} />
        <Route path="/admin/notifications" element={<AdminGate><AdminNotifications /></AdminGate>} />
        <Route path="/admin/fixed-desk-import" element={<AdminGate><FixedDeskImport /></AdminGate>} />
        <Route path="/admin/unavailable-employees" element={<AdminGate><UnavailableEmployees /></AdminGate>} />
        <Route path="/admin/public-holidays" element={<AdminGate><PublicHolidays /></AdminGate>} />
        <Route path="/admin" element={<AdminGate><AdminTools /></AdminGate>} />
      </Route>
      <Route path="*" element={<PageNotFound />} />
    </Routes>
  );
};


function App() {

  return (
    <AuthProvider>
      <QueryClientProvider client={queryClientInstance}>
        <Router>
          <AuthenticatedApp />
        </Router>
        <Toaster />
      </QueryClientProvider>
    </AuthProvider>
  )
}

export default App
// =============================================================================
// PLATFORM HELP KNOWLEDGE BASE — SINGLE SOURCE OF TRUTH (Phase 1 AI Help Assistant)
// =============================================================================
// This file is the canonical help content for the "Platform Assistant" AI agent.
//
// IMPORTANT — SYNCHRONIZATION:
// The same content is embedded into the agent system instructions in
// agents/platform_assistant.json so the agent always has the ground truth.
// If you change anything here, you MUST update agents/platform_assistant.json
// to keep them in sync (see the "// SYNC:" marker block in that file).
//
// SCOPE: read-only navigation / feature / onboarding help only.
// This file contains NO live data, NO entity records, NO private information.
// =============================================================================

export const PLATFORM_NAME = "YOS Workspace Management Platform";

// Roles used across the platform.
export const ROLES = ["Employee", "Team Manager", "Admin"];

// ---------------------------------------------------------------------------
// Navigation map — what each menu item is and where to find it.
// ---------------------------------------------------------------------------
export const NAVIGATION = [
  { label: "Dashboard", path: "/", roles: ["Employee", "Team Manager", "Admin"], summary: "Your home overview: today's status, quick actions, and active platform notifications." },
  { label: "Book Desk", path: "/book-desk", roles: ["Employee", "Team Manager", "Admin"], summary: "Reserve a bookable desk for yourself or a guest on a chosen date." },
  { label: "Book Parking", path: "/book-parking", roles: ["Employee", "Team Manager", "Admin"], summary: "Reserve an employee parking space for yourself or a guest. A vehicle plate number is required." },
  { label: "My Schedule", path: "/my-schedule", roles: ["Employee", "Team Manager", "Admin"], summary: "Set your daily work status (Office / Home Office / Unavailable) and view or release your own bookings." },
  { label: "Who Is Where", path: "/people", roles: ["Employee", "Team Manager", "Admin"], summary: "See colleagues' public work status (Office / Home Office / Unavailable) for a given day." },
  { label: "Notifications", path: "/notifications", roles: ["Employee", "Team Manager", "Admin"], summary: "Read active platform-wide announcements. Urgent/pinned items appear first." },
  { label: "Reports", path: "/reports", roles: ["Team Manager", "Admin"], summary: "Reports & Analytics: attendance, occupancy, desk/parking and guest booking reports. Manager and Admin only." },
  { label: "Admin", path: "/admin", roles: ["Admin"], summary: "Admin tools menu: People, Locations, Floors & Maps, Desk/Parking Maps, Guest Bookings, Notifications Admin, Fixed-Desk Import, Public Holidays, SRT/QA Tests." },
];

// ---------------------------------------------------------------------------
// Feature guides — keyed topics the assistant answers from.
// Each guide is plain navigation/onboarding help. No action execution.
// ---------------------------------------------------------------------------
export const HELP_TOPICS = {
  dashboard: {
    title: "Dashboard",
    roles: ["Employee", "Team Manager", "Admin"],
    body: "The Dashboard is your home screen. It shows your status for today, quick shortcuts to book a desk or parking, and any active platform notifications. Open it from the 'Dashboard' menu item.",
  },
  book_desk: {
    title: "How to book a desk",
    roles: ["Employee", "Team Manager", "Admin"],
    body: "Go to 'Book Desk'. Pick the location, building and floor, choose your date(s), then select an available desk on the floor map and confirm. Booking a desk automatically sets your work status to 'Office' for that date. Only 'Bookable' desks can be reserved — Fixed, Blocked and inactive desks cannot.",
  },
  book_parking: {
    title: "How to book parking",
    roles: ["Employee", "Team Manager", "Admin"],
    body: "Go to 'Book Parking'. Choose location, building and parking zone, pick your date(s), select an available 'Employee Bookable' space, enter your vehicle plate number (required) and confirm. Parking does not require a desk booking and does not set your Office status.",
  },
  my_schedule: {
    title: "My Schedule & work status",
    roles: ["Employee", "Team Manager", "Admin"],
    body: "Open 'My Schedule' to set your daily work status for the next 30 days and to view or release your own bookings. The three statuses are Office, Home Office and Unavailable.",
  },
  home_office: {
    title: "Setting Home Office",
    roles: ["Employee", "Team Manager", "Admin"],
    body: "Open 'My Schedule', choose the date and set the status to 'Home Office'. If you have an active personal desk or parking booking on that date, switching to Home Office will release it after you confirm.",
  },
  unavailable: {
    title: "What 'Unavailable' means",
    roles: ["Employee", "Team Manager", "Admin"],
    body: "'Unavailable' is the only public non-working status. It simply means you are not working in the office or from home on that day. It does NOT reveal any reason. Setting Unavailable releases your active personal desk and parking bookings for that date after confirmation. Guest bookings you host are not affected.",
  },
  desk_released: {
    title: "Why a desk booking was released",
    roles: ["Employee", "Team Manager", "Admin"],
    body: "A personal desk booking is released when you change your status to Home Office or Unavailable for that date (after you confirm), when you release it yourself in My Schedule, or when an Admin sets you as Unavailable. Released desks become available for others to book.",
  },
  guest_bookings: {
    title: "How guest bookings work",
    roles: ["Employee", "Team Manager", "Admin"],
    body: "From Book Desk or Book Parking you can create a booking for a guest by choosing the guest option and entering the guest's name, email, phone and reason/role. Guest bookings do NOT count against your personal booking limit, and they do not set your own Office status. You can host multiple guests on the same day. Changing your own status does not auto-cancel guest bookings you host.",
  },
  who_is_where: {
    title: "Finding colleagues (Who Is Where)",
    roles: ["Employee", "Team Manager", "Admin"],
    body: "Open 'Who Is Where' to see colleagues' public status for a chosen day: Office, Home Office or Unavailable. Only these three public statuses are shown — no private reasons, leave types or personal details are ever displayed.",
  },
  notifications: {
    title: "Notifications",
    roles: ["Employee", "Team Manager", "Admin"],
    body: "Open 'Notifications' to read active platform-wide announcements. Urgent/pinned notices appear at the top. Only Admins can publish or manage notifications.",
  },
  reports: {
    title: "Reports & Analytics",
    roles: ["Team Manager", "Admin"],
    body: "Reports & Analytics live under the 'Reports' menu and are available to Team Managers and Admins only. They include desk bookings, parking bookings, guest bookings, occupancy, team attendance and unavailable insights, with XLSX export. Employees do not have access to Reports.",
    employeeNote: "Reports are available only to Team Managers and Admins. As an Employee you won't see the Reports menu.",
  },
  team_attendance: {
    title: "Team attendance reports",
    roles: ["Team Manager", "Admin"],
    body: "In 'Reports', the team attendance summary shows how your team's days split across Office, Home Office and Unavailable over the retention window. Use the filters to focus on a team or date range, and export to XLSX if needed.",
  },
  admin_tools: {
    title: "Admin tools",
    roles: ["Admin"],
    body: "The 'Admin' menu groups all administrative tools: People (employees & teams), Locations, Floors & Maps, Desk Map, Parking Map, Guest Bookings This Week, Notifications Admin, Fixed-Desk Import, Public Holidays and SRT/QA Tests.",
  },
  add_employee: {
    title: "Adding an employee",
    roles: ["Admin"],
    body: "Open Admin > People. Use the 'Add Employee' form to enter name, email and role, then save. You can optionally send an invitation so the person can activate their account.",
  },
  fixed_desk_import: {
    title: "Fixed-Desk Import",
    roles: ["Admin"],
    body: "Open Admin > Fixed-Desk Import. Upload the XLSX file, review the validation preview and impact summary, choose whether to send invitations, then execute. The import updates fixed-desk assignments and can create new employees referenced in the file.",
  },
  invitations: {
    title: "How invitations work",
    roles: ["Admin"],
    body: "Invitations let new employees activate their account. You can send them from Admin > People or during Fixed-Desk Import. Already-activated users are skipped, pending invitations are only re-sent when you explicitly choose to, and expired/failed ones can be retried.",
  },
  audit_log: {
    title: "Audit Log",
    roles: ["Admin"],
    body: "Administrative actions (such as notification changes, imports and admin-set unavailability) are recorded for accountability. Audit information is Admin-only and is reviewed through the relevant Admin tools.",
  },
  retention_cleanup: {
    title: "Retention & cleanup",
    roles: ["Admin"],
    body: "The platform keeps reporting data within a rolling retention window (about four months) so reports stay relevant. Older records fall outside the reporting window automatically.",
  },
};

// ---------------------------------------------------------------------------
// Role-aware quick-prompt chips shown in the chat UI.
// ---------------------------------------------------------------------------
export const QUICK_PROMPTS = {
  Employee: [
    "How do I book a desk?",
    "How do I book parking?",
    "How do I set Home Office?",
    "What does Unavailable mean?",
    "How do guest bookings work?",
    "Where can I find colleagues?",
  ],
  "Team Manager": [
    "Where are Reports & Analytics?",
    "How do team attendance reports work?",
  ],
  Admin: [
    "How do I add an employee?",
    "How does fixed-desk import work?",
    "How do invitations work?",
    "Where is Audit Log?",
    "How does Retention Cleanup work?",
  ],
};

// ---------------------------------------------------------------------------
// Safe answering rules and refusal copy (kept in sync with the agent config).
// ---------------------------------------------------------------------------
export const REFUSAL_LINE = "I can guide you through the process, but I cannot perform this action for you.";

export const PRIVACY_LINE = "I can't share private information such as leave reasons or personal absence details. The only public work status is Office, Home Office or Unavailable.";

export const FALLBACK_LINE = "I'm not sure that's a feature of this platform. I can help with booking desks or parking, setting your work status, finding colleagues, notifications, and (for the right roles) reports and admin tools.";

// Rotating fun replies for clearly off-topic / non-platform questions.
// The assistant picks ONE of these at random for such questions.
export const OFFTOPIC_REPLIES = [
  "Miroslav built this platform; he is a cool guy.",
  "I don't know what to say, so I recommend you visit www.podzemno.com for a clean underground parking.",
  "The Ordering Engine team is amazing and all-mighty.",
  "Goliam si Koce.",
  "Have you seen a bear in real life?",
  "I'm just a humble Help Assistant — but for anything off-topic, ask Miroslav, he knows everything.",
];

export default {
  PLATFORM_NAME,
  ROLES,
  NAVIGATION,
  HELP_TOPICS,
  QUICK_PROMPTS,
  REFUSAL_LINE,
  PRIVACY_LINE,
  FALLBACK_LINE,
  OFFTOPIC_REPLIES,
};
export const deskTypes = ["Fixed", "Bookable", "Blocked"];

export const emptyDesk = {
  code: "",
  desk_type: "Bookable",
  assigned_team_id: "",
  assigned_employee_id: "",
  block_reason: "",
  x_pos: 50,
  y_pos: 50,
  capacity: 1,
  equipment: "",
  accessibility_notes: "",
  is_active: true,
};

export const createDeskPayload = (desk, floor) => ({
  ...desk,
  location_id: floor.location_id,
  building_id: floor.building_id,
  floor_id: floor.id,
  assigned_team_id: desk.desk_type === "Fixed" ? desk.assigned_team_id : "",
  assigned_employee_id: desk.desk_type === "Fixed" ? desk.assigned_employee_id : "",
  block_reason: desk.desk_type === "Blocked" ? desk.block_reason : "",
});

export const isDuplicateCode = (desks, floorId, code, ignoreId) =>
  desks.some((desk) => desk.floor_id === floorId && desk.id !== ignoreId && String(desk.code).trim() === String(code).trim());

export const getPercentFromClick = (event) => {
  // Prefer pre-computed values from the canvas (anchored to the image, not the container)
  if (event && event._computed) return event._computed;
  const rect = event.currentTarget.getBoundingClientRect();
  return {
    x_pos: Math.max(0, Math.min(100, Math.round(((event.clientX - rect.left) / rect.width) * 1000) / 10)),
    y_pos: Math.max(0, Math.min(100, Math.round(((event.clientY - rect.top) / rect.height) * 1000) / 10)),
  };
};
export const getEmployeeByUser = (employees, user) => {
  const email = user?.email?.trim().toLowerCase();
  return employees.find((employee) => employee.email?.trim().toLowerCase() === email && employee.is_active !== false);
};

export const isGuestBooking = (booking) => booking?.owner_type === "Guest";

export const activeBookingsForEmployee = (bookings, employeeId) =>
  bookings.filter((booking) => booking.employee_id === employeeId && booking.status === "Active" && !isGuestBooking(booking));

export const activeGuestBookingsForHost = (bookings, employeeId) =>
  bookings.filter((booking) => booking.status === "Active" && isGuestBooking(booking) && (booking.host_employee_id === employeeId || booking.employee_id === employeeId));

export const getActiveBookingForDate = (bookings, employeeId, date) =>
  bookings.find((booking) => booking.employee_id === employeeId && booking.date === date && booking.status === "Active" && !isGuestBooking(booking));

export const getDeskLabel = (desk) => desk?.code || "Desk";

export const findById = (items, id) => items.find((item) => item.id === id);

export const buildPlaceLabel = ({ desk, locations, buildings, floors }) => {
  if (!desk) return "No desk";
  const location = findById(locations, desk.location_id)?.name;
  const building = findById(buildings, desk.building_id)?.name;
  const floor = findById(floors, desk.floor_id)?.name;
  return [location, building, floor, desk.code].filter(Boolean).join(" / ");
};

export const getDailyStatusForDate = (statuses, employeeId, date) =>
  statuses.find((status) => status.employee_id === employeeId && status.date === date);

export const countGuestBookingsOnDate = (deskBookings, parkingBookings, employeeId, date) => {
  const isHostGuest = (booking) =>
    booking.status === "Active" &&
    isGuestBooking(booking) &&
    booking.date === date &&
    (booking.host_employee_id === employeeId || booking.employee_id === employeeId);
  return (deskBookings || []).filter(isHostGuest).length + (parkingBookings || []).filter(isHostGuest).length;
};

export const getDeskAvailability = ({ desk, selectedDates, activeBookings, employeeId }) => {
  if (!desk || desk.is_active === false) return { state: "blocked", conflicts: selectedDates };
  if (desk.desk_type === "Blocked") return { state: "blocked", conflicts: selectedDates };
  if (desk.desk_type === "Fixed") return { state: "fixed", conflicts: selectedDates };

  const mine = selectedDates.length > 0 && selectedDates.every((date) =>
    activeBookings.some((booking) => booking.desk_id === desk.id && booking.date === date && booking.employee_id === employeeId && !isGuestBooking(booking))
  );
  if (mine) return { state: "mine", conflicts: [] };

  const conflicts = selectedDates.filter((date) =>
    activeBookings.some((booking) => booking.desk_id === desk.id && booking.date === date)
  );
  if (conflicts.length) return { state: "booked", conflicts };

  return { state: "available", conflicts: [] };
};
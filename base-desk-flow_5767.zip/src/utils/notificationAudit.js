import { base44 } from "@/api/base44Client";

// Writes an AuditLog row for an admin notification action.
// Action types: "Notification created" | "Notification edited" | "Notification deactivated" | "Notification reactivated" | "Notification pinned" | "Notification unpinned"
export async function logNotificationAudit({ action_type, notification, reason = "" }) {
  try {
    const user = await base44.auth.me().catch(() => null);
    await base44.entities.AuditLog.create({
      actor_user_id: user?.id || "",
      action_type,
      affected_object_type: "Notification",
      affected_object_id: notification?.id || "",
      summary: `${action_type}: ${notification?.title || "(untitled)"}`,
      reason,
      status: "success",
      timestamp: new Date().toISOString(),
    });
  } catch (_e) {
    // Audit failures must not block the user's primary action.
  }
}
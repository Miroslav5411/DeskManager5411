import { format, startOfMonth, endOfMonth, subMonths, max as dateMax } from "date-fns";

export const RETENTION_MONTHS = 4;

export const getRetentionCutoffDate = () => {
  const now = new Date();
  return startOfMonth(subMonths(now, RETENTION_MONTHS - 1));
};

export const getMonthOptions = () => {
  const now = new Date();
  return Array.from({ length: RETENTION_MONTHS }, (_, index) => {
    const date = subMonths(now, index);
    return {
      key: format(date, "yyyy-MM"),
      label: format(date, "MMMM yyyy"),
    };
  });
};

export const getMonthRange = (monthKey) => {
  const [year, month] = monthKey.split("-").map(Number);
  const start = new Date(year, month - 1, 1);
  const end = endOfMonth(start);
  const cutoff = getRetentionCutoffDate();
  const effectiveStart = dateMax([start, cutoff]);
  return {
    start: format(effectiveStart, "yyyy-MM-dd"),
    end: format(end, "yyyy-MM-dd"),
  };
};

export const isWithinRetention = (dateStr) => {
  if (!dateStr) return false;
  const cutoff = format(getRetentionCutoffDate(), "yyyy-MM-dd");
  return dateStr >= cutoff;
};
import * as XLSX from "xlsx";

export const exportRowsToXlsx = ({ rows, columns, sheetName = "Report", fileName = "report.xlsx" }) => {
  const data = rows.map((row) => {
    const formatted = {};
    columns.forEach((col) => {
      const value = typeof col.accessor === "function" ? col.accessor(row) : row[col.accessor];
      formatted[col.header] = value === null || value === undefined ? "" : value;
    });
    return formatted;
  });
  const worksheet = XLSX.utils.json_to_sheet(data);
  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, worksheet, sheetName.slice(0, 31));
  XLSX.writeFile(workbook, fileName);
};
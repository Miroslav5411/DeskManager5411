// Pure helpers for the Notification entity. No I/O, no React deps.
// Imported from frontend AND mirrored inline in the SRT runner.

export const NOTIFICATION_CATEGORIES = [
  "Event",
  "Safety",
  "Maintenance",
  "Parking",
  "HR",
  "Urgent",
  "General",
];

const CATEGORIES_SET = new Set(NOTIFICATION_CATEGORIES);

// Returns { ok: true } or { ok: false, message: string }
export function validateNotificationPayload(payload) {
  if (!payload) return { ok: false, message: "Missing notification payload." };
  const title = (payload.title || "").trim();
  const body = (payload.body || "").trim();
  const category = payload.category;
  const start = payload.start_date;
  const end = payload.end_date;

  if (!title) return { ok: false, message: "Title is required." };
  if (!body) return { ok: false, message: "Body is required." };
  if (!category) return { ok: false, message: "Category is required." };
  if (!CATEGORIES_SET.has(category)) {
    return { ok: false, message: `Invalid category "${category}".` };
  }
  if (!start) return { ok: false, message: "Start date is required." };
  if (!end) return { ok: false, message: "End date is required." };
  if (end < start) return { ok: false, message: "End date cannot be before start date." };
  return { ok: true };
}

// Returns YYYY-MM-DD in local time (matches start_date / end_date format).
export function todayKey() {
  const d = new Date();
  const yyyy = d.getFullYear();
  const mm = String(d.getMonth() + 1).padStart(2, "0");
  const dd = String(d.getDate()).padStart(2, "0");
  return `${yyyy}-${mm}-${dd}`;
}

// True if a notification should currently be visible to users.
// Rules: is_active === true AND start_date <= today <= end_date.
export function isNotificationVisibleNow(n, today = todayKey()) {
  if (!n) return false;
  if (n.is_active !== true) return false;
  if (!n.start_date || !n.end_date) return false;
  return n.start_date <= today && today <= n.end_date;
}

// Sort: pinned first, then most recent start_date first, then title.
export function sortNotificationsForDisplay(list = []) {
  return [...list].sort((a, b) => {
    const aPinned = a.is_pinned ? 1 : 0;
    const bPinned = b.is_pinned ? 1 : 0;
    if (aPinned !== bPinned) return bPinned - aPinned;
    const aStart = a.start_date || "";
    const bStart = b.start_date || "";
    if (aStart !== bStart) return aStart < bStart ? 1 : -1;
    return (a.title || "").localeCompare(b.title || "");
  });
}

// Convenience: filter active list and sort it for the user-facing surfaces.
export function buildVisibleNotifications(allNotifications = [], today = todayKey()) {
  const visible = (allNotifications || []).filter((n) => isNotificationVisibleNow(n, today));
  return sortNotificationsForDisplay(visible);
}
// Pure helpers for the "Unavailable Insights" report.
// No private absence reasons are ever read or returned. Only DailyWorkStatus
// where status_type === "Unavailable".

import { isWithinRetention } from "@/utils/reportWindow";

export const UNAVAILABLE = "Unavailable";

export const todayStr = () => {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
};

export const addDays = (dateStr, n) => {
  const d = new Date(`${dateStr}T00:00:00`);
  d.setDate(d.getDate() + n);
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
};

// Mon..Fri only. Saturday/Sunday are not "working days".
export const isWorkingDay = (dateStr) => {
  const d = new Date(`${dateStr}T00:00:00`);
  const day = d.getDay();
  return day >= 1 && day <= 5;
};

export const previousWorkingDay = (dateStr) => {
  let cur = addDays(dateStr, -1);
  while (!isWorkingDay(cur)) cur = addDays(cur, -1);
  return cur;
};

export const nextWorkingDay = (dateStr) => {
  let cur = addDays(dateStr, 1);
  while (!isWorkingDay(cur)) cur = addDays(cur, 1);
  return cur;
};

// Returns the first N working days strictly before `dateStr`.
export const previousWorkingDays = (dateStr, n) => {
  const out = [];
  let cur = dateStr;
  while (out.length < n) {
    cur = previousWorkingDay(cur);
    out.push(cur);
  }
  return out;
};

export const nextWorkingDays = (dateStr, n) => {
  const out = [];
  let cur = dateStr;
  while (out.length < n) {
    cur = nextWorkingDay(cur);
    out.push(cur);
  }
  return out;
};

// Apply retention window + Unavailable + filters to the raw status list.
// Filters arg = { dateFrom, dateTo, team, department, location, building, manager, source }
export const filterUnavailableRows = (statuses, employees, filters) => {
  const empById = new Map(employees.map((e) => [e.id, e]));
  return statuses
    .filter((s) => s.status_type === UNAVAILABLE)
    .filter((s) => isWithinRetention(s.date))
    .filter((s) => !filters.dateFrom || s.date >= filters.dateFrom)
    .filter((s) => !filters.dateTo || s.date <= filters.dateTo)
    .filter((s) => {
      if (!filters.source) return true;
      const src = s.source || "Manual";
      return src === filters.source;
    })
    .filter((s) => {
      const emp = empById.get(s.employee_id);
      if (!emp) return false;
      if (filters.team && emp.team_id !== filters.team) return false;
      if (filters.department && emp.department !== filters.department) return false;
      if (filters.manager && emp.manager_id !== filters.manager) return false;
      if (filters.location && emp.default_location_id !== filters.location) return false;
      if (filters.building && emp.default_building_id !== filters.building) return false;
      return true;
    });
};

export const countUnavailableOnDates = (statuses, dates) => {
  const set = new Set(dates);
  const seen = new Set(); // employee_id+date dedupe
  let n = 0;
  for (const s of statuses) {
    if (s.status_type !== UNAVAILABLE) continue;
    if (!set.has(s.date)) continue;
    const k = `${s.employee_id}|${s.date}`;
    if (seen.has(k)) continue;
    seen.add(k);
    n += 1;
  }
  return n;
};

// Distinct employee count for unavailable-on-the-given-dates.
export const distinctUnavailableEmployees = (statuses, dates) => {
  const set = new Set(dates);
  const ids = new Set();
  for (const s of statuses) {
    if (s.status_type !== UNAVAILABLE) continue;
    if (!set.has(s.date)) continue;
    ids.add(s.employee_id);
  }
  return ids.size;
};

export const buildHolidayProximity = ({ holiday, statuses, activeEmployeeCount }) => {
  const date = holiday.holiday_date;
  const prev = previousWorkingDay(date);
  const next = nextWorkingDay(date);
  const prev2 = previousWorkingDays(date, 2);
  const next2 = nextWorkingDays(date, 2);

  const prevCount = distinctUnavailableEmployees(statuses, [prev]);
  const onCount = distinctUnavailableEmployees(statuses, [date]);
  const nextCount = distinctUnavailableEmployees(statuses, [next]);
  const prev2Count = distinctUnavailableEmployees(statuses, prev2);
  const next2Count = distinctUnavailableEmployees(statuses, next2);

  const window = Array.from(new Set([...prev2, date, ...next2]));
  const aroundCount = distinctUnavailableEmployees(statuses, window);
  const pct = activeEmployeeCount > 0 ? Math.round((aroundCount / activeEmployeeCount) * 1000) / 10 : 0;

  return {
    holidayName: holiday.holiday_name,
    holidayDate: date,
    prevWorkingDay: prev,
    nextWorkingDay: next,
    prevCount,
    onCount,
    nextCount,
    prev2Count,
    next2Count,
    aroundCount,
    aroundPct: pct,
  };
};
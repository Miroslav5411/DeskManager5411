import { findById } from "@/utils/deskFlow";

export const buildLookups = ({ employees = [], teams = [], locations = [], buildings = [], floors = [], desks = [], parkingSpaces = [] }) => ({
  employee: (id) => findById(employees, id),
  team: (id) => findById(teams, id),
  location: (id) => findById(locations, id),
  building: (id) => findById(buildings, id),
  floor: (id) => findById(floors, id),
  desk: (id) => findById(desks, id),
  parkingSpace: (id) => findById(parkingSpaces, id),
});

export const employeeName = (lookups, id) => lookups.employee(id)?.name || "—";
export const teamName = (lookups, id) => lookups.team(id)?.name || "—";
export const locationName = (lookups, id) => lookups.location(id)?.name || "—";
export const buildingName = (lookups, id) => lookups.building(id)?.name || "—";
export const floorName = (lookups, id) => lookups.floor(id)?.name || "—";

export const formatTimestamp = (value) => (value ? new Date(value).toLocaleString() : "");

export const isInMonth = (dateStr, monthKey) => dateStr?.startsWith(monthKey);

export const toOptions = (items, labelFn = (i) => i.name) =>
  items.filter((i) => i.is_active !== false).map((i) => ({ value: i.id, label: labelFn(i) }));
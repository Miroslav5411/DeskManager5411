import { addDays, format } from "date-fns";

export const toDateKey = (date) => format(date, "yyyy-MM-dd");

export const getRollingDateWindow = (days = 30) =>
  Array.from({ length: days }, (_, index) => {
    const date = addDays(new Date(), index);
    return {
      key: toDateKey(date),
      label: format(date, "EEE, MMM d"),
      shortLabel: format(date, "MMM d"),
    };
  });

export const todayKey = () => toDateKey(new Date());
export const ROLES = {
  EMPLOYEE: "Employee",
  TEAM_MANAGER: "Team Manager",
  ADMIN: "Admin",
};

export const ROLE_OPTIONS = [ROLES.EMPLOYEE, ROLES.TEAM_MANAGER, ROLES.ADMIN];

export const canManageAdmin = (employee) => employee?.role === ROLES.ADMIN;
export const canViewReports = (employee) => employee?.role === ROLES.ADMIN || employee?.role === ROLES.TEAM_MANAGER;

export const normalizeEmail = (email = "") => email.trim().toLowerCase();

// Single source of truth for valid DailyWorkStatus.status_type values across the app.
// Any code path that creates, updates, or displays a DailyWorkStatus MUST consult
// this list. Values outside this set must be rejected on write and hidden on read.
export const ALLOWED_WORK_STATUSES = ["Office", "Home Office", "Unavailable"];
const ALLOWED_WORK_STATUSES_SET = new Set(ALLOWED_WORK_STATUSES);

export const isAllowedWorkStatus = (statusType) => ALLOWED_WORK_STATUSES_SET.has(statusType);

// Throws a clear error if the status_type is not one of the allowed values.
// Use at the start of every mutation that touches DailyWorkStatus.
export const assertAllowedWorkStatus = (statusType) => {
  if (!isAllowedWorkStatus(statusType)) {
    throw new Error(`Invalid work status "${statusType}". Allowed: ${ALLOWED_WORK_STATUSES.join(", ")}.`);
  }
};

export const validateManualOfficeStatus = (employee) => {
  if (!employee?.fixed_desk_id) {
    return {
      allowed: false,
      message: "Non-fixed employees must book a desk to create Office status.",
      redirectTo: "/admin/desk-map",
    };
  }

  return { allowed: true };
};
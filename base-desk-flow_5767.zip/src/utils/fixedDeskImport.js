// Shared validation + impact utilities for the Fixed-Desk XLSX import.
// Used by the frontend (pre-flight validation) and mirrored by the backend
// (re-validation immediately before execution).

import { normalizeEmail } from "@/utils/workspaceRules";

export const REQUIRED_COLUMNS = [
  "employee_email",
  "employee_name",
  "team_name",
  "location_name",
  "building_name",
  "floor_name",
  "desk_code",
];

export const TEMPLATE_ROW = {
  employee_email: "jane.doe@example.com",
  employee_name: "Jane Doe",
  team_name: "Engineering",
  location_name: "HQ",
  building_name: "Main",
  floor_name: "Floor 2",
  desk_code: "D-201",
};

const trim = (v) => (v == null ? "" : String(v).trim());

export function validateColumns(headers) {
  const set = new Set((headers || []).map((h) => trim(h)));
  const missing = REQUIRED_COLUMNS.filter((c) => !set.has(c));
  return { ok: missing.length === 0, missing, headers: headers || [] };
}

function indexBy(list, keyFn) {
  const m = new Map();
  for (const item of list || []) {
    const k = keyFn(item);
    if (k != null && k !== "") m.set(k, item);
  }
  return m;
}

function buildCatalogIndexes(catalog) {
  const locationByName = indexBy(catalog.locations, (l) => trim(l.name).toLowerCase());
  const buildingByLocAndName = new Map();
  for (const b of catalog.buildings || []) {
    buildingByLocAndName.set(`${b.location_id}::${trim(b.name).toLowerCase()}`, b);
  }
  const floorByBuildingAndName = new Map();
  for (const f of catalog.floors || []) {
    floorByBuildingAndName.set(`${f.building_id}::${trim(f.name).toLowerCase()}`, f);
  }
  const deskByFloorAndCode = new Map();
  for (const d of catalog.desks || []) {
    deskByFloorAndCode.set(`${d.floor_id}::${trim(d.code).toLowerCase()}`, d);
  }
  const teamByName = indexBy(catalog.teams, (t) => trim(t.name).toLowerCase());
  const employeeByEmail = indexBy(catalog.employees, (e) => normalizeEmail(e.email));
  return {
    locationByName,
    buildingByLocAndName,
    floorByBuildingAndName,
    deskByFloorAndCode,
    teamByName,
    employeeByEmail,
  };
}

export function validateRows(rawRows, catalog) {
  const idx = buildCatalogIndexes(catalog);
  const rowErrors = [];
  const parsedRows = [];
  const seenDeskIds = new Set();
  const seenEmails = new Set();

  (rawRows || []).forEach((row, i) => {
    const rowNumber = i + 2; // header is row 1
    const errors = [];

    const emailRaw = trim(row.employee_email);
    const name = trim(row.employee_name);
    const teamName = trim(row.team_name);
    const locName = trim(row.location_name);
    const bldName = trim(row.building_name);
    const floorName = trim(row.floor_name);
    const deskCode = trim(row.desk_code);

    if (!emailRaw) errors.push("employee_email is required");
    if (!name) errors.push("employee_name is required");
    if (!locName) errors.push("location_name is required");
    if (!bldName) errors.push("building_name is required");
    if (!floorName) errors.push("floor_name is required");
    if (!deskCode) errors.push("desk_code is required");

    const email = normalizeEmail(emailRaw);
    if (email && seenEmails.has(email)) {
      errors.push(`duplicate employee_email "${emailRaw}" in file`);
    }
    if (email) seenEmails.add(email);

    const location = locName ? idx.locationByName.get(locName.toLowerCase()) : null;
    if (locName && !location) errors.push(`location "${locName}" not found`);

    let building = null;
    if (location && bldName) {
      building = idx.buildingByLocAndName.get(`${location.id}::${bldName.toLowerCase()}`);
      if (!building) errors.push(`building "${bldName}" not found in location "${locName}"`);
    }

    let floor = null;
    if (building && floorName) {
      floor = idx.floorByBuildingAndName.get(`${building.id}::${floorName.toLowerCase()}`);
      if (!floor) errors.push(`floor "${floorName}" not found in building "${bldName}"`);
    }

    let desk = null;
    if (floor && deskCode) {
      desk = idx.deskByFloorAndCode.get(`${floor.id}::${deskCode.toLowerCase()}`);
      if (!desk) errors.push(`desk "${deskCode}" not found on floor "${floorName}"`);
    }

    if (desk) {
      if (seenDeskIds.has(desk.id)) {
        errors.push(`desk "${deskCode}" assigned more than once in file`);
      }
      seenDeskIds.add(desk.id);
    }

    let team = null;
    if (teamName) {
      team = idx.teamByName.get(teamName.toLowerCase());
      if (!team) errors.push(`team "${teamName}" not found`);
    }

    if (errors.length) {
      rowErrors.push({ row: rowNumber, message: errors.join("; ") });
    } else {
      parsedRows.push({
        rowNumber,
        email,
        name,
        team,
        location,
        building,
        floor,
        desk,
      });
    }
  });

  return { rowErrors, parsedRows };
}

export function buildImpactSummary(parsedRows, catalog) {
  const idx = buildCatalogIndexes(catalog);
  const targetEmails = new Set(parsedRows.map((r) => r.email));
  const targetDeskIds = new Set(parsedRows.map((r) => r.desk.id));

  let newEmployees = 0;
  let employeesChanging = 0;
  let employeesLosing = 0;

  for (const r of parsedRows) {
    const existing = idx.employeeByEmail.get(r.email);
    if (!existing) {
      newEmployees++;
    } else if (existing.fixed_desk_id && existing.fixed_desk_id !== r.desk.id) {
      employeesChanging++;
    }
  }

  for (const e of catalog.employees || []) {
    if (!e.fixed_desk_id) continue;
    const stillAssigned = targetEmails.has(normalizeEmail(e.email)) &&
      parsedRows.find((r) => r.email === normalizeEmail(e.email))?.desk?.id === e.fixed_desk_id;
    if (!stillAssigned) employeesLosing++;
  }

  const locations = new Set(parsedRows.map((r) => r.location.id));
  const buildings = new Set(parsedRows.map((r) => r.building.id));
  const floors = new Set(parsedRows.map((r) => r.floor.id));

  return {
    rowsProcessed: parsedRows.length,
    assignmentsApplied: parsedRows.length,
    assignmentsRemoved: targetDeskIds.size, // cleared before re-apply
    newEmployees,
    employeesChanging,
    employeesLosing,
    locations: locations.size,
    buildings: buildings.size,
    floors: floors.size,
  };
}
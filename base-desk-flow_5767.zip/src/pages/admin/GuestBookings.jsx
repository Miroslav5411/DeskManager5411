import React, { useState, useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import { format, addDays, startOfWeek } from "date-fns";
import { base44 } from "@/api/base44Client";
import PageHeader from "@/components/common/PageHeader";
import KpiRow from "@/components/reports/KpiRow";
import ReportFilters from "@/components/reports/ReportFilters";
import ReportTable from "@/components/reports/ReportTable";
import { exportRowsToXlsx } from "@/utils/reportExport";
import { buildLookups, employeeName, teamName, locationName, buildingName, formatTimestamp, toOptions } from "@/utils/reportData";
import { isGuestBooking } from "@/utils/deskFlow";
import { todayKey } from "@/utils/dateWindow";

const TYPE_OPTIONS = [
  { value: "Desk", label: "Desk" },
  { value: "Parking", label: "Parking" },
];

const STATUS_OPTIONS = [
  { value: "Active", label: "Active" },
  { value: "Cancelled", label: "Cancelled" },
  { value: "Released by User", label: "Released by User" },
  { value: "Cancelled by Host", label: "Cancelled by Host" },
];

const getWeekRange = () => {
  const monday = startOfWeek(new Date(), { weekStartsOn: 1 });
  const sunday = addDays(monday, 6);
  return { start: format(monday, "yyyy-MM-dd"), end: format(sunday, "yyyy-MM-dd") };
};

export default function GuestBookings() {
  const [filters, setFilters] = useState({
    month: "current-week",
    booking_type: "",
    arrival_date: "",
    host: "",
    team: "",
    location: "",
    building: "",
    status: "Active",
  });

  const { data, isLoading } = useQuery({
    queryKey: ["admin-guest-bookings"],
    queryFn: async () => ({
      deskBookings: await base44.entities.DeskBooking.list("-created_date", 5000),
      parkingBookings: await base44.entities.ParkingBooking.list("-created_date", 5000),
      employees: await base44.entities.Employee.list(),
      teams: await base44.entities.Team.list(),
      locations: await base44.entities.Location.list(),
      buildings: await base44.entities.Building.list(),
      floors: await base44.entities.FloorZone.list(),
      desks: await base44.entities.Desk.list("-created_date", 5000),
      parkingSpaces: await base44.entities.ParkingSpace.list("-created_date", 5000),
    }),
  });

  const lookups = useMemo(() => (data ? buildLookups(data) : null), [data]);

  const { rows, kpis, dateOptions } = useMemo(() => {
    if (!data || !lookups) return { rows: [], kpis: [], dateOptions: [] };
    const { start, end } = getWeekRange();
    const today = todayKey();

    const buildRow = (booking, type) => {
      const hostId = booking.host_employee_id || booking.employee_id;
      return {
        id: `${type}-${booking.id}`,
        booking_type: type,
        date: booking.date,
        host: employeeName(lookups, hostId),
        host_team: teamName(lookups, lookups.employee(hostId)?.team_id),
        guest_name: booking.guest_name || "—",
        guest_role: booking.guest_role_reason || "",
        guest_email: booking.guest_email || "",
        guest_phone: booking.guest_phone || "",
        location: locationName(lookups, booking.location_id),
        building: buildingName(lookups, booking.building_id),
        floor_zone: type === "Desk" ? lookups.floor(booking.floor_id)?.name || "—" : lookups.floor(booking.floor_zone_id)?.name || "—",
        resource: type === "Desk" ? lookups.desk(booking.desk_id)?.code || "—" : lookups.parkingSpace(booking.parking_space_id)?.code || "—",
        plate: type === "Parking" ? booking.vehicle_plate_number || "" : "",
        status: booking.status,
        created_at: formatTimestamp(booking.created_date),
        host_id: hostId,
        location_id: booking.location_id,
        building_id: booking.building_id,
      };
    };

    const all = [
      ...data.deskBookings.filter(isGuestBooking).map((b) => buildRow(b, "Desk")),
      ...data.parkingBookings.filter(isGuestBooking).map((b) => buildRow(b, "Parking")),
    ].filter((r) => r.date >= start && r.date <= end && r.date >= today);

    const filtered = all
      .filter((r) => !filters.booking_type || r.booking_type === filters.booking_type)
      .filter((r) => !filters.arrival_date || r.date === filters.arrival_date)
      .filter((r) => !filters.host || r.host_id === filters.host)
      .filter((r) => !filters.team || lookups.employee(r.host_id)?.team_id === filters.team)
      .filter((r) => !filters.location || r.location_id === filters.location)
      .filter((r) => !filters.building || r.building_id === filters.building)
      .filter((r) => !filters.status || r.status === filters.status)
      .sort((a, b) => a.date.localeCompare(b.date) || a.host.localeCompare(b.host));

    const kpiList = [
      { label: "Total this week", value: filtered.length },
      { label: "Guest desk", value: filtered.filter((r) => r.booking_type === "Desk").length },
      { label: "Guest parking", value: filtered.filter((r) => r.booking_type === "Parking").length },
      { label: "Today", value: filtered.filter((r) => r.date === today).length },
    ];

    const dateOpts = Array.from({ length: 7 }, (_, i) => {
      const date = format(addDays(new Date(start), i), "yyyy-MM-dd");
      return { value: date, label: date };
    }).filter((d) => d.value >= today);

    return { rows: filtered, kpis: kpiList, dateOptions: dateOpts };
  }, [data, filters, lookups]);

  if (isLoading) return <div className="py-12 text-center text-muted-foreground">Loading guest bookings...</div>;

  const columns = [
    { header: "Arrival date", accessor: "date" },
    { header: "Type", accessor: "booking_type" },
    { header: "Host", accessor: "host" },
    { header: "Host team", accessor: "host_team" },
    { header: "Guest", accessor: "guest_name" },
    { header: "Reason", accessor: "guest_role" },
    { header: "Email", accessor: "guest_email" },
    { header: "Phone", accessor: "guest_phone" },
    { header: "Location", accessor: "location" },
    { header: "Building", accessor: "building" },
    { header: "Floor / Zone", accessor: "floor_zone" },
    { header: "Resource", accessor: "resource" },
    { header: "Vehicle plate", accessor: "plate" },
    { header: "Status", accessor: "status" },
    { header: "Created", accessor: "created_at" },
  ];

  const fields = [
    { key: "booking_type", label: "Booking type", options: TYPE_OPTIONS },
    { key: "arrival_date", label: "Arrival date", options: dateOptions },
    { key: "host", label: "Host", options: toOptions(data.employees) },
    { key: "team", label: "Host team", options: toOptions(data.teams) },
    { key: "location", label: "Location", options: toOptions(data.locations) },
    { key: "building", label: "Building", options: toOptions(data.buildings) },
    { key: "status", label: "Status", options: STATUS_OPTIONS },
  ];

  const handleExport = () => {
    exportRowsToXlsx({
      rows,
      columns,
      sheetName: "Guest Bookings Week",
      fileName: `guest-bookings-this-week.xlsx`,
    });
  };

  return (
    <div>
      <PageHeader
        eyebrow="Admin"
        title="Guest Bookings This Week"
        description="Upcoming guest desk and parking bookings between Monday and Sunday of the current week."
      />
      <KpiRow kpis={kpis} />
      <ReportFilters
        filters={filters}
        onChange={setFilters}
        fields={fields}
        onExport={handleExport}
        exportDisabled={!rows.length}
        hideMonth
      />
      <ReportTable columns={columns} rows={rows} emptyMessage="No guest bookings match the filters." />
    </div>
  );
}
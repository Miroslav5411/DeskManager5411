import React, { useEffect, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import * as XLSX from "xlsx";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Upload, CheckCircle2, ShieldAlert, RotateCcw } from "lucide-react";
import { useToast } from "@/components/ui/use-toast";
import PageHeader from "@/components/common/PageHeader";
import ImportTemplateBlock from "@/components/admin/import/ImportTemplateBlock";
import RowErrorsList from "@/components/admin/import/RowErrorsList";
import ImpactSummaryCard from "@/components/admin/import/ImpactSummaryCard";
import InvitationPlanTable from "@/components/admin/import/InvitationPlanTable";
import ImportInvitationOptions from "@/components/admin/import/ImportInvitationOptions";
import InvitationSummaryGrid from "@/components/admin/import/InvitationSummaryGrid";
import {
  REQUIRED_COLUMNS,
  validateColumns,
} from "@/utils/fixedDeskImport";

const Stat = ({ label, value }) => (
  <div className="rounded-xl border bg-card p-4">
    <p className="text-xs uppercase tracking-wide text-muted-foreground">{label}</p>
    <p className="mt-1 text-2xl font-semibold">{value}</p>
  </div>
);

export default function FixedDeskImport() {
  const { toast } = useToast();
  const [fileName, setFileName] = useState("");
  const [headers, setHeaders] = useState([]);
  const [rows, setRows] = useState([]);
  const [columnsCheck, setColumnsCheck] = useState(null);
  const [rowErrors, setRowErrors] = useState([]);
  const [impact, setImpact] = useState(null);
  const [invitationPlan, setInvitationPlan] = useState([]);
  const [invitationSummary, setInvitationSummary] = useState(null);
  const [sendInvitations, setSendInvitations] = useState(false);
  const [resendExpiredOrFailed, setResendExpiredOrFailed] = useState(false);
  const [resendPending, setResendPending] = useState(false);
  const [executing, setExecuting] = useState(false);
  const [previewing, setPreviewing] = useState(false);
  const [executionResult, setExecutionResult] = useState(null);

  const { data: catalog, refetch: refetchCatalog } = useQuery({
    queryKey: ["fixed-desk-import-catalog"],
    queryFn: async () => {
      const [locations, buildings, floors, desks, teams, employees] = await Promise.all([
        base44.entities.Location.list(),
        base44.entities.Building.list(),
        base44.entities.FloorZone.list(),
        base44.entities.Desk.list("-created_date", 5000),
        base44.entities.Team.list(),
        base44.entities.Employee.list("-created_date", 5000),
      ]);
      return { locations, buildings, floors, desks, teams, employees };
    },
  });

  const reset = () => {
    setFileName("");
    setHeaders([]);
    setRows([]);
    setColumnsCheck(null);
    setRowErrors([]);
    setImpact(null);
    setInvitationPlan([]);
    setInvitationSummary(null);
    setExecutionResult(null);
  };

  const runPreview = async (nextRows = rows, nextHeaders = headers) => {
    if (!nextRows.length || !nextHeaders.length) return;
    setPreviewing(true);
    const res = await base44.functions.invoke("runFixedDeskImport", {
      mode: "preview",
      fileName,
      headers: nextHeaders,
      rows: nextRows,
      sendInvitations,
      resendExpiredOrFailed,
      resendPending,
    });
    if (res.data?.ok) {
      setRowErrors([]);
      setImpact({ ...res.data.impact, ...res.data.invitationSummary });
      setInvitationPlan(res.data.invitationPlan || []);
      setInvitationSummary(res.data.invitationSummary || null);
    } else if (res.data?.stage === "rows") {
      setRowErrors(res.data.rowErrors || []);
      setImpact(null);
      setInvitationPlan([]);
      setInvitationSummary(null);
    } else if (res.data?.stage === "headers") {
      setColumnsCheck({ ok: false, missing: res.data.missingColumns, headers: nextHeaders });
      setImpact(null);
    }
    setPreviewing(false);
  };

  useEffect(() => {
    if (columnsCheck?.ok && rows.length) runPreview();
  }, [sendInvitations, resendExpiredOrFailed, resendPending]);

  const handleFile = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (!file.name.toLowerCase().endsWith(".xlsx")) {
      toast({ title: "Only .xlsx files are accepted", variant: "destructive" });
      e.target.value = "";
      return;
    }
    setFileName(file.name);
    setExecutionResult(null);

    const buf = await file.arrayBuffer();
    const wb = XLSX.read(buf, { type: "array" });
    const ws = wb.Sheets[wb.SheetNames[0]];
    const json = XLSX.utils.sheet_to_json(ws, { defval: "" });
    const sheetHeaders = Object.keys(json[0] || {});
    setHeaders(sheetHeaders);
    setRows(json);

    const cols = validateColumns(sheetHeaders);
    setColumnsCheck(cols);
    if (!cols.ok) {
      setRowErrors([]);
      setImpact(null);
      setInvitationPlan([]);
      setInvitationSummary(null);
      return;
    }
    await runPreview(json, sheetHeaders);
  };

  const onConfirmExecute = async () => {
    setExecuting(true);
    try {
      const res = await base44.functions.invoke("runFixedDeskImport", {
        mode: "execute",
        fileName,
        headers,
        rows,
        sendInvitations,
        resendExpiredOrFailed,
        resendPending,
      });
      setExecutionResult(res.data);
      if (res.data?.ok) {
        toast({ title: "Import successful", description: `${res.data.summary.assignmentsApplied} assignments applied` });
        await refetchCatalog();
      } else if (res.data?.stage === "rows") {
        setRowErrors(res.data.rowErrors || []);
        setImpact(null);
        toast({ title: "Import blocked by re-check", description: `${res.data.rowErrors?.length || 0} row error(s) found on second pass`, variant: "destructive" });
      } else if (res.data?.stage === "headers") {
        setColumnsCheck({ ok: false, missing: res.data.missingColumns, headers });
        toast({ title: "Headers changed", description: res.data.message, variant: "destructive" });
      } else {
        toast({ title: "Import failed", description: res.data?.errors?.join(", ") || "Unknown", variant: "destructive" });
      }
    } catch (e) {
      toast({ title: "Import failed", description: e.message, variant: "destructive" });
    } finally {
      setExecuting(false);
    }
  };

  return (
    <div>
      <PageHeader
        eyebrow="Admin · Imports"
        title="Fixed-Desk XLSX Import"
        description="Replace ALL fixed-desk assignments from an XLSX file. The import is not partial. Validation runs twice: at upload and immediately before execution. Nothing changes until you confirm."
      />

      <div className="grid gap-6">
        <ImportTemplateBlock />

        <Card className="rounded-2xl">
          <CardContent className="space-y-4 p-6">
            <div className="flex flex-wrap items-center gap-3">
              <label className="inline-flex cursor-pointer items-center gap-2 rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground shadow hover:bg-primary/90">
                <Upload className="h-4 w-4" />
                Choose XLSX file
                <input type="file" accept=".xlsx" className="hidden" onChange={handleFile} />
              </label>
              {fileName && <span className="text-sm text-muted-foreground">Selected: <span className="font-medium text-foreground">{fileName}</span></span>}
              {fileName && (
                <Button variant="ghost" size="sm" className="gap-2" onClick={reset}>
                  <RotateCcw className="h-4 w-4" /> Reset
                </Button>
              )}
            </div>

            {columnsCheck && !columnsCheck.ok && (
              <div className="rounded-2xl border border-red-200 bg-red-50 p-5 text-red-900">
                <h3 className="flex items-center gap-2 font-semibold"><ShieldAlert className="h-5 w-5" /> Required columns missing</h3>
                <p className="mt-1 text-sm">
                  The file is missing: <span className="font-mono">{columnsCheck.missing.join(", ")}</span>
                </p>
                <p className="mt-1 text-xs text-red-900/70">
                  Required columns: {REQUIRED_COLUMNS.join(", ")}
                </p>
              </div>
            )}

            <ImportInvitationOptions
              sendInvitations={sendInvitations}
              setSendInvitations={setSendInvitations}
              resendExpiredOrFailed={resendExpiredOrFailed}
              setResendExpiredOrFailed={setResendExpiredOrFailed}
              resendPending={resendPending}
              setResendPending={setResendPending}
            />

            <RowErrorsList errors={rowErrors} />
          </CardContent>
        </Card>

        {previewing && <p className="text-sm text-muted-foreground">Refreshing invitation preview...</p>}

        {impact && rowErrors.length === 0 && !executionResult?.ok && (
          <>
            <ImpactSummaryCard impact={impact} />
            {invitationSummary && <InvitationSummaryGrid summary={invitationSummary} />}
            <InvitationPlanTable plan={invitationPlan} />
            <div className="flex flex-wrap items-center gap-3">
              <Button onClick={onConfirmExecute} disabled={executing} className="gap-2">
                <CheckCircle2 className="h-4 w-4" />
                {executing ? "Importing..." : "Confirm and execute import"}
              </Button>
              <span className="text-xs text-muted-foreground">
                This replaces ALL fixed-desk assignments. Invitations follow the options selected above.
              </span>
            </div>
          </>
        )}

        {executionResult?.ok && (
          <Card className="rounded-2xl border-green-200 bg-green-50">
            <CardContent className="p-6">
              <h3 className="flex items-center gap-2 text-lg font-semibold text-green-800">
                <CheckCircle2 className="h-5 w-5" /> Import successful
              </h3>
              <p className="mt-1 text-sm text-green-900/80">
                ImportLog id: <span className="font-mono">{executionResult.importLogId}</span>
                </p>
                {executionResult.partialErrors?.length > 0 && (
                <p className="mt-2 text-sm text-amber-800">Import completed with invitation warning(s). Failed invitations can be retried from Admin &gt; Employees.</p>
                )}
                <div className="mt-4 grid gap-3 md:grid-cols-3 lg:grid-cols-5">
                <Stat label="Rows" value={executionResult.summary.rowsProcessed} />
                <Stat label="Applied" value={executionResult.summary.assignmentsApplied} />
                <Stat label="Removed" value={executionResult.summary.assignmentsRemoved} />
                <Stat label="New employees" value={executionResult.summary.newEmployeesCreated} />
                <Stat label="Updated employees" value={executionResult.summary.existingEmployeesUpdated} />
                <Stat label="Lost desk" value={executionResult.summary.employeesLosingAssignment} />
                </div>
                <div className="mt-4">
                <InvitationSummaryGrid summary={executionResult.summary} />
                </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
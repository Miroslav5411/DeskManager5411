import React, { useEffect, useMemo, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import PageHeader from "@/components/common/PageHeader";
import EmptyState from "@/components/common/EmptyState";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import DeskMapCanvas from "@/components/admin/DeskMapCanvas";
import DeskMapLegend from "@/components/admin/DeskMapLegend";
import SequentialPlacementPanel from "@/components/admin/SequentialPlacementPanel";
import DeskReviewTable from "@/components/admin/DeskReviewTable";
import { createDeskPayload, deskTypes, emptyDesk, getPercentFromClick, isDuplicateCode } from "@/utils/deskMapEditor";

const getSavedSelection = () => JSON.parse(sessionStorage.getItem("deskMapSelection") || "{}");

export default function DeskMap() {
  const queryClient = useQueryClient();
  const savedSelection = getSavedSelection();
  const [locationId, setLocationId] = useState(savedSelection.locationId || "");
  const [buildingId, setBuildingId] = useState(savedSelection.buildingId || "");
  const [floorId, setFloorId] = useState(savedSelection.floorId || "");
  const [desk, setDesk] = useState(emptyDesk);
  const [selectedDeskId, setSelectedDeskId] = useState("");
  const [message, setMessage] = useState("");
  const [sequence, setSequence] = useState({ start: 1, end: 69, desk_type: "Bookable", is_active: true });
  const [sequenceActive, setSequenceActive] = useState(false);
  const [sequencePaused, setSequencePaused] = useState(false);
  const [placedCodes, setPlacedCodes] = useState([]);
  const [createdInSession, setCreatedInSession] = useState([]);

  const { data: locations = [] } = useQuery({ queryKey: ["locations"], queryFn: () => base44.entities.Location.list("name") });
  const { data: buildings = [] } = useQuery({ queryKey: ["buildings"], queryFn: () => base44.entities.Building.list("name") });
  const { data: floors = [] } = useQuery({ queryKey: ["floors"], queryFn: () => base44.entities.FloorZone.list("name") });
  const { data: teams = [] } = useQuery({ queryKey: ["teams"], queryFn: () => base44.entities.Team.list("name") });
  const { data: employees = [] } = useQuery({ queryKey: ["employees"], queryFn: () => base44.entities.Employee.list("name") });
  const { data: desks = [] } = useQuery({ queryKey: ["desks"], queryFn: () => base44.entities.Desk.list("code") });

  const selectedFloor = floors.find((floor) => floor.id === floorId);
  const selectedBuilding = buildings.find((building) => building.id === buildingId);
  const filteredBuildings = buildings.filter((building) => building.location_id === locationId && building.is_active !== false);
  const filteredFloors = floors.filter((floor) => floor.type === "Office Floor" && floor.location_id === locationId && floor.building_id === buildingId && floor.is_active !== false);
  const floorDesks = useMemo(() => desks.filter((item) => item.floor_id === floorId), [desks, floorId]);
  const sequenceNumbers = useMemo(() => Array.from({ length: Math.max(0, sequence.end - sequence.start + 1) }, (_, index) => String(sequence.start + index)), [sequence.start, sequence.end]);
  const placedSequenceCodes = new Set([...floorDesks.map((deskItem) => String(deskItem.code)), ...placedCodes]);
  const nextCode = sequenceNumbers.find((code) => !placedSequenceCodes.has(code));
  const progress = { placed: sequenceNumbers.filter((code) => placedSequenceCodes.has(code)).length, total: sequenceNumbers.length };

  useEffect(() => {
    sessionStorage.setItem("deskMapSelection", JSON.stringify({ locationId, buildingId, floorId }));
  }, [locationId, buildingId, floorId]);

  const refreshDesks = () => queryClient.invalidateQueries({ queryKey: ["desks"] });

  const createDesk = useMutation({
    mutationFn: (data) => base44.entities.Desk.create(createDeskPayload(data, selectedFloor)),
    onSuccess: (created) => {
      refreshDesks();
      setDesk(emptyDesk);
      setCreatedInSession((items) => [...items, created.id]);
    },
  });

  const updateDesk = useMutation({
    mutationFn: ({ id, data }) => base44.entities.Desk.update(id, data),
    onSuccess: refreshDesks,
  });

  const deleteDesk = useMutation({
    mutationFn: (id) => base44.entities.Desk.delete(id),
    onSuccess: () => { refreshDesks(); setSelectedDeskId(""); },
  });

  const createDeskAt = async (deskData, position, advanceSequence = false) => {
    setMessage("");
    if (!selectedFloor) return setMessage("Select an office floor first.");
    if (selectedFloor.type !== "Office Floor") return setMessage("Only Office Floor types can be edited here.");
    if (!deskData.code) return setMessage("Desk code is required.");
    if (isDuplicateCode(desks, selectedFloor.id, deskData.code) || placedCodes.includes(String(deskData.code))) return setMessage(`Desk code ${deskData.code} already exists on this floor.`);
    if (deskData.desk_type === "Fixed" && (!deskData.assigned_team_id || !deskData.assigned_employee_id)) return setMessage("Fixed desks require an assigned team and employee.");
    if (deskData.desk_type === "Blocked" && !deskData.block_reason) return setMessage("Blocked desks require a block reason.");
    setPlacedCodes((codes) => [...codes, String(deskData.code)]);
    await createDesk.mutateAsync({ ...deskData, ...position });
  };

  const handleMapClick = (event) => {
    if (!selectedFloor) return;
    const position = getPercentFromClick(event);
    if (sequenceActive && !sequencePaused) {
      if (!nextCode) return setMessage("Sequence complete.");
      createDeskAt({ ...emptyDesk, code: nextCode, desk_type: sequence.desk_type, is_active: sequence.is_active }, position, true);
      return;
    }
    setDesk({ ...desk, ...position });
  };

  const handleManualCreate = () => createDeskAt(desk, { x_pos: desk.x_pos, y_pos: desk.y_pos });

  const handleUpdateDesk = (deskItem, updates) => {
    if (updates.code && isDuplicateCode(desks, deskItem.floor_id, updates.code, deskItem.id)) {
      setMessage(`Desk code ${updates.code} already exists on this floor.`);
      return;
    }
    updateDesk.mutate({ id: deskItem.id, data: updates });
  };

  const handleUndo = () => {
    const lastId = createdInSession[createdInSession.length - 1];
    if (!lastId) return;
    deleteDesk.mutate(lastId);
    setCreatedInSession((items) => items.slice(0, -1));
    setPlacedCodes((codes) => codes.slice(0, -1));
  };

  const selectLocation = (id) => { setLocationId(id); setBuildingId(""); setFloorId(""); setSelectedDeskId(""); };
  const selectBuilding = (id) => { setBuildingId(id); setFloorId(""); setSelectedDeskId(""); };
  const selectFloor = (id) => { setFloorId(id); setSelectedDeskId(""); setPlacedCodes([]); setCreatedInSession([]); };

  return (
    <div>
      <PageHeader eyebrow="Admin" title="Desk Map Editor" description="Place and maintain clickable desk buttons on uploaded office floor maps." />
      <div className="space-y-6">
        <Card className="rounded-3xl">
          <CardContent className="p-6">
            {!selectedFloor ? <EmptyState title="Select an office floor" description="Choose Location, Building, and Office Floor before placing desks." /> : <div className="space-y-4">
              <div className="flex flex-col justify-between gap-3 md:flex-row md:items-end"><div><h3 className="text-xl font-semibold">{selectedFloor.name}</h3><p className="text-sm text-muted-foreground">{locations.find((item) => item.id === selectedFloor.location_id)?.name} · {selectedBuilding?.name}</p></div><DeskMapLegend /></div>
              <DeskMapCanvas floor={selectedFloor} desks={floorDesks} teams={teams} employees={employees} selectedDeskId={selectedDeskId} onSelectDesk={setSelectedDeskId} onMapClick={handleMapClick} onMoveDesk={(deskItem, x_pos, y_pos) => handleUpdateDesk(deskItem, { x_pos, y_pos })} placementHint={sequenceActive && !sequencePaused ? `Click the map to place desk ${nextCode || "Complete"}` : ""} />
            </div>}
          </CardContent>
        </Card>

        <div className="grid gap-6 lg:grid-cols-2">
        <Card className="rounded-3xl">
          <CardContent className="space-y-5 p-6">
            <h3 className="text-xl font-semibold">Floor selection</h3>
            <div><Label>Location</Label><Select value={locationId} onValueChange={selectLocation}><SelectTrigger><SelectValue placeholder="Select location" /></SelectTrigger><SelectContent>{locations.filter((item) => item.is_active !== false).map((item) => <SelectItem key={item.id} value={item.id}>{item.name}</SelectItem>)}</SelectContent></Select></div>
            <div><Label>Building</Label><Select value={buildingId} onValueChange={selectBuilding} disabled={!locationId}><SelectTrigger><SelectValue placeholder="Select building" /></SelectTrigger><SelectContent>{filteredBuildings.map((item) => <SelectItem key={item.id} value={item.id}>{item.name}</SelectItem>)}</SelectContent></Select></div>
            <div><Label>Office floor</Label><Select value={floorId} onValueChange={selectFloor} disabled={!buildingId}><SelectTrigger><SelectValue placeholder="Select office floor" /></SelectTrigger><SelectContent>{filteredFloors.map((item) => <SelectItem key={item.id} value={item.id}>{item.name}</SelectItem>)}</SelectContent></Select></div>

            <SequentialPlacementPanel
              config={sequence}
              setConfig={setSequence}
              active={sequenceActive}
              paused={sequencePaused}
              progress={progress}
              nextCode={nextCode}
              onStart={() => { setSequenceActive(true); setSequencePaused(false); setPlacedCodes([]); setCreatedInSession([]); setMessage("Sequential placement started. Click the map to place each desk."); }}
              onPause={() => setSequencePaused((value) => !value)}
              onUndo={handleUndo}
            />

            <div className="space-y-4 rounded-3xl border p-4">
              <h3 className="text-lg font-semibold">Manual desk details</h3>
              <div><Label>Desk code / label</Label><Input value={desk.code} onChange={(e) => setDesk({ ...desk, code: e.target.value })} /></div>
              <div><Label>Desk type</Label><Select value={desk.desk_type} onValueChange={(desk_type) => setDesk({ ...desk, desk_type })}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent>{deskTypes.map((type) => <SelectItem key={type} value={type}>{type}</SelectItem>)}</SelectContent></Select></div>
              {desk.desk_type === "Fixed" && <div className="grid gap-4 md:grid-cols-2"><div><Label>Assigned team</Label><Select value={desk.assigned_team_id || "none"} onValueChange={(assigned_team_id) => setDesk({ ...desk, assigned_team_id: assigned_team_id === "none" ? "" : assigned_team_id })}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent><SelectItem value="none">No team</SelectItem>{teams.map((team) => <SelectItem key={team.id} value={team.id}>{team.name}</SelectItem>)}</SelectContent></Select></div><div><Label>Assigned employee</Label><Select value={desk.assigned_employee_id || "none"} onValueChange={(assigned_employee_id) => setDesk({ ...desk, assigned_employee_id: assigned_employee_id === "none" ? "" : assigned_employee_id })}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent><SelectItem value="none">No employee</SelectItem>{employees.map((employee) => <SelectItem key={employee.id} value={employee.id}>{employee.name}</SelectItem>)}</SelectContent></Select></div></div>}
              {desk.desk_type === "Blocked" && <div><Label>Block reason</Label><Input value={desk.block_reason} onChange={(event) => setDesk({ ...desk, block_reason: event.target.value })} /></div>}
              <div><Label>Equipment attributes</Label><Input value={desk.equipment} onChange={(event) => setDesk({ ...desk, equipment: event.target.value })} placeholder="Optional" /></div>
              <div><Label>Accessibility notes</Label><Input value={desk.accessibility_notes} onChange={(event) => setDesk({ ...desk, accessibility_notes: event.target.value })} placeholder="Optional" /></div>
              <div className="grid gap-4 md:grid-cols-2"><div><Label>X position (%)</Label><Input type="number" min="0" max="100" value={desk.x_pos} onChange={(event) => setDesk({ ...desk, x_pos: Number(event.target.value) })} /></div><div><Label>Y position (%)</Label><Input type="number" min="0" max="100" value={desk.y_pos} onChange={(event) => setDesk({ ...desk, y_pos: Number(event.target.value) })} /></div></div>
              <div className="flex items-center justify-between rounded-2xl border p-3"><Label>Active</Label><Switch checked={desk.is_active} onCheckedChange={(is_active) => setDesk({ ...desk, is_active })} /></div>
              <Button className="w-full rounded-full" disabled={!selectedFloor || !desk.code} onClick={handleManualCreate}>Add desk to map</Button>
            </div>
            {message && <p className="rounded-2xl bg-secondary p-3 text-sm">{message}</p>}
          </CardContent>
        </Card>

        {selectedFloor && <Card className="rounded-3xl"><CardContent className="space-y-4 p-6"><div><h3 className="text-xl font-semibold">Created desks review</h3><p className="text-sm text-muted-foreground">Edit coordinates, type, active status, or delete markers below.</p></div><DeskReviewTable desks={floorDesks} teams={teams} selectedDeskId={selectedDeskId} onSelect={setSelectedDeskId} onUpdate={handleUpdateDesk} onDelete={(id) => deleteDesk.mutate(id)} /></CardContent></Card>}
        </div>
      </div>
    </div>
  );
}
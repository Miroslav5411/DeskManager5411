import React, { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import PageHeader from "@/components/common/PageHeader";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent } from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import { CalendarPlus, Save, Trash2 } from "lucide-react";

const empty = { holiday_name: "", holiday_date: "", country: "", is_active: true, notes: "" };

export default function PublicHolidays() {
  const qc = useQueryClient();
  const [draft, setDraft] = useState(empty);

  const { data: holidays = [], isLoading } = useQuery({
    queryKey: ["public-holidays-admin"],
    queryFn: () => base44.entities.PublicHoliday.list("-holiday_date", 500),
  });

  const createMutation = useMutation({
    mutationFn: (payload) => base44.entities.PublicHoliday.create(payload),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["public-holidays-admin"] }); qc.invalidateQueries({ queryKey: ["public-holidays"] }); setDraft(empty); },
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, patch }) => base44.entities.PublicHoliday.update(id, patch),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["public-holidays-admin"] }); qc.invalidateQueries({ queryKey: ["public-holidays"] }); },
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.PublicHoliday.delete(id),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["public-holidays-admin"] }); qc.invalidateQueries({ queryKey: ["public-holidays"] }); },
  });

  const submit = (e) => {
    e.preventDefault();
    if (!draft.holiday_name.trim() || !draft.holiday_date) return;
    createMutation.mutate(draft);
  };

  return (
    <div>
      <PageHeader
        eyebrow="Admin · Public Holidays"
        title="Public Holidays"
        description="Used by the Unavailable Insights report's Holiday Proximity section. Holidays are managed manually — no external API integration."
      />

      <Card className="mb-6 rounded-2xl">
        <CardContent className="p-6">
          <form onSubmit={submit} className="grid gap-4 md:grid-cols-5">
            <div className="md:col-span-2">
              <Label className="text-xs uppercase tracking-wide text-muted-foreground">Holiday name</Label>
              <Input value={draft.holiday_name} onChange={(e) => setDraft({ ...draft, holiday_name: e.target.value })} placeholder="e.g. Liberation Day" />
            </div>
            <div>
              <Label className="text-xs uppercase tracking-wide text-muted-foreground">Date</Label>
              <Input type="date" value={draft.holiday_date} onChange={(e) => setDraft({ ...draft, holiday_date: e.target.value })} />
            </div>
            <div>
              <Label className="text-xs uppercase tracking-wide text-muted-foreground">Country</Label>
              <Input value={draft.country} onChange={(e) => setDraft({ ...draft, country: e.target.value })} placeholder="e.g. BG" />
            </div>
            <div className="flex items-end">
              <Button type="submit" className="gap-2" disabled={createMutation.isPending}>
                <CalendarPlus className="h-4 w-4" /> Add holiday
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>

      <Card className="rounded-2xl">
        <CardContent className="p-0">
          {isLoading ? (
            <p className="p-8 text-center text-sm text-muted-foreground">Loading…</p>
          ) : holidays.length === 0 ? (
            <p className="p-8 text-center text-sm text-muted-foreground">No public holidays configured yet.</p>
          ) : (
            <table className="w-full text-sm">
              <thead className="bg-secondary text-xs uppercase tracking-wide text-muted-foreground">
                <tr>
                  <th className="px-4 py-3 text-left">Name</th>
                  <th className="px-4 py-3 text-left">Date</th>
                  <th className="px-4 py-3 text-left">Country</th>
                  <th className="px-4 py-3 text-left">Active</th>
                  <th className="px-4 py-3 text-left">Notes</th>
                  <th className="px-4 py-3 text-right">Actions</th>
                </tr>
              </thead>
              <tbody>
                {holidays.map((h) => (
                  <tr key={h.id} className="border-t">
                    <td className="px-4 py-3 font-medium">{h.holiday_name}</td>
                    <td className="px-4 py-3 font-mono text-xs">{h.holiday_date}</td>
                    <td className="px-4 py-3">{h.country || "—"}</td>
                    <td className="px-4 py-3">
                      <Switch checked={h.is_active !== false} onCheckedChange={(v) => updateMutation.mutate({ id: h.id, patch: { ...h, is_active: v } })} />
                    </td>
                    <td className="px-4 py-3 text-muted-foreground">{h.notes || "—"}</td>
                    <td className="px-4 py-3 text-right">
                      <Button variant="ghost" size="icon" onClick={() => deleteMutation.mutate(h.id)} title="Delete">
                        <Trash2 className="h-4 w-4 text-destructive" />
                      </Button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </CardContent>
      </Card>

      <p className="mt-4 text-xs text-muted-foreground">
        <Save className="mr-1 inline h-3 w-3" />
        Tip: keep the list short — only the dates that should drive the Holiday Proximity analytics.
      </p>
    </div>
  );
}
import React, { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import PageHeader from "@/components/common/PageHeader";
import EmptyState from "@/components/common/EmptyState";
import StatusPill from "@/components/admin/StatusPill";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { normalizeEmail } from "@/utils/workspaceRules";
import SetUnavailableDialog from "@/components/admin/SetUnavailableDialog";
import EmployeeCreateForm from "@/components/admin/EmployeeCreateForm";
import EmployeesList from "@/components/admin/EmployeesList";
import { useToast } from "@/components/ui/use-toast";

const emptyEmployee = {
  name: "",
  email: "",
  role: "Employee",
  team_id: "",
  department: "",
  manager_id: "",
  default_location_id: "",
  default_building_id: "",
  default_floor_id: "",
  fixed_desk_id: "",
  is_active: true,
  invitation_status: "Not Sent",
  last_invitation_error: "",
};
const emptyTeam = { name: "", department: "", manager_id: "", default_location_id: "", default_building_id: "", default_floor_id: "", color: "#E30613", is_active: true };

export default function People() {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const [employee, setEmployee] = useState(emptyEmployee);
  const [team, setTeam] = useState(emptyTeam);
  const [sendInvitationOnCreate, setSendInvitationOnCreate] = useState(false);
  const [invitePendingId, setInvitePendingId] = useState(null);
  const [unavailableTarget, setUnavailableTarget] = useState(null);

  const { data: employees = [] } = useQuery({ queryKey: ["employees"], queryFn: () => base44.entities.Employee.list("name") });
  const { data: teams = [] } = useQuery({ queryKey: ["teams"], queryFn: () => base44.entities.Team.list("name") });
  const { data: locations = [] } = useQuery({ queryKey: ["locations"], queryFn: () => base44.entities.Location.list("name") });
  const { data: buildings = [] } = useQuery({ queryKey: ["buildings"], queryFn: () => base44.entities.Building.list("name") });
  const { data: floors = [] } = useQuery({ queryKey: ["floors"], queryFn: () => base44.entities.FloorZone.list("name") });
  const { data: desks = [] } = useQuery({ queryKey: ["desks"], queryFn: () => base44.entities.Desk.list("code") });

  const duplicateEmail = employee.email && employees.some((item) => normalizeEmail(item.email) === normalizeEmail(employee.email));
  const filteredBuildings = buildings.filter((building) => building.location_id === employee.default_location_id);
  const filteredFloors = floors.filter((floor) => floor.building_id === employee.default_building_id);
  const filteredDesks = desks.filter((deskItem) => deskItem.floor_id === employee.default_floor_id);
  const filteredTeamBuildings = buildings.filter((building) => building.location_id === team.default_location_id);
  const filteredTeamFloors = floors.filter((floor) => floor.building_id === team.default_building_id);

  const createEmployee = useMutation({
    mutationFn: async ({ data, sendInvitation }) => {
      const created = await base44.entities.Employee.create({ ...data, email: normalizeEmail(data.email), invitation_status: "Not Sent" });
      if (sendInvitation) {
        const res = await base44.functions.invoke("manageUserInvitation", {
          email: created.email,
          employeeRole: created.role,
          employeeId: created.id,
          sendEnabled: true,
          forceResendPending: false,
          forceResendExpiredOrFailed: true,
          source: "Manual",
        });
        return { created, invitation: res.data };
      }
      return { created, invitation: null };
    },
    onSuccess: (result) => {
      queryClient.invalidateQueries({ queryKey: ["employees"] });
      setEmployee(emptyEmployee);
      setSendInvitationOnCreate(false);
      if (result.invitation?.action === "failed") {
        toast({ title: "Employee created, invitation failed", description: "You can retry from the Employees list.", variant: "destructive" });
      } else if (result.invitation) {
        toast({ title: "Employee created and invitation sent" });
      }
    },
  });

  const createTeam = useMutation({
    mutationFn: (data) => base44.entities.Team.create(data),
    onSuccess: () => { queryClient.invalidateQueries({ queryKey: ["teams"] }); setTeam(emptyTeam); },
  });

  const updateEmployee = useMutation({
    mutationFn: ({ id, data }) => base44.entities.Employee.update(id, data),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["employees"] }),
  });

  const updateTeam = useMutation({
    mutationFn: ({ id, data }) => base44.entities.Team.update(id, data),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["teams"] }),
  });

  const handleManualInvite = async (target) => {
    setInvitePendingId(target.id);
    const res = await base44.functions.invoke("manageUserInvitation", {
      email: target.email,
      employeeRole: target.role,
      employeeId: target.id,
      sendEnabled: true,
      forceResendPending: true,
      forceResendExpiredOrFailed: true,
      source: target.invitation_status === "Not Sent" ? "Manual" : "Resend",
    });
    await queryClient.invalidateQueries({ queryKey: ["employees"] });
    setInvitePendingId(null);
    if (res.data?.action === "failed") toast({ title: "Invitation failed", description: res.data.errorMessage, variant: "destructive" });
    else if (res.data?.action === "skipped") toast({ title: "Invitation skipped", description: res.data.reason });
    else toast({ title: "Invitation sent" });
  };

  const handleCreateEmployee = () => createEmployee.mutate({ data: employee, sendInvitation: sendInvitationOnCreate });

  return (
    <div>
      <PageHeader eyebrow="Admin" title="Employees" description="Manage employees, teams, roles, and activation status." />
      <div className="grid gap-6 lg:grid-cols-[1.2fr_0.8fr]">
        <Card className="rounded-3xl"><CardContent className="space-y-4 p-6">
          <EmployeeCreateForm
            employee={employee}
            setEmployee={setEmployee}
            teams={teams}
            employees={employees}
            locations={locations}
            filteredBuildings={filteredBuildings}
            filteredFloors={filteredFloors}
            filteredDesks={filteredDesks}
            duplicateEmail={duplicateEmail}
            sendInvitation={sendInvitationOnCreate}
            setSendInvitation={setSendInvitationOnCreate}
            onCreate={handleCreateEmployee}
            creating={createEmployee.isPending}
          />
        </CardContent></Card>

        <Card className="rounded-3xl"><CardContent className="space-y-4 p-6">
          <h3 className="text-xl font-semibold">Add team</h3>
          <div><Label>Team name</Label><Input value={team.name} onChange={(e) => setTeam({ ...team, name: e.target.value })} /></div>
          <div><Label>Department</Label><Input value={team.department} onChange={(e) => setTeam({ ...team, department: e.target.value })} /></div>
          <div><Label>Manager / team lead</Label><Select value={team.manager_id || "none"} onValueChange={(manager_id) => setTeam({ ...team, manager_id: manager_id === "none" ? "" : manager_id })}><SelectTrigger><SelectValue placeholder="Optional" /></SelectTrigger><SelectContent><SelectItem value="none">No manager</SelectItem>{employees.map((manager) => <SelectItem key={manager.id} value={manager.id}>{manager.name}</SelectItem>)}</SelectContent></Select></div>
          <div><Label>Default Location</Label><Select value={team.default_location_id || "none"} onValueChange={(default_location_id) => setTeam({ ...team, default_location_id: default_location_id === "none" ? "" : default_location_id, default_building_id: "", default_floor_id: "" })}><SelectTrigger><SelectValue placeholder="Optional" /></SelectTrigger><SelectContent><SelectItem value="none">No default location</SelectItem>{locations.map((location) => <SelectItem key={location.id} value={location.id}>{location.name}</SelectItem>)}</SelectContent></Select></div>
          <div><Label>Default Building</Label><Select value={team.default_building_id || "none"} onValueChange={(default_building_id) => setTeam({ ...team, default_building_id: default_building_id === "none" ? "" : default_building_id, default_floor_id: "" })}><SelectTrigger><SelectValue placeholder="Optional" /></SelectTrigger><SelectContent><SelectItem value="none">No default building</SelectItem>{filteredTeamBuildings.map((building) => <SelectItem key={building.id} value={building.id}>{building.name}</SelectItem>)}</SelectContent></Select></div>
          <div><Label>Default Floor</Label><Select value={team.default_floor_id || "none"} onValueChange={(default_floor_id) => setTeam({ ...team, default_floor_id: default_floor_id === "none" ? "" : default_floor_id })}><SelectTrigger><SelectValue placeholder="Optional" /></SelectTrigger><SelectContent><SelectItem value="none">No default floor</SelectItem>{filteredTeamFloors.map((floor) => <SelectItem key={floor.id} value={floor.id}>{floor.name}</SelectItem>)}</SelectContent></Select></div>
          <div><Label>Team color</Label><Input type="color" value={team.color} onChange={(e) => setTeam({ ...team, color: e.target.value })} /></div>
          <div className="flex items-center justify-between rounded-2xl border p-3"><Label>Active</Label><Switch checked={team.is_active} onCheckedChange={(is_active) => setTeam({ ...team, is_active })} /></div>
          <Button className="rounded-full" onClick={() => createTeam.mutate(team)} disabled={!team.name}>Create team</Button>
        </CardContent></Card>
      </div>

      <div className="mt-8 grid gap-6 lg:grid-cols-2">
        <Card className="rounded-3xl"><CardContent className="p-6"><h3 className="mb-4 text-xl font-semibold">Employees</h3><EmployeesList employees={employees} teams={teams} onInvite={handleManualInvite} invitePendingId={invitePendingId} onSetUnavailable={setUnavailableTarget} onToggleActive={(e) => updateEmployee.mutate({ id: e.id, data: { is_active: !e.is_active } })} /></CardContent></Card>
        <SetUnavailableDialog
          employee={unavailableTarget}
          open={!!unavailableTarget}
          onOpenChange={(o) => { if (!o) setUnavailableTarget(null); }}
          onSuccess={() => {
            queryClient.invalidateQueries({ queryKey: ["employees"] });
          }}
        />
        <Card className="rounded-3xl"><CardContent className="p-6"><h3 className="mb-4 text-xl font-semibold">Teams</h3>{teams.length === 0 ? <EmptyState title="No teams yet" description="Teams are used for fixed-desk display and future reporting." /> : <div className="space-y-3">{teams.map((t) => <div key={t.id} className="flex items-center justify-between rounded-2xl border p-4"><div className="flex items-center gap-3"><span className="h-4 w-4 rounded-full" style={{ backgroundColor: t.color }} /><div><p className="font-medium">{t.name}</p><p className="text-sm text-muted-foreground">{t.department || "No department"}</p></div></div><div className="flex items-center gap-2"><StatusPill active={t.is_active} /><Switch checked={t.is_active} onCheckedChange={(is_active) => updateTeam.mutate({ id: t.id, data: { is_active } })} /></div></div>)}</div>}</CardContent></Card>
      </div>
    </div>
  );
}
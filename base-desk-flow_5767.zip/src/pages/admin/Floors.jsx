import React, { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import PageHeader from "@/components/common/PageHeader";
import EmptyState from "@/components/common/EmptyState";
import StatusPill from "@/components/admin/StatusPill";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";

const floorTypes = ["Office Floor", "Parking Floor", "Parking Zone"];
const emptyFloor = { location_id: "", building_id: "", name: "", type: "Office Floor", map_image_reference: "", is_active: true, notes: "" };

export default function Floors() {
  const queryClient = useQueryClient();
  const [floor, setFloor] = useState(emptyFloor);
  const { data: locations = [] } = useQuery({ queryKey: ["locations"], queryFn: () => base44.entities.Location.list("name") });
  const { data: buildings = [] } = useQuery({ queryKey: ["buildings"], queryFn: () => base44.entities.Building.list("name") });
  const { data: floors = [] } = useQuery({ queryKey: ["floors"], queryFn: () => base44.entities.FloorZone.list("name") });

  const createFloor = useMutation({ mutationFn: (data) => base44.entities.FloorZone.create(data), onSuccess: () => { queryClient.invalidateQueries({ queryKey: ["floors"] }); setFloor(emptyFloor); } });
  const updateFloor = useMutation({ mutationFn: ({ id, data }) => base44.entities.FloorZone.update(id, data), onSuccess: () => queryClient.invalidateQueries({ queryKey: ["floors"] }) });
  const filteredBuildings = buildings.filter((b) => b.location_id === floor.location_id);

  const uploadMapImage = async (file, updater) => {
    if (!file) return;
    const { file_url } = await base44.integrations.Core.UploadFile({ file });
    updater(file_url);
  };

  return (
    <div>
      <PageHeader eyebrow="Admin" title="Floors & Maps" description="Create floors or parking zones and upload their floor plan images." />
      <Card className="rounded-3xl"><CardContent className="space-y-4 p-6">
        <h3 className="text-xl font-semibold">Create floor or zone</h3>
        <div className="grid gap-4 md:grid-cols-2">
          <div><Label>Location</Label><Select value={floor.location_id || ""} onValueChange={(location_id) => setFloor({ ...floor, location_id, building_id: "" })}><SelectTrigger><SelectValue placeholder="Select location" /></SelectTrigger><SelectContent>{locations.map((l) => <SelectItem key={l.id} value={l.id}>{l.name}</SelectItem>)}</SelectContent></Select></div>
          <div><Label>Building</Label><Select value={floor.building_id || ""} onValueChange={(building_id) => setFloor({ ...floor, building_id })}><SelectTrigger><SelectValue placeholder="Select building" /></SelectTrigger><SelectContent>{filteredBuildings.map((b) => <SelectItem key={b.id} value={b.id}>{b.name}</SelectItem>)}</SelectContent></Select></div>
          <div><Label>Name / Number</Label><Input value={floor.name} onChange={(e) => setFloor({ ...floor, name: e.target.value })} /></div>
          <div><Label>Type</Label><Select value={floor.type} onValueChange={(type) => setFloor({ ...floor, type })}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent>{floorTypes.map((type) => <SelectItem key={type} value={type}>{type}</SelectItem>)}</SelectContent></Select></div>
          <div className="md:col-span-2"><Label>Map image upload</Label><Input type="file" accept="image/*" onChange={(e) => uploadMapImage(e.target.files?.[0], (map_image_reference) => setFloor({ ...floor, map_image_reference }))} />{floor.map_image_reference && <p className="mt-2 text-xs text-muted-foreground">Uploaded image reference saved. Upload another file to replace before creating.</p>}</div>
          <div className="flex items-center justify-between rounded-2xl border p-3"><Label>Active</Label><Switch checked={floor.is_active} onCheckedChange={(is_active) => setFloor({ ...floor, is_active })} /></div>
        </div>
        <Button className="rounded-full" onClick={() => createFloor.mutate(floor)} disabled={!floor.location_id || !floor.building_id || !floor.name}>Create floor / zone</Button>
      </CardContent></Card>

      <Card className="mt-8 rounded-3xl"><CardContent className="p-6">
        <h3 className="mb-4 text-xl font-semibold">Floors & Zones</h3>
        {floors.length === 0 ? <EmptyState title="No floors yet" description="Create an office floor before placing desks." /> : <div className="grid gap-3 md:grid-cols-2">{floors.map((f) => <div key={f.id} className="rounded-2xl border p-4"><div className="flex items-start justify-between gap-3"><div><p className="font-medium">{f.name}</p><p className="text-sm text-muted-foreground">{locations.find((l) => l.id === f.location_id)?.name || "Unknown"} · {buildings.find((b) => b.id === f.building_id)?.name || "Unknown"} · {f.type}</p></div><div className="flex items-center gap-2"><StatusPill active={f.is_active} /><Switch checked={f.is_active} onCheckedChange={(is_active) => updateFloor.mutate({ id: f.id, data: { is_active } })} /></div></div>{f.map_image_reference && <img src={f.map_image_reference} alt={f.name} className="mt-4 h-32 w-full rounded-xl object-cover" />}<div className="mt-4"><Label className="text-xs">Replace map image</Label><Input type="file" accept="image/*" onChange={(e) => uploadMapImage(e.target.files?.[0], (map_image_reference) => updateFloor.mutate({ id: f.id, data: { map_image_reference } }))} /></div></div>)}</div>}
      </CardContent></Card>
    </div>
  );
}
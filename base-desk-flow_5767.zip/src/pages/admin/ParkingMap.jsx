import React, { useMemo, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import PageHeader from "@/components/common/PageHeader";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

export default function ParkingMap() {
  const queryClient = useQueryClient();
  const [locationId, setLocationId] = useState("");
  const [buildingId, setBuildingId] = useState("");
  const [floorId, setFloorId] = useState("");
  const [nextCode, setNextCode] = useState("P1");
  const [spaceType, setSpaceType] = useState("Employee Bookable");

  const { data, isLoading } = useQuery({
    queryKey: ["parking-map-admin-data"],
    queryFn: async () => ({
      locations: await base44.entities.Location.list(),
      buildings: await base44.entities.Building.list(),
      floors: await base44.entities.FloorZone.list(),
      spaces: await base44.entities.ParkingSpace.list(),
    }),
  });

  const filteredBuildings = (data?.buildings || []).filter((building) => !locationId || building.location_id === locationId);
  const filteredFloors = (data?.floors || []).filter((floor) => (!buildingId || floor.building_id === buildingId) && (floor.type === "Parking Floor" || floor.type === "Parking Zone"));
  const floor = (data?.floors || []).find((item) => item.id === floorId);
  const spaces = useMemo(() => (data?.spaces || []).filter((space) => space.floor_zone_id === floorId), [data, floorId]);

  const createSpaceMutation = useMutation({
    mutationFn: async ({ x_pos, y_pos }) => base44.entities.ParkingSpace.create({
      location_id: locationId,
      building_id: buildingId,
      floor_zone_id: floorId,
      code: nextCode,
      space_type: spaceType,
      x_pos,
      y_pos,
      is_active: true,
    }),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["parking-map-admin-data"] }),
  });

  const deleteSpaceMutation = useMutation({
    mutationFn: (id) => base44.entities.ParkingSpace.delete(id),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["parking-map-admin-data"] }),
  });

  const handleMapClick = (event) => {
    if (!locationId || !buildingId || !floorId || !nextCode) return;
    const rect = event.currentTarget.getBoundingClientRect();
    const x_pos = ((event.clientX - rect.left) / rect.width) * 100;
    const y_pos = ((event.clientY - rect.top) / rect.height) * 100;
    createSpaceMutation.mutate({ x_pos, y_pos });
  };

  if (isLoading) return <div className="py-12 text-center text-muted-foreground">Loading parking map...</div>;

  return (
    <div>
      <PageHeader eyebrow="Admin" title="Parking Map" description="Place and manage parking spaces on parking floor maps." />

      <Card className="mb-6 rounded-3xl">
        <CardContent className="grid gap-3 p-4 md:grid-cols-5">
          <Select value={locationId} onValueChange={(value) => { setLocationId(value); setBuildingId(""); setFloorId(""); }}>
            <SelectTrigger><SelectValue placeholder="Location" /></SelectTrigger>
            <SelectContent>{data.locations.map((location) => <SelectItem key={location.id} value={location.id}>{location.name}</SelectItem>)}</SelectContent>
          </Select>
          <Select value={buildingId} onValueChange={(value) => { setBuildingId(value); setFloorId(""); }}>
            <SelectTrigger><SelectValue placeholder="Building" /></SelectTrigger>
            <SelectContent>{filteredBuildings.map((building) => <SelectItem key={building.id} value={building.id}>{building.name}</SelectItem>)}</SelectContent>
          </Select>
          <Select value={floorId} onValueChange={setFloorId}>
            <SelectTrigger><SelectValue placeholder="Parking floor / zone" /></SelectTrigger>
            <SelectContent>{filteredFloors.map((floorItem) => <SelectItem key={floorItem.id} value={floorItem.id}>{floorItem.name}</SelectItem>)}</SelectContent>
          </Select>
          <Input value={nextCode} onChange={(event) => setNextCode(event.target.value)} placeholder="Code, e.g. P1" />
          <Select value={spaceType} onValueChange={setSpaceType}>
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="Employee Bookable">Employee Bookable</SelectItem>
              <SelectItem value="Company Car Fixed">Company Car Fixed</SelectItem>
              <SelectItem value="Guest Bookable">Guest Bookable</SelectItem>
              <SelectItem value="Blocked">Blocked</SelectItem>
            </SelectContent>
          </Select>
        </CardContent>
      </Card>

      <div onClick={handleMapClick} className="relative min-h-[680px] cursor-crosshair overflow-hidden rounded-3xl border bg-secondary">
        {floor?.map_image_reference ? <img src={floor.map_image_reference} alt="Parking map" className="absolute inset-0 h-full w-full object-contain" /> : <div className="absolute inset-0 flex items-center justify-center text-sm text-muted-foreground">Select a parking floor with a map image, then click to place spaces.</div>}
        {spaces.map((space) => (
          <button key={space.id} type="button" onClick={(event) => { event.stopPropagation(); deleteSpaceMutation.mutate(space.id); }} className="absolute flex min-h-7 min-w-7 -translate-x-1/2 -translate-y-1/2 items-center justify-center rounded-full border border-primary bg-primary px-1.5 text-[9px] font-semibold text-primary-foreground shadow-md" style={{ left: `${space.x_pos || 50}%`, top: `${space.y_pos || 50}%` }} title="Click to remove">
            {space.code}
          </button>
        ))}
      </div>
      <p className="mt-3 text-sm text-muted-foreground">Tip: enter the next parking code, then click the map to place it. Click an existing marker to remove it.</p>
    </div>
  );
}
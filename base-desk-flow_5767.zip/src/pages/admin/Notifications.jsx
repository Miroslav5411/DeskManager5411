import React, { useMemo, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import PageHeader from "@/components/common/PageHeader";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Plus, Pencil, Power, AlertTriangle } from "lucide-react";
import { useToast } from "@/components/ui/use-toast";
import NotificationForm from "@/components/admin/NotificationForm";
import { logNotificationAudit } from "@/utils/notificationAudit";
import { isNotificationVisibleNow } from "@/utils/notificationRules";

export default function AdminNotifications() {
  const qc = useQueryClient();
  const { toast } = useToast();
  const { data, isLoading } = useQuery({
    queryKey: ["admin-notifications"],
    queryFn: () => base44.entities.Notification.list("-updated_date", 1000),
  });

  const [editing, setEditing] = useState(null); // null | "new" | <notification>

  const invalidate = () => {
    qc.invalidateQueries({ queryKey: ["admin-notifications"] });
    qc.invalidateQueries({ queryKey: ["user-notifications"] });
    qc.invalidateQueries({ queryKey: ["dashboard-notifications"] });
  };

  const createMutation = useMutation({
    mutationFn: async (payload) => {
      const created = await base44.entities.Notification.create(payload);
      await logNotificationAudit({ action_type: "Notification created", notification: created });
      return created;
    },
    onSuccess: () => { invalidate(); setEditing(null); toast({ title: "Notification created" }); },
    onError: (e) => toast({ title: "Create failed", description: e.message, variant: "destructive" }),
  });

  const updateMutation = useMutation({
    mutationFn: async ({ id, prev, patch }) => {
      const updated = await base44.entities.Notification.update(id, patch);
      await logNotificationAudit({ action_type: "Notification edited", notification: updated });
      // pinned flag transitions get their own audit entries
      if (!!prev.is_pinned !== !!patch.is_pinned) {
        await logNotificationAudit({
          action_type: patch.is_pinned ? "Notification pinned" : "Notification unpinned",
          notification: updated,
        });
      }
      return updated;
    },
    onSuccess: () => { invalidate(); setEditing(null); toast({ title: "Notification updated" }); },
    onError: (e) => toast({ title: "Update failed", description: e.message, variant: "destructive" }),
  });

  const toggleActiveMutation = useMutation({
    mutationFn: async (n) => {
      const nextActive = !n.is_active;
      const updated = await base44.entities.Notification.update(n.id, { ...n, is_active: nextActive });
      await logNotificationAudit({
        action_type: nextActive ? "Notification reactivated" : "Notification deactivated",
        notification: updated,
      });
      return updated;
    },
    onSuccess: () => { invalidate(); toast({ title: "Notification status changed" }); },
    onError: (e) => toast({ title: "Update failed", description: e.message, variant: "destructive" }),
  });

  const list = useMemo(() => (data || []).slice().sort((a, b) => {
    if (!!b.is_pinned !== !!a.is_pinned) return (b.is_pinned ? 1 : 0) - (a.is_pinned ? 1 : 0);
    return (b.start_date || "").localeCompare(a.start_date || "");
  }), [data]);

  return (
    <div>
      <PageHeader
        eyebrow="Admin"
        title="Notification Management"
        description="Create and manage platform-wide notifications. They are visible to every authenticated user during their active date window."
        action={
          <Button onClick={() => setEditing("new")} className="gap-2">
            <Plus className="h-4 w-4" /> New notification
          </Button>
        }
      />

      {editing && (
        <Card className="mb-6 rounded-3xl">
          <CardContent className="p-6">
            <h3 className="mb-4 text-lg font-semibold">{editing === "new" ? "New notification" : "Edit notification"}</h3>
            <NotificationForm
              initial={editing === "new" ? null : editing}
              submitLabel={editing === "new" ? "Create" : "Save changes"}
              onCancel={() => setEditing(null)}
              onSubmit={(payload) => {
                if (editing === "new") return createMutation.mutateAsync(payload);
                return updateMutation.mutateAsync({ id: editing.id, prev: editing, patch: payload });
              }}
            />
          </CardContent>
        </Card>
      )}

      {isLoading && <p className="text-sm text-muted-foreground">Loading…</p>}

      {!isLoading && list.length === 0 && (
        <div className="rounded-3xl border bg-card p-8 text-muted-foreground">No notifications yet.</div>
      )}

      <div className="grid gap-3">
        {list.map((n) => {
          const visibleNow = isNotificationVisibleNow(n);
          return (
            <Card key={n.id} className="rounded-3xl">
              <CardContent className="flex flex-col gap-4 p-5 md:flex-row md:items-center md:justify-between">
                <div className="min-w-0 flex-1">
                  <div className="flex flex-wrap items-center gap-2">
                    {n.is_pinned && (
                      <Badge className="gap-1 bg-primary text-primary-foreground">
                        <AlertTriangle className="h-3 w-3" /> Urgent
                      </Badge>
                    )}
                    <Badge variant="secondary">{n.category}</Badge>
                    <Badge variant={n.is_active ? "default" : "outline"}>
                      {n.is_active ? "Active" : "Inactive"}
                    </Badge>
                    {n.is_active && !visibleNow && (
                      <Badge variant="outline">Outside date window</Badge>
                    )}
                  </div>
                  <h3 className="mt-2 text-lg font-semibold">{n.title}</h3>
                  <p className="mt-1 line-clamp-2 text-sm text-muted-foreground">{n.body}</p>
                  <p className="mt-2 text-xs text-muted-foreground">{n.start_date} → {n.end_date}</p>
                </div>
                <div className="flex flex-wrap items-center gap-2">
                  <Button variant="outline" size="sm" className="gap-1" onClick={() => setEditing(n)}>
                    <Pencil className="h-3.5 w-3.5" /> Edit
                  </Button>
                  <Button
                    variant={n.is_active ? "outline" : "default"}
                    size="sm"
                    className="gap-1"
                    onClick={() => toggleActiveMutation.mutate(n)}
                  >
                    <Power className="h-3.5 w-3.5" />
                    {n.is_active ? "Deactivate" : "Reactivate"}
                  </Button>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>
    </div>
  );
}
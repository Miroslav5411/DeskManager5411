import React, { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import PageHeader from "@/components/common/PageHeader";
import EmptyState from "@/components/common/EmptyState";
import StatusPill from "@/components/admin/StatusPill";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";

const types = ["Office", "Parking", "Mixed"];
const emptyLocation = { name: "", address: "", city: "", country: "", type: "Office", is_active: true, notes: "" };
const emptyBuilding = { location_id: "", name: "", address_detail: "", type: "Office", is_active: true, notes: "" };

export default function Locations() {
  const queryClient = useQueryClient();
  const [location, setLocation] = useState(emptyLocation);
  const [building, setBuilding] = useState(emptyBuilding);

  const { data: locations = [] } = useQuery({ queryKey: ["locations"], queryFn: () => base44.entities.Location.list("name") });
  const { data: buildings = [] } = useQuery({ queryKey: ["buildings"], queryFn: () => base44.entities.Building.list("name") });

  const createLocation = useMutation({ mutationFn: (data) => base44.entities.Location.create(data), onSuccess: () => { queryClient.invalidateQueries({ queryKey: ["locations"] }); setLocation(emptyLocation); } });
  const createBuilding = useMutation({ mutationFn: (data) => base44.entities.Building.create(data), onSuccess: () => { queryClient.invalidateQueries({ queryKey: ["buildings"] }); setBuilding(emptyBuilding); } });
  const updateLocation = useMutation({ mutationFn: ({ id, data }) => base44.entities.Location.update(id, data), onSuccess: () => queryClient.invalidateQueries({ queryKey: ["locations"] }) });
  const updateBuilding = useMutation({ mutationFn: ({ id, data }) => base44.entities.Building.update(id, data), onSuccess: () => queryClient.invalidateQueries({ queryKey: ["buildings"] }) });

  return (
    <div>
      <PageHeader eyebrow="Admin" title="Locations" description="Maintain sites, buildings, and the workspace hierarchy." />
      <div className="grid gap-6 lg:grid-cols-2">
        <Card className="rounded-3xl"><CardContent className="space-y-4 p-6">
          <h3 className="text-xl font-semibold">Create location</h3>
          <div><Label>Name</Label><Input value={location.name} onChange={(e) => setLocation({ ...location, name: e.target.value })} /></div>
          <div className="grid gap-4 md:grid-cols-2"><div><Label>City</Label><Input value={location.city} onChange={(e) => setLocation({ ...location, city: e.target.value })} /></div><div><Label>Country</Label><Input value={location.country} onChange={(e) => setLocation({ ...location, country: e.target.value })} /></div></div>
          <div><Label>Address</Label><Input value={location.address} onChange={(e) => setLocation({ ...location, address: e.target.value })} /></div>
          <div><Label>Type</Label><Select value={location.type} onValueChange={(type) => setLocation({ ...location, type })}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent>{types.map((type) => <SelectItem key={type} value={type}>{type}</SelectItem>)}</SelectContent></Select></div>
          <div className="flex items-center justify-between rounded-2xl border p-3"><Label>Active</Label><Switch checked={location.is_active} onCheckedChange={(is_active) => setLocation({ ...location, is_active })} /></div>
          <Button className="rounded-full" onClick={() => createLocation.mutate(location)} disabled={!location.name}>Create location</Button>
        </CardContent></Card>

        <Card className="rounded-3xl"><CardContent className="space-y-4 p-6">
          <h3 className="text-xl font-semibold">Create building</h3>
          <div><Label>Location</Label><Select value={building.location_id || ""} onValueChange={(location_id) => setBuilding({ ...building, location_id })}><SelectTrigger><SelectValue placeholder="Select location" /></SelectTrigger><SelectContent>{locations.map((l) => <SelectItem key={l.id} value={l.id}>{l.name}</SelectItem>)}</SelectContent></Select></div>
          <div><Label>Name</Label><Input value={building.name} onChange={(e) => setBuilding({ ...building, name: e.target.value })} /></div>
          <div><Label>Address detail</Label><Input value={building.address_detail} onChange={(e) => setBuilding({ ...building, address_detail: e.target.value })} /></div>
          <div><Label>Type</Label><Select value={building.type} onValueChange={(type) => setBuilding({ ...building, type })}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent>{types.map((type) => <SelectItem key={type} value={type}>{type}</SelectItem>)}</SelectContent></Select></div>
          <div className="flex items-center justify-between rounded-2xl border p-3"><Label>Active</Label><Switch checked={building.is_active} onCheckedChange={(is_active) => setBuilding({ ...building, is_active })} /></div>
          <Button className="rounded-full" onClick={() => createBuilding.mutate(building)} disabled={!building.location_id || !building.name}>Create building</Button>
        </CardContent></Card>
      </div>

      <div className="mt-8 grid gap-6 lg:grid-cols-2">
        <Card className="rounded-3xl"><CardContent className="p-6"><h3 className="mb-4 text-xl font-semibold">Locations</h3>{locations.length === 0 ? <EmptyState title="No locations yet" description="Create your first site before adding buildings." /> : <div className="space-y-3">{locations.map((l) => <div key={l.id} className="flex items-center justify-between rounded-2xl border p-4"><div><p className="font-medium">{l.name}</p><p className="text-sm text-muted-foreground">{l.city || "—"}, {l.country || "—"} · {l.type}</p></div><div className="flex items-center gap-2"><StatusPill active={l.is_active} /><Switch checked={l.is_active} onCheckedChange={(is_active) => updateLocation.mutate({ id: l.id, data: { is_active } })} /></div></div>)}</div>}</CardContent></Card>
        <Card className="rounded-3xl"><CardContent className="p-6"><h3 className="mb-4 text-xl font-semibold">Buildings</h3>{buildings.length === 0 ? <EmptyState title="No buildings yet" description="Buildings sit inside locations and contain floors or zones." /> : <div className="space-y-3">{buildings.map((b) => <div key={b.id} className="flex items-center justify-between rounded-2xl border p-4"><div><p className="font-medium">{b.name}</p><p className="text-sm text-muted-foreground">{locations.find((l) => l.id === b.location_id)?.name || "Unknown location"} · {b.type}</p></div><div className="flex items-center gap-2"><StatusPill active={b.is_active} /><Switch checked={b.is_active} onCheckedChange={(is_active) => updateBuilding.mutate({ id: b.id, data: { is_active } })} /></div></div>)}</div>}</CardContent></Card>
      </div>
    </div>
  );
}
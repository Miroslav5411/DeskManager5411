import React, { useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import PageHeader from "@/components/common/PageHeader";
import UnavailableEmployeeRow from "@/components/admin/UnavailableEmployeeRow";
import EmptyState from "@/components/common/EmptyState";
import { Loader2 } from "lucide-react";

const todayStr = () => {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
};

const addDays = (dateStr, n) => {
  const d = new Date(dateStr);
  d.setDate(d.getDate() + n);
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
};

// For a given employee, find the latest contiguous run of "Unavailable" days
// that includes today. Return: { unavailableUntil, returnDate }.
function resolveUnavailableWindow(statusesForEmployee, today) {
  const byDate = new Map(statusesForEmployee.map((s) => [s.date, s]));
  if (!byDate.get(today) || byDate.get(today).status_type !== "Unavailable") return null;

  let last = today;
  while (true) {
    const next = addDays(last, 1);
    const s = byDate.get(next);
    if (s && s.status_type === "Unavailable") {
      last = next;
    } else {
      break;
    }
  }
  return { unavailableUntil: last, returnDate: addDays(last, 1) };
}

// Pick the most relevant reason for this employee from AuditLog entries of
// type "Admin Set User Unavailable" - latest one wins.
function resolveReason(auditLogs, employeeId) {
  const entries = auditLogs
    .filter((a) => a.action_type === "Admin Set User Unavailable" && a.affected_object_id === employeeId)
    .sort((a, b) => (b.timestamp || "").localeCompare(a.timestamp || ""));
  const latest = entries[0];
  if (!latest) return "";
  // Prefer admin-supplied reason; fall back to summary.
  return latest.reason?.trim() || latest.summary || "";
}

export default function UnavailableEmployees() {
  const { data, isLoading } = useQuery({
    queryKey: ["admin-unavailable-employees"],
    queryFn: async () => {
      const today = todayStr();
      const [employees, statuses, audits] = await Promise.all([
        base44.entities.Employee.list("-created_date", 5000),
        base44.entities.DailyWorkStatus.filter({ status_type: "Unavailable" }, "-date", 5000),
        base44.entities.AuditLog.list("-timestamp", 2000).catch(() => []),
      ]);
      return { today, employees, statuses, audits };
    },
  });

  const rows = useMemo(() => {
    if (!data) return [];
    const { today, employees, statuses, audits } = data;
    const byEmployee = new Map();
    for (const s of statuses) {
      if (!byEmployee.has(s.employee_id)) byEmployee.set(s.employee_id, []);
      byEmployee.get(s.employee_id).push(s);
    }

    const result = [];
    for (const emp of employees) {
      if (emp.is_active === false) continue;
      const empStatuses = byEmployee.get(emp.id) || [];
      const window = resolveUnavailableWindow(empStatuses, today);
      if (!window) continue;
      result.push({
        employee: emp,
        unavailableUntil: window.unavailableUntil,
        returnDate: window.returnDate,
        reason: resolveReason(audits, emp.id),
      });
    }
    // Sort by soonest return first
    result.sort((a, b) => (a.returnDate || "").localeCompare(b.returnDate || ""));
    return result;
  }, [data]);

  return (
    <div>
      <PageHeader
        eyebrow="Admin · Availability"
        title="Unavailable Employees"
        description="All currently unavailable employees, with their expected return date and the reason recorded when they were set to unavailable."
      />

      {isLoading ? (
        <div className="flex items-center justify-center py-16 text-muted-foreground">
          <Loader2 className="mr-2 h-4 w-4 animate-spin" /> Loading…
        </div>
      ) : rows.length === 0 ? (
        <EmptyState
          title="No one is unavailable today"
          description="Employees set to Unavailable for today will appear here automatically."
        />
      ) : (
        <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-3">
          {rows.map((row) => (
            <UnavailableEmployeeRow key={row.employee.id} row={row} />
          ))}
        </div>
      )}
    </div>
  );
}
import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Play, ListChecks, Trash2 } from "lucide-react";
import { useToast } from "@/components/ui/use-toast";
import PageHeader from "@/components/common/PageHeader";
import SuiteSelector from "@/components/srt/SuiteSelector";
import SrtSummaryCards from "@/components/srt/SrtSummaryCards";
import SrtResultsTable from "@/components/srt/SrtResultsTable";

const SUITES = [
  { key: "role", label: "Role Access" },
  { key: "data", label: "Data Hierarchy" },
  { key: "desk", label: "Desk Booking" },
  { key: "status", label: "Work Status" },
  { key: "parking", label: "Parking" },
  { key: "guest", label: "Guest Booking" },
  { key: "reports", label: "Reports" },
  { key: "guestweek", label: "Guest Bookings Week" },
  { key: "notifications", label: "Notifications" },
  { key: "adminunav", label: "Admin Set Unavailable" },
  { key: "unavdash", label: "Unavailable Insights" },
  { key: "ux", label: "UX & Navigation" },
  { key: "aihelp", label: "AI Help Assistant" },
];

export default function SrtTests() {
  const { toast } = useToast();
  const [selected, setSelected] = useState(SUITES.map((s) => s.key));
  const [running, setRunning] = useState(false);
  const [cleaning, setCleaning] = useState(false);
  const [response, setResponse] = useState(null);

  const flatRows = response?.suites?.flatMap((s) => s.results.map((r) => ({ ...r, suite: s.suite }))) || [];

  const run = async (suites) => {
    setRunning(true);
    try {
      const res = await base44.functions.invoke("runSrtTests", { action: "run", suites });
      setResponse(res.data);
      const { summary } = res.data;
      toast({ title: "SRT run complete", description: `${summary.passed} passed · ${summary.failed} failed · ${summary.warnings} warnings` });
    } catch (e) {
      toast({ title: "SRT run failed", description: e.message, variant: "destructive" });
    } finally {
      setRunning(false);
    }
  };

  const cleanup = async () => {
    setCleaning(true);
    try {
      const res = await base44.functions.invoke("runSrtTests", { action: "cleanup" });
      const deleted = Object.entries(res.data.deleted || {}).filter(([, v]) => v > 0).map(([k, v]) => `${k}: ${v}`).join(", ");
      const totalSkipped = Object.values(res.data.skipped || {}).reduce((a, b) => a + b, 0);
      toast({
        title: "Cleanup complete",
        description: `${deleted || "No SRT records found"} · ${totalSkipped} non-SRT records protected`,
      });
    } catch (e) {
      toast({ title: "Cleanup failed", description: e.message, variant: "destructive" });
    } finally {
      setCleaning(false);
    }
  };

  return (
    <div>
      <PageHeader
        eyebrow="Admin · QA"
        title="SRT / QA Tests"
        description="System Regression Tests for the Workspace Management application. All test data is prefixed with SRT_TEST_ and never affects real records."
      />

      <SrtSummaryCards summary={response?.summary} lastRun={response?.timestamp} />

      <div className="mb-4">
        <SuiteSelector suites={SUITES} selected={selected} onChange={setSelected} />
      </div>

      <div className="mb-6 flex flex-wrap gap-2">
        <Button onClick={() => run(selected)} disabled={running || !selected.length} className="gap-2">
          <ListChecks className="h-4 w-4" /> Run selected tests
        </Button>
        <Button onClick={() => run(SUITES.map((s) => s.key))} disabled={running} variant="secondary" className="gap-2">
          <Play className="h-4 w-4" /> Run all tests
        </Button>
        <Button onClick={cleanup} disabled={cleaning} variant="outline" className="gap-2">
          <Trash2 className="h-4 w-4" /> Cleanup test data
        </Button>
        {(running || cleaning) && <span className="self-center text-sm text-muted-foreground">{running ? "Running tests..." : "Cleaning up..."}</span>}
      </div>

      <SrtResultsTable rows={flatRows} lastRun={response?.timestamp} />
    </div>
  );
}
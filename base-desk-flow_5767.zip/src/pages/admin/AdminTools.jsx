import React from "react";
import { Link } from "react-router-dom";
import {
  Users, UserX, CalendarCheck, Building2, Layers3, Map, Car,
  UserPlus, Bell, FileSpreadsheet, FlaskConical, ArrowRight,
} from "lucide-react";
import PageHeader from "@/components/common/PageHeader";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

const GROUPS = [
  {
    title: "People & Organization",
    description: "Employees, teams, availability, and statutory holidays.",
    items: [
      { label: "Employees", path: "/admin/people", icon: Users, desc: "Profiles, teams, roles, activation." },
      { label: "Unavailable Employees", path: "/admin/unavailable-employees", icon: UserX, desc: "Mark users as unavailable for one or more dates." },
      { label: "Public Holidays", path: "/admin/public-holidays", icon: CalendarCheck, desc: "Manually configured holiday calendar used by reports." },
    ],
  },
  {
    title: "Workspace Setup",
    description: "Sites, floors, and the physical desk and parking inventory.",
    items: [
      { label: "Locations", path: "/admin/locations", icon: Building2, desc: "Cities, addresses, and buildings." },
      { label: "Floors & Maps", path: "/admin/floors", icon: Layers3, desc: "Floors, parking zones, and floorplan images." },
      { label: "Desk Map", path: "/admin/desk-map", icon: Map, desc: "Place, edit, and label desks on the floorplan." },
      { label: "Parking Map", path: "/admin/parking-map", icon: Car, desc: "Place, edit, and label parking spots." },
    ],
  },
  {
    title: "Operations",
    description: "Day-to-day workplace administration tasks.",
    items: [
      { label: "Guest Bookings This Week", path: "/admin/guest-bookings", icon: UserPlus, desc: "Visitor desk + parking activity for the current week." },
      { label: "Notifications Admin", path: "/admin/notifications", icon: Bell, desc: "Create and manage company-wide announcements." },
      { label: "Fixed-Desk Import", path: "/admin/fixed-desk-import", icon: FileSpreadsheet, desc: "Bulk update fixed-desk assignments via XLSX." },
    ],
  },
  {
    title: "Governance",
    description: "Quality and compliance tooling.",
    items: [
      { label: "SRT / QA Tests", path: "/admin/srt-tests", icon: FlaskConical, desc: "Run system regression suites and verify cleanup." },
    ],
  },
];

export default function AdminTools() {
  return (
    <div data-testid="admin-tools-page">
      <PageHeader
        eyebrow="Admin"
        title="Admin Tools"
        description="Configuration, operations, and governance for the workplace platform."
      />
      <div className="space-y-10">
        {GROUPS.map((group) => (
          <section key={group.title}>
            <div className="mb-4">
              <h3 className="text-lg font-semibold tracking-tight">{group.title}</h3>
              <p className="text-sm text-muted-foreground">{group.description}</p>
            </div>
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              {group.items.map((tool) => {
                const Icon = tool.icon;
                return (
                  <Card key={tool.path} className="rounded-2xl transition hover:-translate-y-0.5 hover:shadow-md">
                    <CardContent className="flex h-full flex-col gap-3 p-5">
                      <div className="flex items-center gap-3">
                        <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-primary/10 text-primary">
                          <Icon className="h-5 w-5" />
                        </div>
                        <h4 className="text-base font-semibold">{tool.label}</h4>
                      </div>
                      <p className="flex-1 text-sm text-muted-foreground">{tool.desc}</p>
                      <Button asChild size="sm" variant="outline" className="self-start rounded-full">
                        <Link to={tool.path}>Open <ArrowRight className="ml-1.5 h-3.5 w-3.5" /></Link>
                      </Button>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </section>
        ))}
      </div>
    </div>
  );
}
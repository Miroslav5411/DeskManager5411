import React from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import PageHeader from "@/components/common/PageHeader";

export default function SetPassword() {
  return (
    <div className="mx-auto max-w-2xl">
      <PageHeader eyebrow="Invitation" title="Set Password / Invitation" description="Base44 handles account invitations, password setup, login, and reset flows. This screen confirms that the app relies on the platform authentication flow instead of a custom login page." />
      <Card className="rounded-3xl"><CardContent className="space-y-4 p-6">
        <p className="text-muted-foreground">New employees should be invited through Base44 user invitations. Their Employee business profile must use the same email address as their authenticated account.</p>
        <Button className="rounded-full" onClick={() => window.history.back()}>Back</Button>
      </CardContent></Card>
    </div>
  );
}
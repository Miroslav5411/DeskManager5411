import React, { useMemo, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import PageHeader from "@/components/common/PageHeader";
import EmployeeGate from "@/components/employee/EmployeeGate";
import NotificationCard from "@/components/notifications/NotificationCard";
import NotificationDetailDialog from "@/components/notifications/NotificationDetailDialog";
import { buildVisibleNotifications } from "@/utils/notificationRules";

export default function NotificationsPage() {
  return <EmployeeGate>{() => <NotificationsContent />}</EmployeeGate>;
}

function NotificationsContent() {
  const { data, isLoading } = useQuery({
    queryKey: ["user-notifications"],
    queryFn: () => base44.entities.Notification.list("-updated_date", 500),
  });
  const [open, setOpen] = useState(null);

  const visible = useMemo(() => buildVisibleNotifications(data || []), [data]);
  const pinned = visible.filter((n) => n.is_pinned);
  const standard = visible.filter((n) => !n.is_pinned);

  return (
    <div>
      <PageHeader
        eyebrow="Updates"
        title="Notifications"
        description="Active platform-wide announcements. Urgent items appear at the top."
      />

      {isLoading && <p className="text-sm text-muted-foreground">Loading…</p>}

      {!isLoading && visible.length === 0 && (
        <div className="rounded-3xl border bg-card p-8 text-muted-foreground">
          There are no active notifications right now.
        </div>
      )}

      {pinned.length > 0 && (
        <section className="mb-8">
          <h3 className="mb-3 text-sm font-semibold uppercase tracking-wide text-muted-foreground">Urgent</h3>
          <div className="grid gap-3 md:grid-cols-2">
            {pinned.map((n) => <NotificationCard key={n.id} notification={n} onOpen={setOpen} />)}
          </div>
        </section>
      )}

      {standard.length > 0 && (
        <section>
          <h3 className="mb-3 text-sm font-semibold uppercase tracking-wide text-muted-foreground">All notifications</h3>
          <div className="grid gap-3 md:grid-cols-2">
            {standard.map((n) => <NotificationCard key={n.id} notification={n} onOpen={setOpen} />)}
          </div>
        </section>
      )}

      <NotificationDetailDialog notification={open} onClose={() => setOpen(null)} />
    </div>
  );
}
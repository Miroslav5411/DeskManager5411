import React from "react";
import { Link } from "react-router-dom";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import PageHeader from "@/components/common/PageHeader";
import { ArrowRight, Map, Users, Building2 } from "lucide-react";

const steps = [
  { title: "1. Employees, Teams & Roles", text: "Create business profiles and keep role control Admin-only.", path: "/admin/people", icon: Users },
  { title: "2. Locations & Buildings", text: "Create and maintain the hierarchy root.", path: "/admin/locations", icon: Building2 },
  { title: "3. Floors, Maps & Desk Editor", text: "Upload floor maps and place desks for future booking phases.", path: "/admin/floors", icon: Map },
];

export default function Home() {
  return (
    <div>
      <PageHeader
        eyebrow="Admin"
        title="Workspace setup"
        description="Configure people and teams, the site hierarchy, and floor maps."
      />
      <div className="grid gap-4 md:grid-cols-3">
        {steps.map((step) => {
          const Icon = step.icon;
          return (
            <Card key={step.title} className="rounded-3xl border bg-card shadow-sm transition hover:-translate-y-1 hover:shadow-lg">
              <CardContent className="p-6">
                <div className="mb-5 flex h-12 w-12 items-center justify-center rounded-2xl bg-primary text-primary-foreground">
                  <Icon className="h-5 w-5" />
                </div>
                <h3 className="text-xl font-semibold">{step.title}</h3>
                <p className="mt-2 min-h-12 text-sm text-muted-foreground">{step.text}</p>
                <Button asChild className="mt-6 rounded-full">
                  <Link to={step.path}>Open <ArrowRight className="ml-2 h-4 w-4" /></Link>
                </Button>
              </CardContent>
            </Card>
          );
        })}
      </div>
    </div>
  );
}
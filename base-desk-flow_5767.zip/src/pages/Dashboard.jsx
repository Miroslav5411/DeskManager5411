import React from "react";
import { Link } from "react-router-dom";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import PageHeader from "@/components/common/PageHeader";
import EmployeeGate from "@/components/employee/EmployeeGate";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { activeBookingsForEmployee, activeGuestBookingsForHost, buildPlaceLabel, countGuestBookingsOnDate, findById, getDailyStatusForDate } from "@/utils/deskFlow";
import { getRollingDateWindow, todayKey } from "@/utils/dateWindow";
import { assertAllowedWorkStatus, isAllowedWorkStatus } from "@/utils/workspaceRules";
import DashboardNotificationsSection from "@/components/notifications/DashboardNotificationsSection";
import UnavailableInsightsShortcut from "@/components/admin/dashboard/UnavailableInsightsShortcut";

const dates = getRollingDateWindow();

export default function Dashboard() {
  return <EmployeeGate>{({ employee }) => <DashboardContent employee={employee} />}</EmployeeGate>;
}

function DashboardContent({ employee }) {
  const queryClient = useQueryClient();
  const { data, isLoading } = useQuery({
    queryKey: ["dashboard-data"],
    queryFn: async () => ({
      bookings: await base44.entities.DeskBooking.list(),
      parkingBookings: await base44.entities.ParkingBooking.list(),
      statuses: await base44.entities.DailyWorkStatus.list(),
      desks: await base44.entities.Desk.list(),
      parkingSpaces: await base44.entities.ParkingSpace.list(),
      locations: await base44.entities.Location.list(),
      buildings: await base44.entities.Building.list(),
      floors: await base44.entities.FloorZone.list(),
    }),
  });

  const setStatusMutation = useMutation({
    mutationFn: async (status_type) => {
      assertAllowedWorkStatus(status_type);
      const date = todayKey();
      const guestCount = countGuestBookingsOnDate(data.bookings, data.parkingBookings, employee.id, date);
      if (guestCount) window.alert("You have guest bookings on this date. These will remain active unless you cancel them.");
      const booking = (await base44.entities.DeskBooking.filter({ employee_id: employee.id, date, status: "Active", owner_type: "Employee" }))[0];
      if (booking) {
        const ok = window.confirm(`This will release your desk booking for ${date}. Continue?`);
        if (!ok) return;
        await base44.entities.DeskBooking.update(booking.id, { ...booking, status: "Released by User", cancelled_at: new Date().toISOString() });
      }
      const existing = (await base44.entities.DailyWorkStatus.filter({ employee_id: employee.id, date }))[0];
      const payload = { employee_id: employee.id, date, status_type, source: "Manual" };
      return existing ? base44.entities.DailyWorkStatus.update(existing.id, payload) : base44.entities.DailyWorkStatus.create(payload);
    },
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["dashboard-data"] }),
  });

  const cancelDeskGuestMutation = useMutation({
    mutationFn: (booking) => base44.entities.DeskBooking.update(booking.id, { ...booking, status: "Cancelled by Host", cancelled_at: new Date().toISOString() }),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["dashboard-data"] }),
  });

  const cancelParkingGuestMutation = useMutation({
    mutationFn: (booking) => base44.entities.ParkingBooking.update(booking.id, { ...booking, status: "Cancelled by Host", cancelled_at: new Date().toISOString() }),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["dashboard-data"] }),
  });

  if (isLoading) return <div className="py-12 text-center text-muted-foreground">Loading dashboard...</div>;

  const today = todayKey();
  const bookings = activeBookingsForEmployee(data.bookings, employee.id).filter((booking) => dates.some((date) => date.key === booking.date));
  const guestDeskBookings = activeGuestBookingsForHost(data.bookings, employee.id).filter((booking) => dates.some((date) => date.key === booking.date));
  const guestParkingBookings = (data.parkingBookings || []).filter((booking) => booking.status === "Active" && booking.owner_type === "Guest" && (booking.host_employee_id === employee.id || booking.employee_id === employee.id) && dates.some((date) => date.key === booking.date));
  const todayGuestCount = guestDeskBookings.filter((booking) => booking.date === today).length + guestParkingBookings.filter((booking) => booking.date === today).length;
  const rawTodayStatus = getDailyStatusForDate(data.statuses, employee.id, today);
  // Defensive: never display a status_type that isn't in the allowed set.
  const todayStatus = rawTodayStatus && isAllowedWorkStatus(rawTodayStatus.status_type) ? rawTodayStatus : null;
  const todayBooking = bookings.find((booking) => booking.date === today);
  const getDesk = (id) => findById(data.desks, id);
  const getParking = (id) => findById(data.parkingSpaces, id);

  return (
    <div data-testid="dashboard-page">
      <PageHeader eyebrow="Workspace" title="Dashboard" description="Your workspace schedule, bookings, and notifications." />
      <DashboardNotificationsSection />
      {(employee.role === "Admin" || employee.role === "Team Manager") && (
        <div className="mb-6">
          <UnavailableInsightsShortcut />
        </div>
      )}
      <div className="grid gap-4 lg:grid-cols-3">
        <Card className="rounded-2xl"><CardContent className="p-6"><p className="text-xs font-medium uppercase tracking-wider text-muted-foreground">Today’s status</p><h3 className="mt-2 text-2xl font-semibold">{todayStatus?.status_type || "Not set"}</h3></CardContent></Card>
        <Card className="rounded-2xl"><CardContent className="p-6"><p className="text-xs font-medium uppercase tracking-wider text-muted-foreground">Today’s desk</p><h3 className="mt-2 text-xl font-semibold">{todayBooking ? buildPlaceLabel({ desk: getDesk(todayBooking.desk_id), ...data }) : "No active desk booking"}</h3></CardContent></Card>
        <Card className="rounded-2xl"><CardContent className="p-6"><p className="text-xs font-medium uppercase tracking-wider text-muted-foreground">Today’s guest bookings</p><h3 className="mt-2 text-2xl font-semibold">{todayGuestCount}</h3></CardContent></Card>
      </div>
      <Card className="mt-6 rounded-2xl">
        <CardContent className="p-6">
          <p className="text-xs font-medium uppercase tracking-wider text-muted-foreground">Quick actions</p>
          <div className="mt-3 flex flex-wrap gap-2">
            <Button asChild><Link to="/book-desk">Book Desk</Link></Button>
            <Button asChild><Link to="/book-parking">Book Parking</Link></Button>
            <Button variant="outline" onClick={() => setStatusMutation.mutate("Home Office")}>Set Home Office</Button>
            <Button variant="outline" onClick={() => setStatusMutation.mutate("Unavailable")}>Set Unavailable</Button>
            <Button asChild variant="outline"><Link to="/my-schedule">My Schedule</Link></Button>
          </div>
        </CardContent>
      </Card>
      <div className="mt-6 grid gap-6 lg:grid-cols-2">
        <Card className="rounded-2xl"><CardContent className="p-6"><h3 className="text-base font-semibold">Upcoming desk bookings</h3><div className="mt-4 space-y-3">{bookings.length ? bookings.map((booking) => <div key={booking.id} className="rounded-xl border p-4"><p className="font-medium">{booking.date}</p><p className="text-sm text-muted-foreground">{buildPlaceLabel({ desk: getDesk(booking.desk_id), ...data })}</p></div>) : <p className="text-sm text-muted-foreground">No upcoming desk bookings.</p>}</div></CardContent></Card>
        <Card className="rounded-2xl"><CardContent className="p-6"><h3 className="text-base font-semibold">Upcoming guest bookings</h3><div className="mt-4 space-y-3">{guestDeskBookings.map((booking) => <div key={booking.id} className="flex flex-col gap-3 rounded-xl border p-4 md:flex-row md:items-center md:justify-between"><div><p className="font-medium">Desk · {booking.date} · {booking.guest_name}</p><p className="text-sm text-muted-foreground">{booking.guest_role_reason} · {getDesk(booking.desk_id)?.code}</p></div><Button variant="outline" size="sm" onClick={() => cancelDeskGuestMutation.mutate(booking)}>Cancel</Button></div>)}{guestParkingBookings.map((booking) => <div key={booking.id} className="flex flex-col gap-3 rounded-xl border p-4 md:flex-row md:items-center md:justify-between"><div><p className="font-medium">Parking · {booking.date} · {booking.guest_name}</p><p className="text-sm text-muted-foreground">{booking.guest_role_reason} · {getParking(booking.parking_space_id)?.code} · {booking.vehicle_plate_number}</p></div><Button variant="outline" size="sm" onClick={() => cancelParkingGuestMutation.mutate(booking)}>Cancel</Button></div>)}{!guestDeskBookings.length && !guestParkingBookings.length && <p className="text-sm text-muted-foreground">No upcoming guest bookings.</p>}</div></CardContent></Card>
      </div>
    </div>
  );
}
import React, { useMemo } from "react";
import { Link } from "react-router-dom";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import PageHeader from "@/components/common/PageHeader";
import EmployeeGate from "@/components/employee/EmployeeGate";
import ScheduleTable from "@/components/schedule/ScheduleTable";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { activeGuestBookingsForHost, countGuestBookingsOnDate, findById, getActiveBookingForDate, getDailyStatusForDate } from "@/utils/deskFlow";
import { getRollingDateWindow } from "@/utils/dateWindow";
import { assertAllowedWorkStatus } from "@/utils/workspaceRules";

const dates = getRollingDateWindow();

export default function MySchedule() {
  return <EmployeeGate>{({ employee }) => <MyScheduleContent employee={employee} />}</EmployeeGate>;
}

function MyScheduleContent({ employee }) {
  const queryClient = useQueryClient();
  const { data, isLoading } = useQuery({
    queryKey: ["my-schedule-data"],
    queryFn: async () => ({
      bookings: await base44.entities.DeskBooking.list(),
      parkingBookings: await base44.entities.ParkingBooking.list(),
      statuses: await base44.entities.DailyWorkStatus.list(),
      desks: await base44.entities.Desk.list(),
      parkingSpaces: await base44.entities.ParkingSpace.list(),
      locations: await base44.entities.Location.list(),
      buildings: await base44.entities.Building.list(),
      floors: await base44.entities.FloorZone.list(),
    }),
  });

  const statusMutation = useMutation({
    mutationFn: async ({ date, statusType }) => {
      assertAllowedWorkStatus(statusType);
      const guestCount = countGuestBookingsOnDate(data.bookings, data.parkingBookings, employee.id, date);
      if ((statusType === "Home Office" || statusType === "Unavailable") && guestCount) window.alert("You have guest bookings on this date. These will remain active unless you cancel them.");
      const booking = getActiveBookingForDate(data.bookings, employee.id, date);
      if (statusType === "Office" && !employee.fixed_desk_id) throw new Error("Please book a desk to set Office status.");
      if ((statusType === "Home Office" || statusType === "Unavailable") && booking) {
        const ok = window.confirm(`This will release your desk booking for ${date}. Continue?`);
        if (!ok) return;
        await base44.entities.DeskBooking.update(booking.id, { ...booking, status: "Released by User", cancelled_at: new Date().toISOString() });
      }
      const fixedDesk = statusType === "Office" ? findById(data.desks, employee.fixed_desk_id) : null;
      const existing = (await base44.entities.DailyWorkStatus.filter({ employee_id: employee.id, date }))[0];
      const payload = { employee_id: employee.id, date, status_type: statusType, location_id: fixedDesk?.location_id, building_id: fixedDesk?.building_id, floor_id: fixedDesk?.floor_id, desk_id: fixedDesk?.id, source: "Manual" };
      if (existing) return base44.entities.DailyWorkStatus.update(existing.id, payload);
      return base44.entities.DailyWorkStatus.create(payload);
    },
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["my-schedule-data"] }),
  });

  const cancelDeskGuestMutation = useMutation({
    mutationFn: (booking) => base44.entities.DeskBooking.update(booking.id, { ...booking, status: "Cancelled by Host", cancelled_at: new Date().toISOString() }),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["my-schedule-data"] }),
  });

  const cancelParkingGuestMutation = useMutation({
    mutationFn: (booking) => base44.entities.ParkingBooking.update(booking.id, { ...booking, status: "Cancelled by Host", cancelled_at: new Date().toISOString() }),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["my-schedule-data"] }),
  });

  const rows = useMemo(() => {
    if (!data) return {};
    return Object.fromEntries(dates.map((date) => {
      const status = getDailyStatusForDate(data.statuses, employee.id, date.key);
      const booking = getActiveBookingForDate(data.bookings, employee.id, date.key);
      const desk = booking ? findById(data.desks, booking.desk_id) : status?.desk_id ? findById(data.desks, status.desk_id) : employee.fixed_desk_id && status?.status_type === "Office" ? findById(data.desks, employee.fixed_desk_id) : null;
      return [date.key, { status, booking, place: { desk, locations: data.locations, buildings: data.buildings, floors: data.floors } }];
    }));
  }, [data, employee]);

  if (isLoading) return <div className="py-12 text-center text-muted-foreground">Loading schedule...</div>;

  const guestDeskBookings = activeGuestBookingsForHost(data.bookings, employee.id).filter((booking) => dates.some((date) => date.key === booking.date));
  const guestParkingBookings = (data.parkingBookings || []).filter((booking) => booking.status === "Active" && booking.owner_type === "Guest" && (booking.host_employee_id === employee.id || booking.employee_id === employee.id) && dates.some((date) => date.key === booking.date));

  return (
    <div>
      <PageHeader eyebrow="Workspace" title="My Schedule" description="Manage your work status and guest bookings for the next 30 days." action={<Button asChild><Link to="/book-desk">Book Desk</Link></Button>} />
      {statusMutation.error && <Card className="mb-4 rounded-3xl border-primary"><CardContent className="flex flex-col gap-3 p-4 md:flex-row md:items-center md:justify-between"><span>{statusMutation.error.message}</span><Button asChild size="sm"><Link to="/book-desk">Go to Book Desk</Link></Button></CardContent></Card>}
      <ScheduleTable dates={dates} rows={rows} onSetStatus={(date, statusType) => statusMutation.mutate({ date, statusType })} />
      <Card className="mt-6 rounded-3xl"><CardContent className="p-6"><h3 className="text-lg font-semibold">Guest bookings I created</h3><div className="mt-4 space-y-3">{guestDeskBookings.map((booking) => <div key={booking.id} className="flex flex-col gap-3 rounded-2xl border p-4 md:flex-row md:items-center md:justify-between"><div><p className="font-medium">Desk · {booking.date} · {booking.guest_name}</p><p className="text-sm text-muted-foreground">{booking.guest_role_reason} · {findById(data.desks, booking.desk_id)?.code}</p></div><Button variant="outline" size="sm" onClick={() => cancelDeskGuestMutation.mutate(booking)}>Cancel</Button></div>)}{guestParkingBookings.map((booking) => <div key={booking.id} className="flex flex-col gap-3 rounded-2xl border p-4 md:flex-row md:items-center md:justify-between"><div><p className="font-medium">Parking · {booking.date} · {booking.guest_name}</p><p className="text-sm text-muted-foreground">{booking.guest_role_reason} · {findById(data.parkingSpaces, booking.parking_space_id)?.code} · {booking.vehicle_plate_number}</p></div><Button variant="outline" size="sm" onClick={() => cancelParkingGuestMutation.mutate(booking)}>Cancel</Button></div>)}{!guestDeskBookings.length && !guestParkingBookings.length && <p className="text-sm text-muted-foreground">No guest bookings in the next 30 days.</p>}</div></CardContent></Card>
    </div>
  );
}
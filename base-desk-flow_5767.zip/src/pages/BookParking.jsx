import React, { useMemo, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import PageHeader from "@/components/common/PageHeader";
import EmployeeGate from "@/components/employee/EmployeeGate";
import ParkingFloorMap from "@/components/parking/ParkingFloorMap";
import GuestBookingFields, { emptyGuestBooking, hasRequiredGuestFields } from "@/components/guest/GuestBookingFields";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { todayKey } from "@/utils/dateWindow";
import { isGuestBooking } from "@/utils/deskFlow";

export default function BookParking() {
  return <EmployeeGate>{({ employee }) => <BookParkingContent employee={employee} />}</EmployeeGate>;
}

function BookParkingContent({ employee }) {
  const queryClient = useQueryClient();
  const [bookingFor, setBookingFor] = useState("myself");
  const [guest, setGuest] = useState(emptyGuestBooking);
  const [date, setDate] = useState(todayKey());
  const [locationId, setLocationId] = useState("");
  const [buildingId, setBuildingId] = useState("");
  const [floorId, setFloorId] = useState("");
  const [selectedSpace, setSelectedSpace] = useState(null);
  const [message, setMessage] = useState("");
  const isGuestMode = bookingFor === "guest";

  const { data, isLoading } = useQuery({
    queryKey: ["parking-booking-data"],
    queryFn: async () => ({
      locations: await base44.entities.Location.list(),
      buildings: await base44.entities.Building.list(),
      floors: await base44.entities.FloorZone.list(),
      spaces: await base44.entities.ParkingSpace.list(),
      bookings: await base44.entities.ParkingBooking.list(),
      employees: await base44.entities.Employee.list(),
    }),
  });

  const activeBookings = useMemo(() => (data?.bookings || []).filter((booking) => booking.date === date && booking.status === "Active"), [data, date]);
  const myBooking = activeBookings.find((booking) => booking.employee_id === employee.id && !isGuestBooking(booking));
  const guestBookings = activeBookings.filter((booking) => isGuestBooking(booking) && (booking.host_employee_id === employee.id || booking.employee_id === employee.id));
  const filteredBuildings = (data?.buildings || []).filter((building) => !locationId || building.location_id === locationId);
  const filteredFloors = (data?.floors || []).filter((floor) => (!buildingId || floor.building_id === buildingId) && (floor.type === "Parking Floor" || floor.type === "Parking Zone"));
  const visibleSpaces = (data?.spaces || []).filter((space) => space.floor_zone_id === floorId && space.is_active !== false);

  const createBookingMutation = useMutation({
    mutationFn: async () => {
      setMessage("");
      if (isGuestMode && !hasRequiredGuestFields(guest, true)) throw new Error("Please complete all guest and vehicle details.");
      const freshBookings = await base44.entities.ParkingBooking.filter({ date, status: "Active" });
      const freshSpace = (await base44.entities.ParkingSpace.filter({ id: selectedSpace.id }))[0];
      if (!freshSpace || freshSpace.is_active === false || freshSpace.space_type === "Blocked" || freshSpace.space_type === "Company Car Fixed") throw new Error("This parking space cannot be booked.");
      if (freshBookings.some((booking) => booking.parking_space_id === freshSpace.id)) throw new Error("This parking space is no longer available.");
      if (!isGuestMode && freshBookings.some((booking) => booking.employee_id === employee.id && !isGuestBooking(booking))) throw new Error("You already have a parking booking for this date.");

      return base44.entities.ParkingBooking.create({
        employee_id: employee.id,
        parking_space_id: freshSpace.id,
        location_id: freshSpace.location_id,
        building_id: freshSpace.building_id,
        floor_zone_id: freshSpace.floor_zone_id,
        date,
        status: "Active",
        owner_type: isGuestMode ? "Guest" : "Employee",
        host_employee_id: isGuestMode ? employee.id : undefined,
        guest_name: isGuestMode ? guest.guest_name : undefined,
        guest_role_reason: isGuestMode ? guest.guest_role_reason : undefined,
        guest_email: isGuestMode ? guest.guest_email : undefined,
        guest_phone: isGuestMode ? guest.guest_phone : undefined,
        vehicle_plate_number: isGuestMode ? guest.vehicle_plate_number : undefined,
      });
    },
    onSuccess: () => {
      setSelectedSpace(null);
      setGuest(emptyGuestBooking);
      setMessage(isGuestMode ? "Guest parking booking confirmed." : "Parking booking confirmed.");
      queryClient.invalidateQueries({ queryKey: ["parking-booking-data"] });
    },
    onError: (error) => setMessage(error.message),
  });

  const cancelBookingMutation = useMutation({
    mutationFn: async (booking) => base44.entities.ParkingBooking.update(booking.id, { ...booking, status: isGuestBooking(booking) ? "Cancelled by Host" : "Released by User", cancelled_at: new Date().toISOString() }),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["parking-booking-data"] }),
  });

  if (isLoading) return <div className="py-12 text-center text-muted-foreground">Loading parking...</div>;

  return (
    <div>
      <PageHeader eyebrow="Workspace" title="Book Parking" description="Select a date and an available parking space." />

      <Card className="mb-6 rounded-3xl">
        <CardContent className="grid gap-3 p-4 md:grid-cols-4">
          <Select value={bookingFor} onValueChange={(value) => { setBookingFor(value); setSelectedSpace(null); }}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent><SelectItem value="myself">Book for myself</SelectItem><SelectItem value="guest">Book for guest</SelectItem></SelectContent></Select>
          <Input type="date" value={date} onChange={(event) => setDate(event.target.value)} />
          <Select value={locationId} onValueChange={(value) => { setLocationId(value); setBuildingId(""); setFloorId(""); }}>
            <SelectTrigger><SelectValue placeholder="Location" /></SelectTrigger>
            <SelectContent>{data.locations.map((location) => <SelectItem key={location.id} value={location.id}>{location.name}</SelectItem>)}</SelectContent>
          </Select>
          <Select value={buildingId} onValueChange={(value) => { setBuildingId(value); setFloorId(""); }}>
            <SelectTrigger><SelectValue placeholder="Building" /></SelectTrigger>
            <SelectContent>{filteredBuildings.map((building) => <SelectItem key={building.id} value={building.id}>{building.name}</SelectItem>)}</SelectContent>
          </Select>
          <Select value={floorId} onValueChange={(value) => { setFloorId(value); setSelectedSpace(null); }}>
            <SelectTrigger><SelectValue placeholder="Parking floor / zone" /></SelectTrigger>
            <SelectContent>{filteredFloors.map((floor) => <SelectItem key={floor.id} value={floor.id}>{floor.name}</SelectItem>)}</SelectContent>
          </Select>
        </CardContent>
      </Card>

      {isGuestMode && <Card className="mb-6 rounded-3xl"><CardContent className="p-4"><GuestBookingFields guest={guest} onChange={setGuest} includeVehicle /></CardContent></Card>}

      {myBooking && <Card className="mb-6 rounded-3xl border-primary/30 bg-primary/5"><CardContent className="flex flex-col gap-3 p-4 md:flex-row md:items-center md:justify-between"><p className="text-sm font-medium">You already have an active parking booking for this date.</p><Button variant="outline" onClick={() => cancelBookingMutation.mutate(myBooking)}>Cancel Booking</Button></CardContent></Card>}

      <ParkingFloorMap floor={data.floors.find((floor) => floor.id === floorId)} spaces={visibleSpaces} bookings={activeBookings} employees={data.employees} selectedSpaceId={selectedSpace?.id} onSelect={setSelectedSpace} />

      <div className="mt-4 flex items-center justify-between rounded-3xl border bg-card p-4">
        <p className="text-sm text-muted-foreground">{selectedSpace ? `Selected: ${selectedSpace.code}` : "Select an available parking space on the map."}</p>
        <Button disabled={!selectedSpace || (!isGuestMode && !!myBooking) || (isGuestMode && !hasRequiredGuestFields(guest, true))} onClick={() => createBookingMutation.mutate()}>{isGuestMode ? "Book Guest Parking" : "Book Parking"}</Button>
      </div>
      {message && <p className="mt-3 rounded-2xl bg-secondary p-3 text-sm">{message}</p>}

      {guestBookings.length > 0 && <Card className="mt-4 rounded-3xl"><CardContent className="p-6"><h3 className="font-semibold">Cancel guest parking bookings</h3><div className="mt-3 space-y-2">{guestBookings.map((booking) => <div key={booking.id} className="flex items-center justify-between rounded-2xl border p-3"><span>{booking.date} · {booking.guest_name} · {booking.vehicle_plate_number}</span><Button variant="outline" size="sm" onClick={() => cancelBookingMutation.mutate(booking)}>Cancel guest booking</Button></div>)}</div></CardContent></Card>}
    </div>
  );
}
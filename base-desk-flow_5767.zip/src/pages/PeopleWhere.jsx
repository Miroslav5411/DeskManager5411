import React, { useMemo, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import PageHeader from "@/components/common/PageHeader";
import EmployeeGate from "@/components/employee/EmployeeGate";
import HierarchySelects from "@/components/desk/HierarchySelects";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent } from "@/components/ui/card";
import { buildPlaceLabel, findById } from "@/utils/deskFlow";
import { todayKey } from "@/utils/dateWindow";
import { isAllowedWorkStatus } from "@/utils/workspaceRules";

export default function PeopleWhere() {
  return <EmployeeGate>{() => <PeopleWhereContent />}</EmployeeGate>;
}

function PeopleWhereContent() {
  const [date, setDate] = useState(todayKey());
  const [search, setSearch] = useState("");
  const [teamId, setTeamId] = useState("all");
  const [statusType, setStatusType] = useState("all");
  const [locationId, setLocationId] = useState("");
  const [buildingId, setBuildingId] = useState("");
  const [floorId, setFloorId] = useState("");

  const { data, isLoading } = useQuery({
    queryKey: ["people-where-data"],
    queryFn: async () => ({
      employees: await base44.entities.Employee.list(),
      teams: await base44.entities.Team.list(),
      statuses: await base44.entities.DailyWorkStatus.list(),
      bookings: await base44.entities.DeskBooking.list(),
      desks: await base44.entities.Desk.list(),
      locations: await base44.entities.Location.list(),
      buildings: await base44.entities.Building.list(),
      floors: await base44.entities.FloorZone.list(),
    }),
  });

  const rows = useMemo(() => {
    if (!data) return [];
    return data.employees.filter((employee) => employee.is_active !== false).map((employee) => {
      const rawStatus = data.statuses.find((item) => item.employee_id === employee.id && item.date === date);
      // Defensive: hide any DailyWorkStatus whose status_type is not in the allowed set.
      const status = rawStatus && isAllowedWorkStatus(rawStatus.status_type) ? rawStatus : null;
      const booking = data.bookings.find((item) => item.employee_id === employee.id && item.date === date && item.status === "Active");
      const desk = booking ? findById(data.desks, booking.desk_id) : status?.desk_id ? findById(data.desks, status.desk_id) : status?.status_type === "Office" ? findById(data.desks, employee.fixed_desk_id) : null;
      return { employee, team: findById(data.teams, employee.team_id), status, desk };
    }).filter((row) => {
      const status = row.status?.status_type || "Not set";
      const matchesSearch = row.employee.name?.toLowerCase().includes(search.toLowerCase());
      const matchesTeam = teamId === "all" || row.employee.team_id === teamId;
      const matchesStatus = statusType === "all" || status === statusType;
      const matchesPlace = statusType !== "Office" || ((!locationId || row.desk?.location_id === locationId) && (!buildingId || row.desk?.building_id === buildingId) && (!floorId || row.desk?.floor_id === floorId));
      return matchesSearch && matchesTeam && matchesStatus && matchesPlace;
    });
  }, [data, date, search, teamId, statusType, locationId, buildingId, floorId]);

  if (isLoading) return <div className="py-12 text-center text-muted-foreground">Loading people...</div>;

  return (
    <div>
      <PageHeader eyebrow="Workspace" title="Who Is Where" description="See where teammates are working today." />
      <Card className="mb-6 rounded-3xl"><CardContent className="grid gap-3 p-6 md:grid-cols-4"><Input type="date" value={date} onChange={(e) => setDate(e.target.value)} /><Input placeholder="Search employee" value={search} onChange={(e) => setSearch(e.target.value)} /><Select value={teamId} onValueChange={setTeamId}><SelectTrigger><SelectValue placeholder="Team" /></SelectTrigger><SelectContent><SelectItem value="all">All teams</SelectItem>{data.teams.map((team) => <SelectItem key={team.id} value={team.id}>{team.name}</SelectItem>)}</SelectContent></Select><Select value={statusType} onValueChange={setStatusType}><SelectTrigger><SelectValue placeholder="Status" /></SelectTrigger><SelectContent><SelectItem value="all">All statuses</SelectItem><SelectItem value="Office">Office</SelectItem><SelectItem value="Home Office">Home Office</SelectItem><SelectItem value="Unavailable">Unavailable</SelectItem></SelectContent></Select>{statusType === "Office" && <div className="md:col-span-4"><HierarchySelects locations={data.locations} buildings={data.buildings} floors={data.floors} locationId={locationId} buildingId={buildingId} floorId={floorId} onLocation={(id) => { setLocationId(id); setBuildingId(""); setFloorId(""); }} onBuilding={(id) => { setBuildingId(id); setFloorId(""); }} onFloor={setFloorId} /></div>}</CardContent></Card>
      <div className="space-y-3">{rows.map((row) => <Card key={row.employee.id} className="rounded-3xl"><CardContent className="grid gap-2 p-5 md:grid-cols-4 md:items-center"><div><p className="font-semibold">{row.employee.name}</p><p className="text-sm text-muted-foreground">{row.team?.name || "No team"}</p></div><div>{row.status?.status_type || "Not set"}</div><div className="text-sm text-muted-foreground md:col-span-2">{row.status?.status_type === "Office" ? buildPlaceLabel({ desk: row.desk, ...data }) : "No location shown"}</div></CardContent></Card>)}</div>
    </div>
  );
}
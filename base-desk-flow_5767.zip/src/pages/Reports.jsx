import React, { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useLocation } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import PageHeader from "@/components/common/PageHeader";
import ManagerOrAdminGate from "@/components/reports/ManagerOrAdminGate";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import DeskBookingsReport from "@/components/reports/DeskBookingsReport";
import ParkingBookingsReport from "@/components/reports/ParkingBookingsReport";
import EmployeeStatusReport from "@/components/reports/EmployeeStatusReport";
import GuestBookingsReport from "@/components/reports/GuestBookingsReport";
import OccupancyReport from "@/components/reports/OccupancyReport";
import TeamAttendanceSummary from "@/components/reports/TeamAttendanceSummary";
import UnavailableInsights from "@/components/reports/UnavailableInsights";

const REPORT_TABS = [
  { value: "desk", label: "Desk Bookings", Component: DeskBookingsReport },
  { value: "parking", label: "Parking Bookings", Component: ParkingBookingsReport },
  { value: "status", label: "Employee Status", Component: EmployeeStatusReport },
  { value: "guest", label: "Guest Bookings", Component: GuestBookingsReport },
  { value: "occupancy", label: "Occupancy", Component: OccupancyReport },
  { value: "team", label: "Team Attendance", Component: TeamAttendanceSummary },
  { value: "unavailable", label: "Unavailable Insights", Component: UnavailableInsights },
];

function ReportsContent() {
  const routerLocation = useLocation();
  const initialTab = (() => {
    const t = new URLSearchParams(routerLocation.search).get("tab");
    return REPORT_TABS.some((r) => r.value === t) ? t : "desk";
  })();
  const [tab, setTab] = useState(initialTab);

  const { data, isLoading } = useQuery({
    queryKey: ["reports-dataset"],
    queryFn: async () => ({
      deskBookings: await base44.entities.DeskBooking.list("-created_date", 5000),
      parkingBookings: await base44.entities.ParkingBooking.list("-created_date", 5000),
      dailyStatuses: await base44.entities.DailyWorkStatus.list("-created_date", 5000),
      employees: await base44.entities.Employee.list(),
      teams: await base44.entities.Team.list(),
      locations: await base44.entities.Location.list(),
      buildings: await base44.entities.Building.list(),
      floors: await base44.entities.FloorZone.list(),
      desks: await base44.entities.Desk.list("-created_date", 5000),
      parkingSpaces: await base44.entities.ParkingSpace.list("-created_date", 5000),
    }),
  });

  if (isLoading) {
    return <div className="py-12 text-center text-muted-foreground">Loading report data...</div>;
  }

  return (
    <div>
      <PageHeader
        eyebrow="Reports"
        title="Reports & Analytics"
        description="Operational reports for the rolling 4-month retention window. Export to XLSX."
      />
      <Tabs value={tab} onValueChange={setTab}>
        <TabsList className="mb-6 flex flex-wrap">
          {REPORT_TABS.map((rt) => (
            <TabsTrigger key={rt.value} value={rt.value}>
              {rt.label}
            </TabsTrigger>
          ))}
        </TabsList>
        {REPORT_TABS.map(({ value, Component }) => (
          <TabsContent key={value} value={value}>
            <Component data={data} />
          </TabsContent>
        ))}
      </Tabs>
    </div>
  );
}

export default function Reports() {
  return (
    <ManagerOrAdminGate>
      <ReportsContent />
    </ManagerOrAdminGate>
  );
}
import React, { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import PageHeader from "@/components/common/PageHeader";
import EmployeeGate from "@/components/employee/EmployeeGate";
import DateMultiSelect from "@/components/desk/DateMultiSelect";
import HierarchySelects from "@/components/desk/HierarchySelects";
import FloorDeskMap from "@/components/desk/FloorDeskMap";
import GuestBookingFields, { emptyGuestBooking, hasRequiredGuestFields } from "@/components/guest/GuestBookingFields";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { getActiveBookingForDate, getDeskAvailability, isGuestBooking } from "@/utils/deskFlow";
import { assertAllowedWorkStatus } from "@/utils/workspaceRules";

export default function BookDesk() {
  return <EmployeeGate>{({ employee }) => <BookDeskContent employee={employee} />}</EmployeeGate>;
}

function BookDeskContent({ employee }) {
  const [selectedDates, setSelectedDates] = useState([]);
  const [bookingFor, setBookingFor] = useState("myself");
  const [guest, setGuest] = useState(emptyGuestBooking);
  const [locationId, setLocationId] = useState(employee.default_location_id || "");
  const [buildingId, setBuildingId] = useState(employee.default_building_id || "");
  const [floorId, setFloorId] = useState(employee.default_floor_id || "");
  const [selectedDeskId, setSelectedDeskId] = useState("");
  const [message, setMessage] = useState("");
  const queryClient = useQueryClient();
  const isGuestMode = bookingFor === "guest";

  const { data, isLoading } = useQuery({
    queryKey: ["book-desk-data"],
    queryFn: async () => ({
      locations: await base44.entities.Location.list(),
      buildings: await base44.entities.Building.list(),
      floors: await base44.entities.FloorZone.list(),
      desks: await base44.entities.Desk.list(),
      teams: await base44.entities.Team.list(),
      employees: await base44.entities.Employee.list(),
      bookings: await base44.entities.DeskBooking.list(),
      statuses: await base44.entities.DailyWorkStatus.list(),
    }),
  });

  const refresh = () => queryClient.invalidateQueries({ queryKey: ["book-desk-data"] });

  const bookingMutation = useMutation({
    mutationFn: async () => {
      setMessage("");
      if (isGuestMode && !hasRequiredGuestFields(guest)) throw new Error("Please complete all guest details.");
      const activeBookings = await base44.entities.DeskBooking.filter({ status: "Active" });
      const desk = (await base44.entities.Desk.filter({ id: selectedDeskId }))[0];
      if (!desk || desk.is_active === false || desk.desk_type === "Blocked" || desk.desk_type === "Fixed") throw new Error("This desk cannot be booked.");

      // Per-date conflict re-check against fresh bookings (all-or-nothing)
      const conflicts = selectedDates.filter((date) =>
        activeBookings.some((booking) => booking.desk_id === desk.id && booking.date === date)
      );
      if (isGuestMode) {
        if (conflicts.length) throw new Error(`Desk unavailable on: ${conflicts.join(", ")}`);
      } else {
        const availability = getDeskAvailability({ desk, selectedDates, activeBookings, employeeId: employee.id });
        if (availability.state !== "available") throw new Error(`Desk unavailable on: ${availability.conflicts.join(", ")}`);
        const ownConflicts = selectedDates.filter((date) => activeBookings.some((booking) => booking.employee_id === employee.id && booking.date === date && !isGuestBooking(booking)));
        if (ownConflicts.length) throw new Error(`You already have a booking on: ${ownConflicts.join(", ")}`);
      }

      await base44.entities.DeskBooking.bulkCreate(selectedDates.map((date) => ({
        employee_id: employee.id,
        desk_id: desk.id,
        location_id: desk.location_id,
        building_id: desk.building_id,
        floor_id: desk.floor_id,
        date,
        status: "Active",
        owner_type: isGuestMode ? "Guest" : "Employee",
        host_employee_id: isGuestMode ? employee.id : undefined,
        guest_name: isGuestMode ? guest.guest_name : undefined,
        guest_role_reason: isGuestMode ? guest.guest_role_reason : undefined,
        guest_email: isGuestMode ? guest.guest_email : undefined,
        guest_phone: isGuestMode ? guest.guest_phone : undefined,
      })));

      if (!isGuestMode) {
        for (const date of selectedDates) {
          const existing = (await base44.entities.DailyWorkStatus.filter({ employee_id: employee.id, date }))[0];
          const payload = { employee_id: employee.id, date, status_type: "Office", location_id: desk.location_id, building_id: desk.building_id, floor_id: desk.floor_id, desk_id: desk.id, source: "Generated from Desk Booking" };
          assertAllowedWorkStatus(payload.status_type);
          if (existing) await base44.entities.DailyWorkStatus.update(existing.id, payload);
          else await base44.entities.DailyWorkStatus.create(payload);
        }
      }
    },
    onSuccess: () => { setSelectedDeskId(""); setGuest(emptyGuestBooking); setMessage(isGuestMode ? "Guest desk booking confirmed." : "Desk booked successfully."); refresh(); },
    onError: (error) => setMessage(error.message),
  });

  const cancelMutation = useMutation({
    mutationFn: async (booking) => {
      await base44.entities.DeskBooking.update(booking.id, { ...booking, status: isGuestBooking(booking) ? "Cancelled by Host" : "Released by User", cancelled_at: new Date().toISOString() });
      if (!isGuestBooking(booking)) {
        const status = (await base44.entities.DailyWorkStatus.filter({ employee_id: employee.id, date: booking.date }))[0];
        if (status?.source === "Generated from Desk Booking") await base44.entities.DailyWorkStatus.delete(status.id);
      }
    },
    onSuccess: refresh,
  });

  if (isLoading) return <div className="py-12 text-center text-muted-foreground">Loading desk map...</div>;
  const activeBookings = data.bookings.filter((booking) => booking.status === "Active");
  const floor = data.floors.find((item) => item.id === floorId);
  const floorDesks = data.desks.filter((desk) => desk.floor_id === floorId);
  const ownBookings = selectedDates.map((date) => getActiveBookingForDate(activeBookings, employee.id, date)).filter(Boolean);
  const guestBookings = data.bookings.filter((booking) => booking.status === "Active" && isGuestBooking(booking) && (booking.host_employee_id === employee.id || booking.employee_id === employee.id) && selectedDates.includes(booking.date));
  const canConfirm = selectedDates.length > 0 && selectedDeskId && !bookingMutation.isPending && (!isGuestMode || hasRequiredGuestFields(guest));

  return (
    <div>
      <PageHeader eyebrow="Workspace" title="Book Desk" description="Select a date, location, and available desk." />
      <div className="grid gap-6 lg:grid-cols-[380px_1fr]">
        <Card className="rounded-3xl"><CardContent className="space-y-6 p-6">
          <div><h3 className="mb-3 font-semibold">Booking type</h3><Select value={bookingFor} onValueChange={(value) => { setBookingFor(value); setSelectedDeskId(""); }}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent><SelectItem value="myself">Book for myself</SelectItem><SelectItem value="guest">Book for guest</SelectItem></SelectContent></Select></div>
          {isGuestMode && <GuestBookingFields guest={guest} onChange={setGuest} />}
          <div><h3 className="mb-3 font-semibold">1. Select dates</h3><DateMultiSelect selectedDates={selectedDates} onChange={setSelectedDates} /></div>
          <div><h3 className="mb-3 font-semibold">2. Select floor</h3><HierarchySelects locations={data.locations} buildings={data.buildings} floors={data.floors} locationId={locationId} buildingId={buildingId} floorId={floorId} onLocation={(id) => { setLocationId(id); setBuildingId(""); setFloorId(""); }} onBuilding={(id) => { setBuildingId(id); setFloorId(""); }} onFloor={setFloorId} /></div>
          <Button disabled={!canConfirm} onClick={() => bookingMutation.mutate()} className="w-full">{isGuestMode ? "Confirm guest booking" : "Confirm booking"}</Button>{message && <p className="rounded-2xl bg-secondary p-3 text-sm">{message}</p>}
        </CardContent></Card>
        <div className="space-y-4">
          {floor ? <FloorDeskMap floor={floor} desks={floorDesks} teams={data.teams} employees={data.employees} selectedDates={selectedDates} activeBookings={activeBookings} employeeId={employee.id} selectedDeskId={selectedDeskId} onSelectDesk={setSelectedDeskId} /> : <Card className="rounded-3xl"><CardContent className="p-8 text-center text-muted-foreground">Select a floor to view desks.</CardContent></Card>}
          {ownBookings.length > 0 && <Card className="rounded-3xl"><CardContent className="p-6"><h3 className="font-semibold">Release your active bookings</h3><div className="mt-3 space-y-2">{ownBookings.map((booking) => <div key={booking.id} className="flex items-center justify-between rounded-2xl border p-3"><span>{booking.date}</span><Button variant="outline" size="sm" onClick={() => cancelMutation.mutate(booking)}>Release</Button></div>)}</div></CardContent></Card>}
          {guestBookings.length > 0 && <Card className="rounded-3xl"><CardContent className="p-6"><h3 className="font-semibold">Cancel guest desk bookings</h3><div className="mt-3 space-y-2">{guestBookings.map((booking) => <div key={booking.id} className="flex items-center justify-between rounded-2xl border p-3"><span>{booking.date} · {booking.guest_name}</span><Button variant="outline" size="sm" onClick={() => cancelMutation.mutate(booking)}>Cancel guest booking</Button></div>)}</div></CardContent></Card>}
        </div>
      </div>
    </div>
  );
}